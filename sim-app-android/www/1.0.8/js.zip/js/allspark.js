define('AnimTransform', ['Transformation', 'Transition', 'Matrix'], function(Transformation, Transition, Matrix) {

    /**
     * creates instanceof AnimTransform class. simObjects inherits this class, all the method of this class are accessed through simObject
     * @constructor AnimTransform
     */
    function AnimTransform(options) {
        _initTransform.call(this, options);
    }

    function _initTransform(options) {
        this._transformGetter = null;
        this._opacityGetter = null;
        this._originGetter = null;
        this._sizeGetter = null;

        /* TODO: remove this when deprecation complete */
        this._legacyStates = {};

        this._output = {
            transform: Matrix.identity,
            opacity: 1,
            origin: null,
            size: null,
            target: null
        };

        if (options) {
            if (options.transform) this.transformFrom(options.transform);
            if (options.opacity !== undefined) this.opacityFrom(options.opacity);
            if (options.origin) this.originFrom(options.origin);
            if (options.size) this.sizeFrom(options.size);
        }
    }

    /**
     * resets the AnimTransform object,this method would be called from simObject
     * @memberof AnimTransform
     * @method _resetTransform
     */
    AnimTransform.prototype._resetTransform = function _resetTransform() {
        _initTransform.call(this, {
            opacity: this._opacity,
            size: this.size,
            origin: this._origin,
            transform: Matrix.identity
        });
    }

    AnimTransform.prototype.transformFrom = function transformFrom(transform) {
        if (transform instanceof Function) this._transformGetter = transform;
        else if (transform instanceof Object && transform.get) this._transformGetter = transform.get.bind(transform);
        else {
            this._transformGetter = null;
            this._output.transform = transform;
        }
        return this;
    };


    AnimTransform.prototype.opacityFrom = function opacityFrom(opacity) {
        if (opacity instanceof Function) this._opacityGetter = opacity;
        else if (opacity instanceof Object && opacity.get) this._opacityGetter = opacity.get.bind(opacity);
        else {
            this._opacityGetter = null;
            this._output.opacity = opacity;
        }
        return this;
    };


    AnimTransform.prototype.originFrom = function originFrom(origin) {
        if (origin instanceof Function) this._originGetter = origin;
        else if (origin instanceof Object && origin.get) this._originGetter = origin.get.bind(origin);
        else {
            this._originGetter = null;
            this._output.origin = origin;
        }
        return this;
    };


    AnimTransform.prototype.sizeFrom = function sizeFrom(size) {
        if (size instanceof Function) this._sizeGetter = size;
        else if (size instanceof Object && size.get) this._sizeGetter = size.get.bind(size);
        else {
            this._sizeGetter = null;
            this._output.size = size;
        }
        return this;
    };

    /**
     * transform a simObject
     * @memberof AnimTransform
     * @method transform
     * @param {Matrix[]} matrix final matrix value
     * @param {object} transitionOptions {duration:,curve:}
     * @param {function} callback callback after animation completion
     */
    AnimTransform.prototype.transform = function setTransform(transform, transitionOptions, callback) {
        if (transitionOptions || this._legacyStates.transform) {
            if (!this._legacyStates.transform) {
                this._legacyStates.transform = new Transformation(this._output.transform);
            }
            if (!this._transformGetter) this.transformFrom(this._legacyStates.transform);

            this._legacyStates.transform.set(transform, transitionOptions, callback);
            return this;
        } else return this.transformFrom(transform);
    };

    /**
     * setOpacity of a simObject
     * @memberof AnimTransform
     * @method setOpacity
     * @param {number} opacity final opacity values
     * @param {object} transitionOptions {duration:,curve:}
     * @param {function} callback callback after animation completion
     */
    AnimTransform.prototype.setOpacity = function setOpacity(opacity, transitionOptions, callback) {
        if (transitionOptions || this._legacyStates.opacity) {
            if (!this._legacyStates.opacity) {
                this._legacyStates.opacity = new Transition(this._output.opacity);
            }
            if (!this._opacityGetter) this.opacityFrom(this._legacyStates.opacity);

            return this._legacyStates.opacity.set(opacity, transitionOptions, callback);
        } else return this.opacityFrom(opacity);
    };

    /**
     * setOrigin of a simObject
     * @memberof AnimTransform
     * @method setOrigin
     * @param {origin[]} opacity final value of origin
     * @param {object} transitionOptions {duration:,curve:}
     * @param {function} callback callback after animation completion
     */
    AnimTransform.prototype.setOrigin = function setOrigin(origin, transitionOptions, callback) {
        /* TODO: remove this if statement when deprecation complete */
        if (transitionOptions || this._legacyStates.origin) {

            if (!this._legacyStates.origin) {
                this._legacyStates.origin = new Transition(this._output.origin || [0, 0]);
            }
            if (!this._originGetter) this.originFrom(this._legacyStates.origin);

            this._legacyStates.origin.set(origin, transitionOptions, callback);
            return this;
        } else return this.originFrom(origin);
    };

    /**
     * setOrigin of a simObject
     * @memberof AnimTransform
     * @method setSize
     * @param {size[]} size final size
     * @param {object} transitionOptions {duration:,curve:}
     * @param {function} callback callback after animation completion
     */
    AnimTransform.prototype.setSize = function setSize(size, transitionOptions, callback) {
        if (size && (transitionOptions || this._legacyStates.size)) {
            if (!this._legacyStates.size) {
                this._legacyStates.size = new Transition(this._output.size || [0, 0]);
            }
            if (!this._sizeGetter) this.sizeFrom(this._legacyStates.size);

            this._legacyStates.size.set(size, transitionOptions, callback);
            return this;
        } else return this.sizeFrom(size);
    };

    AnimTransform.prototype.halt = function halt() {
        if (this._legacyStates.transform) this._legacyStates.transform.halt();
        if (this._legacyStates.opacity) this._legacyStates.opacity.halt();
        if (this._legacyStates.origin) this._legacyStates.origin.halt();
        if (this._legacyStates.size) this._legacyStates.size.halt();
        this._transformGetter = null;
        this._opacityGetter = null;
        this._originGetter = null;
        this._sizeGetter = null;
    };

    AnimTransform.prototype.pause = function pause() {
        if (this._legacyStates.transform)
            this._legacyStates.transform.pause();
    }


    AnimTransform.prototype.getTransform = function getTransform() {
        return this._transformGetter();
    };


    AnimTransform.prototype.getFinalTransform = function getFinalTransform() {
        return this._legacyStates.transform ? this._legacyStates.transform.getFinal() : this._output.transform;
    };


    AnimTransform.prototype.getOpacity = function getOpacity() {
        return this._opacityGetter();
    };

    AnimTransform.prototype.getOrigin = function getOrigin() {
        return this._originGetter();
    };


    AnimTransform.prototype.getSize = function getSize() {
        return this._sizeGetter ? this._sizeGetter() : this._output.size;
    };

    // call providers on tick to receive render spec elements to apply
    function _update() {
        if (this._transformGetter) this._output.transform = this._transformGetter();
        if (this._opacityGetter) this._output.opacity = this._opacityGetter();
        if (this._originGetter) this._output.origin = this._originGetter();
        if (this._sizeGetter) this._output.size = this._sizeGetter();
    }

    /**
     * get the manipulated values of the simObject
     * @memberof AnimTransform
     * @method manipulate
     */
    AnimTransform.prototype.manipulate = function manipulate(target) {
        _update.call(this);
        this._output.target = target;
        return {
            transform: this._output.transform,
            opacity: this._output.opacity,
            origin: this._output.origin,
            size: this._output.size
        };
    };

    return AnimTransform
});;
define('Animation',['rAF'],function(rAF) {
	
	/**
	 * creates instance of Animation hander class
	 * @constructor Animation
	 * @param {object} scene
	 */
	
	var frameID ;
	function Animation(object){
			cancelAnimationFrame(frameID);
		this._context = object;
		this._lastTime = Date.now();
		this._currentTime = undefined;
		this._lapseTime = undefined;
		this._pause = false;
	}
	
	
	/**
	 * pauses all the Animation running inside the scene
	 * @memberof Animation
	 * @method pause
	 */
	Animation.prototype.pause = function(){
		this._pause = true;
	}
	
	/**
	 * resume or play the Animations 
	 * @memberof Animation
	 * @method play
	 */
	Animation.prototype.play = function(){
		this._pause = false;
	}
	
	/**
	 * stop the Animation handler
	 * @method stop
	 * @memberof Animation
	 */
	Animation.prototype.stop = function(){
		cancelAnimationFrame(this.frameID);
	}
	
	
	/**
	 * Animation handler loop, which runs all the time, its triggers update of scene, which eventually triggers update of
	 * simObjects
	 * @memberof Animation
	 * @method animate
	 */
	Animation.prototype.animate = function(){
		var self = this;
		this._currentTime = Date.now();
		this._lapseTime =  this._currentTime-this._lastTime;
		this._lastTime = this._currentTime;
			if(this._pause){
				this._context.pause();
			}else{
				this._context.update();
			}
		 this.frameID = requestAnimationFrame(function(){
			 self.animate();
			 });
		 frameID = this.frameID;
	}	
	
	return Animation;

});
	;define('Transformation', ['Matrix', 'Transition', 'utility'], function(Transform, transition, Utility) {

    function Transformation(transform) {
        this._final = Transform.identity.slice();
        this.translate = new transition([0, 0, 0]);
        this.rotate = new transition([0, 0, 0]);
        this.skew = new transition([0, 0, 0]);
        this.scale = new transition([1, 1, 1]);

        if (transform) this.set(transform);
    }

    function _build() {
        return Transform.build({
            translate: this.translate.get(),
            rotate: this.rotate.get(),
            skew: this.skew.get(),
            scale: this.scale.get()
        });
    }


    Transformation.prototype.setTranslate = function setTranslate(translate, transitionOptions, callback) {
        this.translate.set(translate, transitionOptions, callback);
        this._final = this._final.slice();
        this._final[12] = translate[0];
        this._final[13] = translate[1];
        if (translate[2] !== undefined) this._final[14] = translate[2];
        return this;
    };


    Transformation.prototype.setScale = function setScale(scale, transitionOptions, callback) {
        this.scale.set(scale, transitionOptions, callback);
        this._final = this._final.slice();
        this._final[0] = scale[0];
        this._final[5] = scale[1];
        if (scale[2] !== undefined) this._final[10] = scale[2];
        return this;
    };


    Transformation.prototype.setRotate = function setRotate(eulerAngles, transitionOptions, callback) {
        this.rotate.set(eulerAngles, transitionOptions, callback);
        this._final = _build.call(this);
        this._final = Transform.build({
            translate: this.translate.get(),
            rotate: eulerAngles,
            scale: this.scale.get(),
            skew: this.skew.get()
        });
        return this;
    };


    Transformation.prototype.setSkew = function setSkew(skewAngles, transitionOptions, callback) {
        this.skew.set(skewAngles, transitionOptions, callback);
        this._final = Transform.build({
            translate: this.translate.get(),
            rotate: this.rotate.get(),
            scale: this.scale.get(),
            skew: skewAngles
        });
        return this;
    };


    Transformation.prototype.set = function set(transform, transitionOptions, callback) {
        this._final = transform;
        var components = Transform.interpret(transform);

        var _callback = callback ? Utility.after(4, callback) : null;
        this.translate.set(components.translate, transitionOptions, _callback);
        this.rotate.set(components.rotate, transitionOptions, _callback);
        this.skew.set(components.skew, transitionOptions, _callback);
        this.scale.set(components.scale, transitionOptions, _callback);
        return this;
    };


    Transformation.prototype.setDefaultTransition = function setDefaultTransition(transitionOptions) {
        this.translate.setDefault(transitionOptions);
        this.rotate.setDefault(transitionOptions);
        this.skew.setDefault(transitionOptions);
        this.scale.setDefault(transitionOptions);
    };


    Transformation.prototype.get = function get() {
        if (this.isActive()) {
            return _build.call(this);
        } else return this._final;
    };


    Transformation.prototype.getFinal = function getFinal() {
        return this._final;
    };


    Transformation.prototype.isActive = function isActive() {
        return this.translate.isActive() || this.rotate.isActive() || this.scale.isActive() || this.skew.isActive();
    };


    Transformation.prototype.halt = function halt() {
        this._final = this.get();
        this.translate.halt();
        this.rotate.halt();
        this.skew.halt();
        this.scale.halt();
    };

    Transformation.prototype.pause = function pause() {
        this.translate.pause();
        this.rotate.pause();
        this.skew.pause();
        this.scale.pause();
    }

    return Transformation

});;
define('easing',[],function() {	
	
/**
 * @namespace easing
 */	
var easing = {
		
		/**
		 * @memberof easing
		 * @method inQuad
		 */
        inQuad: function(t) {
            return t*t;
        },
        
        /**
         * @memberof easing
         * @method linear
         */
        linear: function(t) {
            return t;
        },

		/**
		 * @memberof easing
		 * @method outQuad
		 */
        outQuad: function(t) {
            return -(t-=1)*t+1;
        },

		/**
		 * @memberof easing
		 * @method inOutQuad
		 */
        inOutQuad: function(t) {
            if ((t/=.5) < 1) return .5*t*t;
            return -.5*((--t)*(t-2) - 1);
        },

		/**
		 * @memberof easing
		 * @method inCubic
		 */
        inCubic: function(t) {
            return t*t*t;
        },

		/**
		 * @memberof easing
		 * @method outCubic
		 */
        outCubic: function(t) {
            return ((--t)*t*t + 1);
        },

		/**
		 * @memberof easing
		 * @method inOutCubic
		 */
        inOutCubic: function(t) {
            if ((t/=.5) < 1) return .5*t*t*t;
            return .5*((t-=2)*t*t + 2);
        },

		/**
		 * @memberof easing
		 * @method inQuart
		 */
        inQuart: function(t) {
            return t*t*t*t;
        },
		/**
		 * @memberof easing
		 * @method outQuart
		 */
        outQuart: function(t) {
            return -((--t)*t*t*t - 1);
        },
		/**
		 * @memberof easing
		 * @method inOutQuart
		 */
        inOutQuart: function(t) {
            if ((t/=.5) < 1) return .5*t*t*t*t;
            return -.5 * ((t-=2)*t*t*t - 2);
        },
		/**
		 * @memberof easing
		 * @method inQuint
		 */
        inQuint: function(t) {
            return t*t*t*t*t;
        },
		/**
		 * @memberof easing
		 * @method outQuint
		 */
        outQuint: function(t) {
            return ((--t)*t*t*t*t + 1);
        },
		/**
		 * @memberof easing
		 * @method inOutQuint
		 */
        inOutQuint: function(t) {
            if ((t/=.5) < 1) return .5*t*t*t*t*t;
            return .5*((t-=2)*t*t*t*t + 2);
        },
		/**
		 * @memberof easing
		 * @method inSine
		 */
        inSine: function(t) {
            return -1.0*Math.cos(t * (Math.PI/2)) + 1.0;
        },
		/**
		 * @memberof easing
		 * @method outSine
		 */
        outSine: function(t) {
            return Math.sin(t * (Math.PI/2));
        },
		/**
		 * @memberof easing
		 * @method inOutSine
		 */
        inOutSine: function(t) {
            return -.5*(Math.cos(Math.PI*t) - 1);
        },
		/**
		 * @memberof easing
		 * @method inExpo
		 */
        inExpo: function(t) {
            return (t===0) ? 0.0 : Math.pow(2, 10 * (t - 1));
        },
		/**
		 * @memberof easing
		 * @method outExpo
		 */
        outExpo: function(t) {
            return (t===1.0) ? 1.0 : (-Math.pow(2, -10 * t) + 1);
        },
		/**
		 * @memberof easing
		 * @method inOutExpo
		 */
        inOutExpo: function(t) {
            if (t===0) return 0.0;
            if (t===1.0) return 1.0;
            if ((t/=.5) < 1) return .5 * Math.pow(2, 10 * (t - 1));
            return .5 * (-Math.pow(2, -10 * --t) + 2);
        },
		/**
		 * @memberof easing
		 * @method inCirc
		 */
        inCirc: function(t) {
            return -(Math.sqrt(1 - t*t) - 1);
        },
		/**
		 * @memberof easing
		 * @method outCirc
		 */
        outCirc: function(t) {
            return Math.sqrt(1 - (--t)*t);
        },
		/**
		 * @memberof easing
		 * @method inOutCirc
		 */
        inOutCirc: function(t) {
            if ((t/=.5) < 1) return -.5 * (Math.sqrt(1 - t*t) - 1);
            return .5 * (Math.sqrt(1 - (t-=2)*t) + 1);
        },
		/**
		 * @memberof easing
		 * @method inElastic
		 */
        inElastic: function(t) {
            var s=1.70158;var p=0;var a=1.0;
            if (t===0) return 0.0;  if (t===1) return 1.0;  if (!p) p=.3;
            s = p/(2*Math.PI) * Math.asin(1.0/a);
            return -(a*Math.pow(2,10*(t-=1)) * Math.sin((t-s)*(2*Math.PI)/ p));
        },
		/**
		 * @memberof easing
		 * @method outElastic
		 */
        outElastic: function(t) {
            var s=1.70158;var p=0;var a=1.0;
            if (t===0) return 0.0;  if (t===1) return 1.0;  if (!p) p=.3;
            s = p/(2*Math.PI) * Math.asin(1.0/a);
            return a*Math.pow(2,-10*t) * Math.sin((t-s)*(2*Math.PI)/p) + 1.0;
        },
		/**
		 * @memberof easing
		 * @method inOutElastic
		 */
        inOutElastic: function(t) {
            var s=1.70158;var p=0;var a=1.0;
            if (t===0) return 0.0;  if ((t/=.5)===2) return 1.0;  if (!p) p=(.3*1.5);
            s = p/(2*Math.PI) * Math.asin(1.0/a);
            if (t < 1) return -.5*(a*Math.pow(2,10*(t-=1)) * Math.sin((t-s)*(2*Math.PI)/p));
            return a*Math.pow(2,-10*(t-=1)) * Math.sin((t-s)*(2*Math.PI)/p)*.5 + 1.0;
        },
		/**
		 * @memberof easing
		 * @method inBack
		 */
        inBack: function(t, s) {
            if (s === undefined) s = 1.70158;
            return t*t*((s+1)*t - s);
        },
		/**
		 * @memberof easing
		 * @method outBack
		 */
        outBack: function(t, s) {
            if (s === undefined) s = 1.70158;
            return ((--t)*t*((s+1)*t + s) + 1);
        },
		/**
		 * @memberof easing
		 * @method inOutBack
		 */
        inOutBack: function(t, s) {
            if (s === undefined) s = 1.70158;
            if ((t/=.5) < 1) return .5*(t*t*(((s*=(1.525))+1)*t - s));
            return .5*((t-=2)*t*(((s*=(1.525))+1)*t + s) + 2);
        },
		/**
		 * @memberof easing
		 * @method inBounce
		 */
        inBounce: function(t) {
            return 1.0 - easing.outBounce(1.0-t);
        },
		/**
		 * @memberof easing
		 * @method outBounce
		 */
        outBounce: function(t) {
            if (t < (1/2.75)) {
                return (7.5625*t*t);
                
            } else if (t < (2/2.75)) {
                return (7.5625*(t-=(1.5/2.75))*t + .75);
            } else if (t < (2.5/2.75)) {
                return (7.5625*(t-=(2.25/2.75))*t + .9375);
            } else {
                return (7.5625*(t-=(2.625/2.75))*t + .984375);
            }
        },
		/**
		 * @memberof easing
		 * @method inOutBounce
		 */
        inOutBounce: function(t) {
            if (t < .5) return easing.inBounce(t*2) * .5;
            return easing.outBounce(t*2-1.0) * .5 + .5;
        }
    }

return easing 
});;define('HostURLs',[],function(){

	URL ={
			SIMULATION_HOST_URL :"http://interactives.ck12.org",
			ADS_HOST_URL : "http://www.ck12.org/dexter",
			AUTH_HOST_URL :"https://www.ck12.org/auth/",
			USER_ACOUNT_HOST_URL :"https://www.ck12.org/account/",
			TEST_HOST_URL:"http://www.ck12.org/assessment/api/get/detail/test/",
			PUBLISH_QUES_HOST_URL:"http://www.ck12.org/assessment/api/publish/question/",
			RENDER_QUES_INSTANCE_HOST_URL:"http://www.ck12.org/assessment/api/render/questionInstance/test/",
			BROWSE_QUES_HOST_URL:"http://www.ck12.org/assessment/api/browse/info/questions/",
			TESTSCORE_DETAIL_HOST_URL:"http://www.ck12.org/assessment/api/get/detail/testscore/",
			CREATE_ASSESSMENT_QUES_HOST_URL:"http://www.ck12.org/assessment/api/create/question",
			UPDATE_ASSESSMENT_QUES_HOST_URL:"http://www.ck12.org/assessment/api/update/question/",
			SUBMIT_ASSESSMENT_ANS_HOST_URL:"http://www.ck12.org/assessment/api/submit/answer/",
			FLX_HOST_URL:"http://www.ck12.org/flx/",
//			SHARE_VIA_EMAIL:"http://frodo.ck12.org/media/common/js/views/share.via.email.view.js",
			SET_TRIAL_COOKIE:"http://www.ck12.org/assessment/api/create/cookie?"
		}; 
	

	
	
	
	
	
	
	
	
	
	
	
});;define('QuizScene', ['Scene', 'StaticObject', 'SandBoxScene', 'CommonView','QuizView','CreateQuizView','TakeQuizView'], function(Scene, StaticObject, SandBoxScene, CommonView,QuizView,CreateQuizView,TakeQuizView) {

    function QuizScene(options, data, eH) {
        Scene.apply(this, [options]);
        this.additionalScene = new SandBoxScene({
            name: "sandBoxScene"
        },data,eH);
        this.eventHandler = eH;
        this.init(data, eH);
    }

    QuizScene.prototype = Object.create(Scene.prototype);
    QuizScene.prototype.constructor = SandBoxScene;

    QuizScene.prototype.init = function(data, eH) {
        _build.apply(this, [data, eH]);
    };

    function _build(data, eH) {
        var quizscene = this;
        
        this.quizView = new QuizView(data,quizscene);
        this.createQuizView = new CreateQuizView(data,quizscene);
        this.takeQuizView = new TakeQuizView(data,quizscene);
        this.addView({
        	"quizMainScreen":this.quizView,
        	"createQuizView":this.createQuizView,
        	"takeQuizView":this.takeQuizView
        })
        
        this.showView("quizMainScreen");

    }
    
    
    
    QuizScene.prototype.render = function(container) {
        container.appendChild(this.el);
        /**change for Quiz mode*/
        this.quizView.refreshView()
    };


    return QuizScene;
});;define('RweScene', ['Scene', 'StaticObject', 'CommonView','rweFullView','rweCardsView','RweEditView'], function(Scene, StaticObject, CommonView, rweFullView, rweCardsView, RweEditView) {


    function RweScene(options, data, eH) {
        Scene.apply(this, [options]);
        this.init(data, eH);
    }

    RweScene.prototype = Object.create(Scene.prototype);
    RweScene.prototype.constructor = RweScene;

    RweScene.prototype.init = function(data, eH) {
        _build.apply(this, [data, eH]);
    };

    function _build(data, eH) {
        var rwescene = this,
            example = [],
            DATA,
            exampleNotes = [],
            paginationDotContainer,
            sampleContainer,
            background = new StaticObject({
                name: 'background',
                type: 'div',
                classes: ['background-rwe']
            });
        background.background(data.background);
        renderEl(rwescene);
        this.data = data;
        this.rweContentView = new rweCardsView(data, rwescene);
        this.fullView = new rweFullView(data.examples, rwescene);
        this.createExampleView = new RweEditView(data.packageData,data.userData);
        rwescene.addView({
            'rweContentView': this.rweContentView,
            'fullView': this.fullView,
            'editRweView': this.createExampleView
        });
        rwescene.showView('rweContentView');
        
        this.overlay = new StaticObject({name:'overlay',type:'div',classes:['rwe-overlay']});
        rwescene.add([this.overlay]);
        
        this.createExampleView.eventHandler.on('hideAddNewExample',function(){
        	rwescene.hideView('editRweView');
        	rwescene.hideOverlay();
        })
        
        this.createExampleView.eventHandler.on('refreshCardsView',function(response){
        	this.rweContentView.getExamplesData(response.response.ownerID,response.task);
        })
        
        this.eventHandler.on('showMessage',function(info){
        	eH.emit('showMessage',info);
        })
        
        this.eventHandler.on('showMessageModal',function(info){
        	eH.emit('showMessageModal',info);
        })
        
        this.eventHandler.on('hideMessageModal',function(info){
        	eH.emit('hideMessageModal',info);
        })
        
        function renderEl(rwescene) {
            rwescene.add(example.concat([background]));
        }
    }

    RweScene.prototype.showOverlay = function(){
    	this.overlay.el.style.display = 'block';
    	this.overlay.el.style.opacity = 1;
    }
    
    RweScene.prototype.hideOverlay = function(){
    	this.overlay.el.style.opacity = 0;
    	this.overlay.el.style.display = 'none';
    }

    RweScene.prototype.render = function(container) {

        container.appendChild(this.el);
    };


    return RweScene;
});;define('rweCardsView',['CommonView','Carousel','utility','ajax','HostURLs'],function(CommonView,Carousel,utility,ajax,HostURLs){
	
	function rweCardsView(data, scene) {
		var contentSource_CK12 = "CK12 Content" ,
		contentSource_community = "Community Contributed" ,
		contentSource_ALL = "All Content" ;
		this.defaultCardsCarousel = "";
		this.data = data ;
		this.dataRWE = {} ;
		this.responseRWE = { RWEs : [] } ;
		this.currentData = this.data.examples;
		this.currentPage = 0;
        this.scene = scene;
        this.flag = 0;
        this.completedTask = false;
        for (var idx = 0; idx < this.data.examples.length; idx += 1) {
        	var title = this.data.examples[idx].title.replace(/</g,"&lt;").replace(/>/g,"&gt;");
        	this.defaultCardsCarousel += '<div id="carousel-example-container-'
        			                  + idx + '" class="carousel-example-container" style="opacity: 1;"><div id="example-' 
        			                  + idx + '" class="examples example-'
        			                  + idx + '" style="background-image: url(' + this.data.examples[idx].imageUrl + ');"><div class="label">' 
        			                  + title + '</div></div></div>';
             }
        var addNewTitle = "Add similar examples." ,
        addNewIndex = "add-new" ;
    
        this.addNewExampleHTML = '<div id="addNewExampleTile" class="carousel-example-container-add-new" style="opacity: 1;"><div id="example-'
    	                        + addNewIndex + '" class="examples add-new example-'
    	                        + addNewIndex + '" ><div class="label">'
    	                        + addNewTitle + '</div></div></div>' ;
  
        this.defaultCardsCarousel =   this.addNewExampleHTML + this.defaultCardsCarousel ;
    
        var cardsContainer = '<div class="cards-container" id="cardsContainer" style="opacity: 0;">'+ this.defaultCardsCarousel +'</div>' ;
        
        var template = '<div id="contentHeader" class="content-header"><div class="level-filter hide">All Levels</div><div class="content-menus-list" id="contentMenusList"><div class="content-menu   " id="contentCK12" >'
        	            +contentSource_CK12+'</div><div class="content-menu " id="contentCommunity" >'
        	            +contentSource_community+'</div><div class="content-menu " id="contentALL">'
        	            +contentSource_ALL+'</div></div></div>' 
        	            +'<div class="msg-overlay hide">'+
							'<div class="msg-box">'+
					 			'<div class="msg-Close"></div>'+
					 			'<div class="msg-infoContainer">Are you sure you want to remove this example permanently?</div>'+
					 			'<div class="button-container ">'+
						 			'<div  class="rwe-delete submit-button report-button">REMOVE</div>'+
						 			'<div  class="rwe-delete-cancel cancel-button report-button">CANCEL</div>'+
					 			'</div>'+
					 		'</div>'+
				 		'</div>';
        
            template = template + cardsContainer ;
     
       
        CommonView.apply(this , [{
			template:template,
			name :'rweContentView',
			el: 'div',
			initialize: this.init
		}]);
        
        
        this.events = {
            'click #contentCK12' : 'showContent_CK12',
            'click #contentCommunity' : 'showContent_community',
            'click #contentALL' : 'showContent_ALL',
            'click .cards-container' : 'content_container',
            'click .rwe-delete' : 'confirmDelete',
            'click .rwe-delete-cancel' : 'closeDelete',
            'click .msg-Close' : 'closeDelete'
        };
        this.edit_example = function edit_example(e){
        	e.stopPropagation();
        	this.scene.showView('editRweView');
        	this.scene.createExampleView.update( this.currentData[e.currentTarget.parentNode.id.match(/\d+/)[0]]);
        }.bind(this);
        this.delete_example = function delete_example(e){
        	e.stopPropagation();
        	this.toBeDeletedId = this.currentData[e.currentTarget.parentNode.id.match(/\d+/)[0]]._id;
        	this.msgOverlay.classList.remove('hide');
        }.bind(this);
        
        this.confirmDelete = function confirmDelete(e){
        	e.stopPropagation();
        	var that = this,
        		id = this.toBeDeletedId;
        	ajax.sendFormData(URL.FLX_HOST_URL+"delete/rwe/" + id,{
				withCredentials : true,
				callback : function(response){
					that.closeDelete();
					that.eventHandler.emit('refreshCardsView',{response : response, task : "delete"});
					if(response.message){
						that.eventHandler.emit('showMessage',{ message : response.message});
					}else {
						that.eventHandler.emit('showMessage',{ message : "Real world example deleted successfully."});
					}
				}
			});
        }.bind(this);
        
        this.closeDelete = function closeDelete(e){
        	e&&e.stopPropagation();
        	this.msgOverlay.classList.add('hide');
        }.bind(this);
        
        this.showContent_CK12 = function showContent_CK12(e){
        	this.eventHandler.emit('showRWE_CK12');
        	this.activateContent(this.contentCK12);
        	this.currentData = this.dataRWE.ck12_data ;
        	this.update();
        }.bind(this);
       
        this.content_container = function content_container(e){
    	 
        }.bind(this);
       
        this.showContent_community = function showContent_community(e){
        	this.eventHandler.emit('showRWE_community');
        	this.activateContent(this.contentCommunity) ;
        	this.currentData = this.dataRWE.community_data ;
        	this.update();
        }.bind(this);
       
        this.showContent_ALL = function showContent_ALL(e){
        	this.eventHandler.emit('showRWE_all');
        	this.activateContent(this.contentALL) ;
        	this.currentData = this.dataRWE.ck12_data.concat(this.dataRWE.community_data) ;
        	this.update();
        }.bind(this);
        
        this.bindEventCreateExample = function bindEventCreateExample(e){
        	this.eventHandler.on('addNewExample', function() {
        		this.scene.showOverlay();
            	this.scene.showView('editRweView');
        	}.bind(this));
        }.bind(this);
        
        
        this.addNewExample = function addNewExample(e){
        	if(this.flag == 0){
        		this.bindEventCreateExample(e);
        		this.flag = 1;
        	}
        	this.eventHandler.emit('addNewExample');
        }.bind(this);
       
        this.elaborateExample = function elaborateExample(e){
    	   
        	var exampleIdx = parseInt(e.currentTarget.id.match(/\d+/)[0]);
        	this.openFullView(exampleIdx);
    	   
        }.bind(this);
       
	    this.openFullView = function openFullView(exampleIdx) {
	      
	    	if(!utility.isEmpty(this.currentData[exampleIdx])){
	    	   this.scene.fullView.update(this.currentData[exampleIdx], exampleIdx, this.currentData);
	       		this.scene.showView('fullView');
	       		this.eventHandler.emit('fullView');
	       		this.scene.fullView.updateCarousel(exampleIdx);
	    	}
	    }.bind(this);
       
	    this.elaborateContentExample = function elaborateContentExample(e){
	    	var exampleIdx = parseInt(e.currentTarget.id.match(/\d+/)[0]);
	    	this.openFullView(exampleIdx);
    	   
	    }.bind(this);
       
       
	    this.openFullViewContent = function openFullViewContent(exampleIdx) {
	    	
	    	if(!utility.isEmpty(this.currentData[exampleIdx])){
        	   this.scene.fullView.update(this.currentData[exampleIdx], exampleIdx, this.currentData);
        	   this.scene.showView('fullView');
        	   this.eventHandler.emit('fullView');
        	   this.scene.fullView.updateCarousel(exampleIdx);
	    	}
	    }.bind(this);
       
       
	    this.getExamples_RWE = function getExamples_RWE(data){
	    	this.getExamplesData(data);
	    }.bind(this);
           
    }

	
    rweCardsView.prototype = Object.create(CommonView.prototype);
    rweCardsView.prototype.constructor = rweCardsView;

    rweCardsView.prototype.showContent = function showContent(ownerID){
    	document.querySelector("#loaderScreen").classList.remove('hide');
    	setTimeout(function(){
    		if(!ownerID){
    			this.update();
    		}
    		document.querySelector("#loaderScreen").classList.add('hide');
        }.bind(this),0);
    
    };
    
    rweCardsView.prototype.init = function init(){
    	
    	this.contentMenuTabs = this.el.querySelector('.content-menu');
    	this.carouselExampleContainer = this.el.querySelector('.carousel-example-container');
		this.contentCK12 = this.el.querySelector('#contentCK12');
		this.contentCommunity = this.el.querySelector('#contentCommunity');
		this.contentALL = this.el.querySelector('#contentALL');
		this.cardsContainer = this.el.querySelector('#cardsContainer');
		this.addNewExampleTile = this.el.querySelector('#addNewExampleTile');
		this.msgOverlay = this.el.querySelector('.msg-overlay');
		this.contentCK12.classList.add('active'); // added temporarily 
		this.getExamplesData();
	
		
	};
    
	rweCardsView.prototype.activateContent =  function activateContent(currentTab){
		this.contentCommunity.classList.remove('active');
		this.contentCK12.classList.remove('active');
		this.contentALL.classList.remove('active');
 	   	currentTab.classList.add('active') ;
     };
    rweCardsView.prototype.filterContentData = function filterContentData(ownerID){
    	
    	var data_ck12 = this.data.examples ;
    	var data_community = [] ;
    	var responseLength = this.responseRWE.RWEs ? this.responseRWE.RWEs.length : 0;
    	for (var i = 0; i < responseLength ; i += 1){
    		
    		if(this.responseRWE.RWEs[i].ownerID == 3){
 	    		
 	    		 data_ck12.push(this.responseRWE.RWEs[i]) ;
 	    	}else{
 	    		
 	             data_community.push(this.responseRWE.RWEs[i]) 
 	    	}
    	}
    	
    	
    	
    	this.dataRWE.ck12_data =  data_ck12 ;
    	this.dataRWE.community_data = data_community ;
    	if(ownerID){
    		if(ownerID === "3"){
    			this.showContent_CK12();
        	} else {
        		this.showContent_community();
        	}
    	}
    }
    rweCardsView.prototype.getExamplesData =  function getExamplesData(ownerID,completedTask){
    	var paramsRWE = {
    			simID : this.data.packageData.artifactID,
    			eids :  this.data.packageData.concepts		
    	};
    	if(this.rweCarousel){
    		this.currentPage = this.rweCarousel.currentPageId;
    	}
    	
    	this._getDataRWE = function _getDataRWE(data){
    		this.filterContentData(ownerID);
    		this.showContent();
    		ajax.loadURL(URL.FLX_HOST_URL+"get/info/rwe?simID="+paramsRWE.simID+"&pageSize=100",{
    			withCredentials : true,
    			callback : this.consumeDataRWE
    		});
    	}
    	
    	this.consumeDataRWE = function consumeDataRWE(response){
    		
    		var responseRWE = (response.status === 200) ? JSON.parse(response.response) : {response : {RWEs : []}};
    		this.responseRWE = responseRWE.response ;
    		this.completedTask = completedTask;
    		this.filterContentData(ownerID);
    		
    		//this.showContent();

    		
    		
    	}.bind(this);
    	
    	this._getDataRWE();
    
    	
     };
    
    rweCardsView.prototype.update = function update() {
       this.cardsCarousel = "";
       this.newCardsCarousel = "" ;
       this.cardsContainer.innerHTML = "" ;
       this.cardsContainer.style.opacity = "1" ;
       var currentLength =  this.currentData.length,
       	   editDeleteHTML = '';  
       
       for (var idx = 0; idx < currentLength ; idx += 1) {
    	if(!this.currentData[idx].ownerID){
    		editDeleteHTML = "";
    	} else if((this.data.userData.id === parseInt(this.currentData[idx].ownerID))||(this.data.userData.role.id === 3)){
    		editDeleteHTML = '<div class="example-edit" title="edit"></div><div class="example-delete" title="delete"></div>';
    	} else{
    		editDeleteHTML = "";
    	}
    	
    	var title = this.currentData[idx].title.replace(/</g,"&lt;").replace(/>/g,"&gt;");
        this.cardsCarousel += '<div id="carousel-example-container-' + idx + '" class="carousel-example-container" style="opacity: 1;">' 
        					  + editDeleteHTML
        					  + '<div id="example-' + idx + '" class="examples example-' + idx + '" style="background-image: url(' + this.currentData[idx].imageUrl.replace(/%2BIMAGE/g,'%2BIMAGE_THUMB_POSTCARD') + ');">' + '<div class="label">' 
        					  + title 
        					  + '</div></div></div>';
        }
       
       /*for (var idx = 0; idx < this.responseRWE.RWEs.length; idx += 1) {
   		this.newCardsCarousel += '<div id="content-examples-' + idx  + '" class=" content-examples  " style="opacity: 1;">' + '<div id="example-' + idx + defaultLength + '" class="examples example-' + idx + defaultLength + '" style="background-image: url(' + this.responseRWE.RWEs[idx].imageUrl + ');">' + '<div class="label">' + this.responseRWE.RWEs[idx].title + '</div></div></div>';
       	}*/
     
        /*this.defaultCardsCarousel =   this.addNewExampleHTML + this.defaultCardsCarousel ;*/
        this.cardsCarousel = this.addNewExampleHTML + this.cardsCarousel;
   
        var rweCarouselOptions = {
        	container : this.cardsContainer,
        	children : this.cardsCarousel,
        	paginationDots : true,
        	navigationArrows : false,
        	noOfTilesPerPage : [3,2],
        	marginInPercentage : 1.35
        } ;
            
        this.rweCarousel = new Carousel(rweCarouselOptions);
        var events = {
        	'click .carousel-example-container' : this.elaborateExample  ,
			'click .content-examples' : this.elaborateContentExample  ,
			'click #addNewExampleTile' : this.addNewExample ,  
			'click .example-edit': this.edit_example,
			'click .example-delete': this.delete_example
    	} ;
    	
    	this.rweCarousel.bindEvents(events);
    	if(this.completedTask === "create"){
    		this.rweCarousel.moveToPageId(this.rweCarousel.noOfPages-1);
    		this.completedTask = undefined;
    	} else if((this.completedTask === "update")||((this.completedTask === "delete"))){
    		this.rweCarousel.moveToPageId(this.currentPage,{duration:0});
    		this.completedTask = undefined;
    	}
    	
    /*	this.rweCarousel.moveToPageId(currentPageIdx);
        currentPageIdx = Math.ceil((index-2)/3);
        this.prevIndex = index;
        */
        
       
    };
    
    return rweCardsView;
}) ;;define('rweFullView',['CommonView','Carousel','utility','HostURLs'],function(CommonView,Carousel,utility,HostURLs){
	
	function rweFullView(data, scene) {
        var template = '<div class="text-container">' + '<div class="closeIcon"></div>' + '<div class="color-bg"></div>' + '<div class="text-bg"></div>' + '<div class="text-content"><div class="title">@@title@@</div><div class="example-text">@@eleboratedText@@</div></div>' + '</div>',
            tileCarousel = '<div class="carousel-container">' + '<div class="navigate-carousel left hide"></div>' + '<div class="navigate-carousel right hide"></div>' + '<div class="more-examples"><span class="more-examples-img close-examples"></span><div class="more-examples-text">More Examples</div></div>' + '<div class="tile-carousel"></div></div>'/*<div class="full-carousel" style="width:' + data.examples.length * 30.5 + '%">'*/,
            fullview = this,
            numberOfTiles = data.length;
        this.tileCarouselHTML = "";

        for (var idx = 0; idx < data.length; idx += 1) {
        	var title = data[idx].title.replace(/</g,"&lt;").replace(/>/g,"&gt;");
            this.tileCarouselHTML += '<div id="carousel-example-container-' + idx + '" class="carousel-example-container" style="opacity: 1;">' + '<div id="example-' + idx + '" class="examples example-' + idx + '" style="background-image: url(' + data[idx].imageUrl.replace(/%2BIMAGE/g,'%2BIMAGE_THUMB_LARGE') + ');">' + '<div class="label">' + title + '</div></div></div>';
        }

        template += tileCarousel;

        CommonView.apply(this, [{
            template: template,
            name: 'rweFullView',
            el: 'div'
        }]);
        this.prevIndex = 0;
        this.scene = scene;
        this.data = data;
        this.totalShift = 0;
        this.examplesClosed = false;
        if (numberOfTiles > 4) {
            fullview.el.querySelectorAll('.navigate-carousel')[0].classList.remove('hide');
            fullview.el.querySelectorAll('.navigate-carousel')[1].classList.remove('hide');
        }
        
        
        this.events = {
            'click .closeIcon': 'closeFullView',
            'click .carousel-example-container': 'openClickedTile',
            'click .navigate-carousel.left': 'shiftCarouseLeft',
            'click .navigate-carousel.right': 'shiftCarouseRight',
            'click .more-examples': 'toggleCarousel'
        };
        this.closeFullView = function() {
            scene.hideView('fullView');
            this.eventHandler.emit('CloseRWEFullView');
        };
        
        this.openClickedTile = function(event) {
            var exampleIdx = parseInt(event.currentTarget.id.match(/\d+/)[0]);
            fullview.update(this.data[exampleIdx], exampleIdx, this.data);
            fullview.updateCarousel(exampleIdx);
        }.bind(this);
        
        this.shiftCarouseRight = function() {
        	if(this.exampleCarousel.currentPageId < this.exampleCarousel.noOfPages-1){
        		this.exampleCarousel.moveToPageId(this.exampleCarousel.currentPageId+1);
        	}
        	
        	if(this.exampleCarousel.currentPageId === this.exampleCarousel.noOfPages-1){
        		fullview.el.querySelectorAll('.navigate-carousel')[1].classList.add('hide');
        		fullview.el.querySelectorAll('.navigate-carousel')[0].classList.remove('hide');
        	}else{
        		fullview.el.querySelectorAll('.navigate-carousel')[1].classList.remove('hide');
        		fullview.el.querySelectorAll('.navigate-carousel')[0].classList.remove('hide');
        	}
        	
        	window.clearTimeout(this.timeoutVar);
        }.bind(this);
        
        this.shiftCarouseLeft = function() {
        	if(this.exampleCarousel.currentPageId > 0){
        		this.exampleCarousel.moveToPageId(this.exampleCarousel.currentPageId-1);
        	}
        	
        	if(this.exampleCarousel.currentPageId === 0){
        		fullview.el.querySelectorAll('.navigate-carousel')[0].classList.add('hide');
        		fullview.el.querySelectorAll('.navigate-carousel')[1].classList.remove('hide');
        	}else{
        		fullview.el.querySelectorAll('.navigate-carousel')[0].classList.remove('hide');
        		fullview.el.querySelectorAll('.navigate-carousel')[1].classList.remove('hide');
        	}
        	
        	window.clearTimeout(this.timeoutVar);
        }.bind(this);
        
        this.toggleCarousel = function() {
            if (fullview.examplesClosed) {
                fullview.openCarousel();
            } else {
                fullview.closeCarousel();
            }
        };
        
        this.openCarousel = function() {
            var tileCarousel = fullview.el.querySelector('.tile-carousel'),
                navigateButtons = fullview.el.querySelectorAll('.navigate-carousel');
            tileCarousel.style.webkitTransform = "translateY(0px)";
            tileCarousel.style.transform = "translateY(0px)";
            for (var i = 0, len = navigateButtons.length; i < len; i += 1) {
                navigateButtons[i].style.webkitTransform = "translateY(0px)";
                navigateButtons[i].style.transform = "translateY(0px)";
            }
            fullview.el.querySelector('.more-examples-text').style.opacity = 0;
            fullview.el.querySelector('.more-examples-img').classList.add('close-examples');
            fullview.examplesClosed = false;
        };
    }
    rweFullView.prototype = Object.create(CommonView.prototype);
    rweFullView.prototype.constructor = rweFullView;

    rweFullView.prototype.update = function(data, index, rweData) {
        /*this.el.querySelector('.text-bg').style.backgroundImage = 'url(' + data.imageUrl + ')';
        this.el.querySelector('.title').innerHTML = data.title;
        this.el.querySelector('.example-text').innerHTML = (data.eleboratedText ? data.eleboratedText : data.content);
        this.el.querySelector('.more-examples').classList.remove('hide');*/
    	
        this.tileCarouselHTML = "";
        this.data = rweData;
        for (var idx = 0; idx < this.data.length; idx += 1) {
        	if(idx != index){
        		var title = this.data[idx].title.replace(/</g,"&lt;").replace(/>/g,"&gt;");
        		this.tileCarouselHTML += '<div id="carousel-example-container-' + idx + '" class="carousel-example-container" style="opacity: 1;">' + '<div id="example-' + idx + '" class="examples example-' + idx + '" style="background-image: url(' + this.data[idx].imageUrl.replace(/%2BIMAGE/g,'%2BIMAGE_THUMB_LARGE') + ');">' + '<div class="label">' + title + '</div></div></div>';
        	}
        }
        this.openCarousel();
        this.prevIndex = index;
        var fullview = this;
        window.clearTimeout(this.timeoutVar);
        this.timeoutVar = window.setTimeout(function() {
            fullview.closeCarousel();
        }, 3000);
        _renderRWEFull.call(this,data);
    };

    rweFullView.prototype.closeCarousel = function() {
        var translateBy = 1.25*this.el.querySelector('.tile-carousel').clientHeight,
            tileCarousel = this.el.querySelector('.tile-carousel'),
            navigateButtons = this.el.querySelectorAll('.navigate-carousel');
        tileCarousel.style.webkitTransform = "translateY(" + translateBy + "px)";
        tileCarousel.style.transform = "translateY(" + translateBy + "px)";
        for (var i = 0, len = navigateButtons.length; i < len; i += 1) {
            navigateButtons[i].style.webkitTransform = "translateY(" + translateBy + "px)";
            navigateButtons[i].style.transform = "translateY(" + translateBy + "px)";
        }
        this.el.querySelector('.more-examples-img').classList.remove('close-examples');
        this.el.querySelector('.more-examples-text').style.opacity = 1;
        this.examplesClosed = true;
        window.clearTimeout(this.timeoutVar);
    };

    rweFullView.prototype.updateCarousel = function(index) {
    	this.el.querySelector('.tile-carousel').innerHTML = "";
    	var carouselOptions = {
        		container : this.el.querySelector('.tile-carousel'),
        		children : this.tileCarouselHTML,
        		paginationDots : false,
        		navigationArrows : true,
        		noOfTilesPerPage : [3,1],
        		marginInPercentage : 2
        },
        	navArrows = this.el.querySelectorAll('.navigate-carousel');
        
        this.exampleCarousel = new Carousel(carouselOptions);
    	var events = {
    			"click .carousel-example-container" : this.openClickedTile
    	},
    		currentPageId = Math.floor((((index-1)<0) ? 0 : index-1)/3);
    	
    	if(this.exampleCarousel.totalNoOfTiles === 0){
        	this.el.querySelector('.more-examples').classList.add('hide');
        }
    	this.exampleCarousel.moveToPageId(currentPageId,{duration:0});
    	navArrows[0].classList.remove('hide');
    	navArrows[1].classList.remove('hide');
		
		if(this.exampleCarousel.noOfPages > 1){
			if(this.exampleCarousel.currentPageId === 0){
				navArrows[0].classList.add('hide');
			} else if(this.exampleCarousel.currentPageId === this.exampleCarousel.noOfPages-1){
				navArrows[1].classList.add('hide');
			}
		} else {
			navArrows[0].classList.add('hide');
			navArrows[1].classList.add('hide');
		}
		
    	this.exampleCarousel.bindEvents(events);
    };
    
    function _renderRWEFull(options){
    	var backgroundEl = this.el.querySelector('.text-bg');
    	backgroundEl.removeAttribute('style');
    	this.el.querySelector('.text-container').classList.remove('hide');
    	backgroundEl.style.backgroundImage = 'url(' + options.imageUrl + ')';
    	this.el.querySelector('.title').textContent = options.title;
    	this.el.querySelector('.example-text').innerHTML = (options.eleboratedText ? options.eleboratedText : options.content);
    	
    	if(options.rweData&&(!utility.isEmpty(options.rweData))){
    		backgroundEl.style.left = parseFloat(options.rweData.left) + (1/this.scene.el.clientWidth) + '%';
        	backgroundEl.style.top = parseFloat(options.rweData.top) + (1/this.scene.el.clientHeight) + '%';
        	backgroundEl.style.width = parseFloat(options.rweData.width) + '%';
        	backgroundEl.style.height = parseFloat(options.rweData.height) + '%';
        	this.el.querySelector('.color-bg').style.backgroundColor = options.rweData.color;
    	}
    	this.el.querySelector('.example-text').ontouchmove = function(e){
    		e.stopPropagation();
    	}
    }
    
    
    return rweFullView;
});define('sim', ['SceneController', 'CoverScene', 'RweScene', 'SandBoxScene', 'VideoScene', 'QuizScene', 'ajax', 'preloadImage','utility','HostURLs'], function(SceneController, CoverScene, RweScene, SandBoxScene, VideoScene, QuizScene, ajax, preloadImage,utility,HostURLs) {

	//force login to CK12 site
    var userInfo, simReferrer = "unknown" ;
    if (document.domain.search('ck12.org') != '-1') {
        document.domain = 'ck12.org';
    }
    var loadWindow = document.getElementById('loaderWindow');
    loadWindow.style.display = "block";
   
/* 
    //Preventing unauthorized iframe usage.
	(function checkForAuthentication() {
    	var warning, template;
		try{
			if(top.document.domain && top.document.domain !== 'ck12.org'){
				top.location.replace(this.location.href);
			}
			else{
			}
		}catch(e) {
	    	   template =  "<div>"
					+"<div class='access-denied'>UNAUTHORIZED</div>"
					+"This content can't be accessed here"
					+"<br>"
					+"<a href='"+URL.SIMULATION_HOST_URL+"/simulations' target='_blank' style='color: #0098FF'>Please visit ck12.org for authorized access</a>"
					+"</div>";
				   warning = document.createElement('div');
				   warning.classList.add('unauthorized-use');
				   warning.innerHTML = template;
				   document.body.appendChild(warning);
				   throw new Error("unauthorized usage");
		}
	})();
  */  
    //Device compatibility screen
    var deviceCompatibilityAlertScreen = document.createElement('div'), minDeviceWidth = 790;
    deviceCompatibilityAlertScreen.id = "deviceCompatibilityAlert";
    deviceCompatibilityAlertScreen.classList.add('device-alert');
    deviceCompatibilityAlertScreen.classList.add('hide');
    deviceCompatibilityAlertScreen.innerHTML = '<div class="device-message"></div><div class="device-error-message">Our simulations are compatible with tablets, laptops and desktops.</div>';
    document.getElementsByTagName('body')[0].appendChild(deviceCompatibilityAlertScreen); 

    if (((window.innerWidth > window.innerHeight) && (window.innerWidth < minDeviceWidth)) || ((window.innerWidth < window.innerHeight) && (window.innerHeight < minDeviceWidth)) || navigator.userAgent.match(/(iPhone|iPodN)/g)) {
        deviceCompatibilityAlertScreen.classList.remove('hide');
        if(window.innerWidth > window.innerHeight){
        	deviceCompatibilityAlertScreen.classList.add('landscape');
        	}
        else{
        	deviceCompatibilityAlertScreen.classList.remove('landscape');
        	}  
        throw new Error("device not supported");
    }
    if(/Chromebook/.test(navigator.userAgent)){
    	if(window.innerWidth != screen.width){
    		deviceCompatibilityAlertScreen.innerHTML = '<div class="device-message"></div><div class="device-error-message">Whoops! To continue please maximize the window</div>';
    		deviceCompatibilityAlertScreen.classList.remove('hide');
//    		throw new Error('Screen size too small');
    	}
    }
   // localStorage.setItem("AuthUserInfo",JSON.stringify(a));
    var userInfoAuth = localStorage.getItem("AuthUserInfo");
    //userInfoAuth = JSON.parse(userInfoAuth)

	checkForCredentials(userInfoAuth);
    function checkForCredentials(response) {
        userInfo =response;// (response.status === 200) ? response.responseText : {};
        var res = JSON.parse(response);//(response.status === 200) ? JSON.parse(response.responseText) : {};        
        goToSim();
        
        function goToSim(){

        	var loadWindow = document.getElementById('loaderWindow');
            loadWindow.style.display = "block";
            
            var allsparkImagesFolder = "../../allspark/assets/images/",
            	allsparkImages = [
                                  'About_Active.png',
                                  'About.png',
                                  'add-new.png',
                                  'add.png',
                                  'alert.png',
                                  'arrow.gif',
                                  'avatar_female.png',
                                  'avatar_male.png',
                                  'back-active.png',
                                  'back-normal.png',
                                  'bat.png',
                                  'burger.png',
                                  'cancel.png',
                                  'check.png',
                                  'ck12-2.png',
                                  'ck12-attempted.png',
                                  'ck12-logo-300dpi.png',
                                  'ck12-logo-white.png',
                                  'ck12.png',
                                  'close-active.png',
                                  'close-default.png',
                                  'close-icon.png',
                                  'Close.png',
                                  'cog-icon.png',
                                  'Cog.png',
                                  'Color.png',
                                  'community-attempted.png',
                                  'community.png',
                                  'concept.png',
                                  'create-ques.png',
                                  'cross.gif',
                                  'cup.png',
                                  'Dislike_Active.png',
                                  'Dislike.png',
                                  'done.png',
                                  'drag-over.png',
                                  'Drag.png',
                                  'ErrorPage.png',
                                  'errorMessageRat.png',
                                  'favicon.png',
                                  'FB_Active.png',
                                  'FB.png',
                                  'Feedback.png',
                                  'graph-icon.png',
                                  'graph.png',
                                  'Group_Active.png',
                                  'Group.png',
                                  'home.png',
                                  'hs.png',
                                  'hv.png',
                                  'icons-01.png',
                                  'icons-02.png',
                                  'icons-03.png',
                                  'icons-06.png',
                                  'icons-07.png',
                                  'Img_Edit.png',
                                  'info.png',
                                  'ipad.png',
                                  'Like_Active.png',
                                  'Like.png',
                                  'loader.png',
                                  'logo-ck12.png',
                                  'Mail_Active.png',
                                  'Mail.png',
                                  'Menu.png',
                                  'more-icon.png',
                                  'next.png',
                                  'orientation.png',
                                  'pause.png',
                                  'play.png',
                                  'prev-next.png',
                                  'preview.png',
                                  'progress_pause.png',
                                  'progress_play.png',
                                  'progress_pointer.png',
                                  'ques.png',
                                  'Quest.png',
                                  'quiz-dropdown.png',
                                  'replay.png',
                                  'Report_Active.png',
                                  'Report.png',
                                  'right-ans.png',
                                  'rwe_more.png',
                                  'rwe-delete.png',
                                  'rwe-edit.png',
                                  'sending.png',
                                  'settings.png',
                                  'signout.png',
                                  'sim-logo.png',
                                  'suitcase.png',
                                  'turtle.png',
                                  'Twitt_Active.png',
                                  'Twitt.png',
                                  'Upload-2.png',
                                  'upload-image.png',
                                  'Upload.png',
                                  'walkthrough.png',
                                  'wrong-ans.png',
                                  'zoom-in.png',
                                  'zoom-out.png'                                  
                                  ];
            
            for(var i=0,l=allsparkImages.length;i<l;i++){
            	allsparkImages[i] = allsparkImagesFolder + allsparkImages[i]; 
            }
            
            images = allsparkImages.concat(images);
            
            new preLoader(images, {
                onProgress: function(src, element, index) {
                    if (element) {} else {
                        // console.error('failed ' + src);
                    }
                    var donePercent = Math.floor((100 / this.queue.length) * this.completed.length);
                    var loadElem = document.getElementById('loadingProgress');
                    loadElem.innerHTML = donePercent;
                },
                onComplete: function(loaded, errors) {
                    var loadWindow = document.getElementById('loaderWindow'), title, simDescription, simKeyWords, orientationAlertScreen, favIconLink , loaderScreen, inProgressScreen2, bodyTag, 
                        templateCss, hrefTempCss;
                        
                        
                        if(window.location.href.indexOf('referrer=') > -1){
                        	
                        	if(window.location.href.indexOf('referrer=ck12Launcher') > -1){
                        		simReferrer = "simulation_browse" ;
                        	}else if(window.location.href.indexOf('referrer=search_details') > -1){
                        		simReferrer = "search_details" ;
                        	}else if(window.location.href.indexOf('referrer=concept_details') > -1){
                        		simReferrer = "concept_details" ;
                        	}
                        	
                        	
                        }
                        
                     /*   
                        *//****** DexterJs config Update ******//*
                        dexterjs.set("config", {
                            memberID   : res.response.id ,
                        });
                        *//****** DexterJs config Update ******/
                       
                         xhr = new XMLHttpRequest();
                         packageResponse = function(responseText){
                         	//console.log(this.responseText);

                         	data = JSON.parse(responseText);
                             var conceptArray = [] ;
                             var context_eid_Array = [] ;
                             for(var i=0 ; i < data.concepts.length ; i++){
                             	conceptArray.push(data.concepts[i].name);
                             	context_eid_Array.push(data.concepts[i].encodedID);
                                  }
                             /****** DexterJs config Update ******/   
                             /*dexterjs.set("config", {
                                 clientID: 24839961 ,
                                 trackPageTime: false ,
                                 apis: {
                                     recordEvent: (URL.ADS_HOST_URL+"/record/event"),
                                     recordEventBulk: (URL.ADS_HOST_URL+"/record/event/bulk"),
                                     recordEventBulkZip: (URL.ADS_HOST_URL+"/record/event/bulk/zip")
                                 },
                                 mixins: {
                                     "artifactID" : data.artifactID ,
                                     "context_eid" : context_eid_Array[0]
                                 }
                             });
                             dexterjs.logEvent("FBS_SIMULATION", {
                                 referrer :  simReferrer 
                             });
                             /****** DexterJs config Update ******/
                             title = document.querySelector('title');
                             title.id = data.id;
                             title.innerHTML = data.name + ' (' + conceptArray.join(', ') + ') | Physics | CK-12 Exploration Series';
                             simDescription = document.querySelector('meta[name = "description"]');
                             simDescription.content = data.description;

                             simKeyWords = document.querySelector('meta[name = "keywords"]');
                             simKeyWords.content = data.concepts;

                             favIconLink = document.createElement('link');
                             favIconLink.id = 'dynamic-favicon';
                             favIconLink.rel = 'shortcut icon';
                             favIconLink.href = URL.SIMULATION_HOST_URL+"/simulations/common/allspark/assets/images/favicon.png";
                             
                             orientationAlertScreen = document.createElement('div');
                             orientationAlertScreen.id = "orientationAlertScreen";
                             orientationAlertScreen.classList.add('orientation-alert');
                             orientationAlertScreen.classList.add('hide');
                             orientationAlertScreen.innerHTML = '<div class="whoops-message">WHOOPS!</div><div class="orientation-error-message">To continue, please turn your device to landscape mode.</div>';
                                                         
                             loaderScreen = document.createElement('div');
                             loaderScreen.id = "loaderScreen";
                             loaderScreen.classList.add('loader');
                             loaderScreen.classList.add('hide');
                             loaderScreen.innerHTML = '<div class="loader-container"><div class="loader-icon"></div></div>' ;
                             
                             inProgressScreen2 = document.createElement('div');
                             inProgressScreen2.id = "inProgressScreen2";
                             inProgressScreen2.classList.add('in-progress');
                             inProgressScreen2.classList.add('hide');
                             inProgressScreen2.innerHTML = '<div class="in-progress-container-2"><div class="in-progress-icon-2"></div><div class="in-progress-message">Sending....</div></div>' ;
                             
                             bodyTag = document.querySelector('body');
                             headTag = document.querySelector('head');
                             bodyTag.appendChild(orientationAlertScreen);
                             bodyTag.appendChild(loaderScreen);
                             bodyTag.appendChild(inProgressScreen2);
                             headTag.appendChild(favIconLink);

                             templateCss = document.getElementById('templateStyleSheet');
                             hrefTempCss = '../allspark/templates/@@template-$@@/template.css';
                             if (templateCss) {
                                 templateCss.href = hrefTempCss.replace('@@template-$@@', data.data.template);
                             }
                             loadContent(data,loadWindow);
                         
                         }
						
						ajax.loadURL('../package.json', function(data) {
							//if(data.status === 200){
								packageResponse(data.responseText);
							//}
						});
                }
            });        
        }

    }


    var sceneController = new SceneController(),
        images = preloadImage,
        device = false,
        rotated = false,
        dataObj = {};

    // Add required Scenes to the SceneController
    sceneController.addScenes({
        'coverScene': CoverScene,
        'videoScene': VideoScene,
        'sandBoxScene': SandBoxScene,
        'quizScene': QuizScene,
        'rweScene': RweScene
    });

    // Loading all the required content for the simulation
    // setScene to the sceneController and pass the merged JSON data to the SceneController
    function loadContent(packageData,loadWindow) {
        var content = packageData.data;
        var windowWidth = window.innerWidth;
        var windowHeight = window.innerHeight;
        var userData = JSON.parse(userInfo).response;
            orientationAlertScreen = document.getElementById("orientationAlertScreen");
        if (windowHeight > windowWidth) {
            orientationAlertScreen.classList.remove('hide');
            rotated = true;
        }
        var isAdmin = (function(){
				for(var i in userData.roles){
						if(userData.roles[i].name=="admin" || userData.roles[i].name=="content-admin"|| userData.roles[i].name=="support-admin"/*||userData.roles[i].name=="member"*/)
							return true;
				}
			})() ||	false;
        // if(!(isAdmin) && packageData.quizMode!=="inactive"){
        	// ajax.loadURL(URL.TEST_HOST_URL+"sim%20interactive%20practice/simID/"+packageData.artifactID+"?includeItems=True",{
        		// withCredentials : true,
        		// callback :function(response){
        			// var responseQuiz = (response.status === 200) ? JSON.parse(response.response) : {response : {test :{ items:[]}}};
        				// responseQuiz = responseQuiz.response ;
        				// if(!responseQuiz.test || !responseQuiz.test.items.length){   	
        						// // quiz Mode removed for users if no items
        						// sceneController.removeScene('quizScene');  					
        				// }		
        		// }
        	// });
        //}else 
		if(packageData.quizMode==="inactive"){
        	sceneController.removeScene('quizScene');  
        }
        ajax.loadURL(content.content, function(data) {
        	if(data.readyState === 4){
	            data = JSON.parse(data.responseText);
	            dataObj.userInfo = userInfo;
	            dataObj.packageData = packageData;
	            dataObj.cover = data.scenes[0];
	            dataObj.video = data.scenes[1];
	            dataObj.sandbox = data.scenes[2];
	            dataObj.similarExamples = data.scenes[3];
	            ajax.loadURL(content.similarExamples, function(data) {
	            	if(data.readyState === 4){
		                data = JSON.parse(data.responseText);
		                dataObj.similarExamples.examples = data.examples;
		                
		                //This is required for customizable RWE (2.0)
		                dataObj.similarExamples.packageData = packageData;
		                dataObj.similarExamples.userData = JSON.parse(userInfo).response;
		                
		                /*updateJSON(dataObj);*/
		                sceneController.setScenesData(dataObj);
		
		                var windowWidth = window.innerWidth,
		                    windowHeight = window.innerHeight, windowWidthNew, sceneHolder;
		                sceneHolder = document.querySelector('#scenesController');
		                windowWidthNew = (windowHeight * 4) / 3;
		
		                sceneHolder.style.height = windowHeight + 'px';
		                sceneHolder.style.width = windowWidthNew + 'px';
		                var margin = windowWidth - windowWidthNew;
		                margin = margin / 2;
		                sceneHolder.style.margin = '0px ' + margin + 'px';
		                sceneController.setScene('coverScene');
		                loadWindow.style.display = "none";
	            	}
	            });
        	}

        });
    }
    
    
 // This functionality is deffered, as scroll in Ipad is essential in RWE page
    //Preventing IPad default functionality of window movement.
    document.ontouchmove = function(e) {
        e.preventDefault();
    };
    document.body.ontouchmove = function(e) {
        e.preventDefault();
    };
    
    if('ontouchstart' in document){
	//FastClick.attach(document.body);
	}

    //Reloading the application on every window resize
    //Checking for Portrait and Landscape mode
    window.onresize = function() {
        if (navigator.userAgent.match(/(Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini)/g) ? true : false) {
            device = true;
        }
        window.setTimeout(function() {
            var windowWidth = window.innerWidth,
                windowHeight = window.innerHeight,
                orientationAlertScreen = document.getElementById("orientationAlertScreen");
            if (windowHeight > windowWidth) {
                orientationAlertScreen.classList.remove('hide');
                rotated = true;
            } else if (!device || rotated) {
                window.location = window.location;
                orientationAlertScreen.classList.add('hide');
                rotated = false;
            }
        }, 100);

    };

});
;define('ConfigManager', ['ajax', 'utility'], function(ajax, utility) {
    var resultOutput = {
            "111": {
                "error-code": 201,
                "result": true
            },
            "110": {
                "error-code": 302,
                "result": true
            },
            "101": {
                "error-code": 202,
                "result": true
            },
            "100": {
                "error-code": 400,
                "result": true
            },
            "011": {
                "error-code": 205,
                "result": true //reset content,
            },
            "010": {
                "error-code": 200,
                "result": true //ok online version,
            },
            "001": {
                "error-code": 403,
                "result": false //bad request false.
            },
            "000": {
                "error-code": 404,
                "result": false //no access"false"
            }

        };
    window.retry = false;
    window.dismiss = false
    var timeout,	
    obj = {
			'404' : '<div id="errorView" class="hide-error-model">'
				+'<div class="error-container">'
					+'<div class="panda"></div>'
					+'<div class="error-text-container">'
						+'<div class="error-header"></div>'
						+'<div class="error-description"></div>'
					+'</div>'
					+'<div class="error-buttoncontainer"></div>'
				+'</div>'
				+'</div>',
		'403':  '<div id="errorView" class="hide-error-model">'
				+'<div class="error-container">'
					+'<div class="rat"></div>'
					+'<div class="error-text-container">'
						+'<div class="error-header"></div>'
						+'<div class="error-description"></div>'
					+'</div>'
					+'<div class="error-buttoncontainer"></div>'
				+'</div>'
				+'</div>'
	  }	;
        /***All Public variable and method******/
    function ConfigManager() {
        this.download = utility.getUrlParameters("Downloaded") ? "1" : "0";
        this.jsonObject = {};
        this.connectivityAvbl = "";
        this.outputProtocol = "";
        this.message = false;
        this.name = "";
        this.resultCode = "";
        _init.call(this);

    };

    function _init() {
        var that = this;
		ajax.loadURL('../../allspark/json/module.json',{
            "callback": function(response) {
                response = JSON.parse(response.response);
                response = response.handler[0];
                that.setJsonOutput(response);
            }

        });
    }
    ConfigManager.prototype.checkConnection =  function(){
        var xhr = new XMLHttpRequest();
		var file = "http://simdev.ck12.org/simulations/common/allspark/assets/images/arrow.gif";
        var r = Math.round(Math.random() * 10000);
        xhr.open('HEAD', file + "?subins=" + r, false);
        try {
            xhr.send();
            if (xhr.status >= 200 && xhr.status < 304) {
                return true;
            } else {
                return false;
            }
        } catch (e) {
            return false;
        }
    }
    ConfigManager.prototype.result = function(handler) {
        var connection;
        if (this.jsonObject[handler]) {
            var connctivity = this.checkConnection();
            if (connctivity == true) {
                connection = "1";
            } else if (connctivity == false) {
                connection = "0";
            } else {
                connection = "0";
            }

            this.resultCode = this.jsonObject[handler].Downloadable.concat(connection, this.download);
            this.name = this.jsonObject[handler].module;
            var outputrequire = this.setMessageProtocol(this.resultCode, this.name)
            if (outputrequire.result == false) this.messageWindow(outputrequire.message);
            return outputrequire.result;
        } else {
            return true;
        }

    }
    ConfigManager.prototype.setJsonOutput = function(response) {
        this.jsonObject = response
    }
    ConfigManager.prototype.setMessageProtocol = function(result, name) {

        this.outputProtocol = resultOutput[result]["error-code"];
        errorresult = resultOutput[result]["result"];
        var msgObject = this.setMessage(errorresult, name)
        return msgObject;
    }
    ConfigManager.prototype.setMessage = function(errorresult, name) {
        if (errorresult === false) {
            if (name === "QuizScene" || name === "CK12QuizQuestions" || name === "CoverScene" || name === "VideoScene" || name === "SandboxScene" || name === "RWEScene") {
                document.getElementById("navNext").classList.add("z-ind-1000");
                document.getElementById("navPrev").classList.add("z-ind-1000");
                this.outputProtocol = 404;
                this.message = {
                    message: "Internet connection is required to view this page.",
                    heading: "Unable to load Q&A page",
                    buttons: [{
                        name: "Retry",
                        callback: function(e) {
                        	window.retry = true;
                        	}.bind(this)}
                    ],
                    protocol: this.outputProtocol
                }
            } else {
                this.outputProtocol = 403;
                this.message = {
                    message: "Internet connection is required for this feature.",
                    heading: "You are offline",
                    buttons: [{
                        name: "Dismiss",
                        callback: function() {
                        	window.dismiss = true;
                            this.closeConfigMessage();
                        }.bind(this)
                    },
                    {
                        name: "Retry",
                        callback: function(e) {
                        	window.retry = true;
                        }.bind(this)
                    }],
                    protocol: this.outputProtocol
                }
            }
        } else {
            this.outputProtocol = this.outputProtocol;
            this.message = {
                message: "You can acces this",
                heading: "Good to go",
                buttons: [],
                protocol: this.outputProtocol
            }
        }

        return {
            "message": this.message,
            "result": errorresult
        }

    }
    ConfigManager.prototype.messageWindow = function(options) {

        if (document.getElementsByClassName("message-container")[0]) {
            this.createMessageModal(options)
        }
    }
    ConfigManager.prototype.createMessageModal = function(options){

		

			
		var xyz = options.protocol;
		document.getElementsByClassName("message-container")[0].classList.add("showConfigMsg");
		document.getElementsByClassName("message-content")[0].innerHTML = obj[xyz] ;		
		
		document.getElementById("errorView").classList.remove("hide-error-model");
		document.getElementsByClassName('error-description')[0].innerHTML = options.message;
		document.getElementsByClassName('error-header')[0].innerHTML = options.heading;
		//this.msgModalClose = document.getElementsByClassName('msg-modal-close')[0];
		//this.cross = options.cross ? options.cross:true;
		var buttonTemp = '';
		if(options.buttons){
			for(var i=0; i<options.buttons.length; i++){
				buttonTemp+= '<a href="#" class="error-button" id ="'+options.buttons[i].name+'">'+options.buttons[i].name+'</a>';
			}
			
			document.getElementsByClassName('error-buttoncontainer')[0].innerHTML = buttonTemp;
			var buttons =document.getElementsByClassName('error-button');
			for(var i=0; i<options.buttons.length; i++){
			/*	buttons[i].style.backgroundColor = options.buttons[i].backgroundColor || this.backgroundColor;
				buttons[i].style.color = options.buttons[i].color || this.fontColor;*/
				if(options.buttons[i].callback){
					buttons[i].addEventListener('click',options.buttons[i].callback,false);
				}
				
			
			}
		}
		

	/*	if(this.cross){
			this.msgModalClose.classList.remove('hide');
			this.msgModalClose.addEventListener('click',function(){
				this.closeConfigMessage();
			}.bind(this),false);
		}else{
			this.msgModalClose.classList.add('hide');
			this.msgModalClose.removeEventListener('click',function(){
				//this.eventHandler.emit('hideMessageModal');
				this.closeMessage();
			}.bind(this));
		}*/
	
    	
    }
    ConfigManager.prototype.createDummyMessageModal = function(option){


		

		
		var xyz = option;
		document.getElementsByClassName("message-content")[0].innerHTML = obj[xyz] ;		
		
		//document.getElementById("errorView").classList.remove("hide-error-model");
		document.getElementsByClassName('error-description')[0].innerHTML = "Dummy";
		document.getElementsByClassName('error-header')[0].innerHTML = "Dummy";

	
    	
    
    }
    ConfigManager.prototype.closeConfigMessage = function(){
		document.getElementsByClassName("message-container")[0].classList.remove('showConfigMsg');
		document.getElementById("errorView").classList.add("hide-error-model");
	};	

    return ConfigManager;
});
define('EventHandler',['ConfigManager'],function(ConfigManager){
	
	/**
	 * Creates EventHandler
	 * @constructor EventHandler
	 */
	var configManager = new ConfigManager();
	 function EventHandler(){
		this.eventListeners  = {}; //name of the event as key and handler array as the keyValue
		this.owner = this;
		window.falseEventArray = []; 
	//	this.analytics = new Analytics();
	}
	 
	/**
	 * listen to an event 
	 * @memberof EventHandler
	 * @method on
	 * @param {string} eventType
	 * @param {function} handler event handler function
	 * @return {this}
	 */
	EventHandler.prototype.on = function(eventType,handler,source){
		if(!this.eventListeners[eventType])
			 this.eventListeners[eventType] = [];
		var index = this.eventListeners[eventType].indexOf(handler);
		if(index < 0)
			{
				this.eventListeners[eventType].push(handler);
			}
		return this;
	};

	/**
	 * triggers an event 
	 * @memberof EventHandler
	 * @method emit
	 * @param {string} eventType
	 * @param {object | number | string} eventData
	 */
	window.flagEvent = 1;
	EventHandler.prototype.emit = function(eventType,eventData,source,e){
		if(window.retry==true){
			document.getElementById("Retry").classList.add("deActive");
			
			var connection = configManager.checkConnection();
			if(connection==true){
				document.getElementById("Retry").classList.add("deActive");
				var self = this;
				timeout = setTimeout(function(){
					configManager.closeConfigMessage();
					clearTimeout(timeout);
					self.reEmit();	
					window.retry = false;
					window.falseEventArray = [];
        	    	//self.closeConfigMessage();
        	    },1000)
			
			}else{
				timeout = setTimeout(function(){
        	    	document.getElementById("Retry").classList.remove("deActive");
        	    	clearTimeout(timeout);
        	    	window.retry = false;
        	    	//self.closeConfigMessage();
        	    },2000)
			}
			
		}else if(window.dismiss==true ){
			window.falseEventArray = [];
			window.dismiss = false;
		}
		else{
			var result = configManager.result(eventType);
			if(result === true){
				if(!eventData)
					eventData = {};
				var eventHandlers = this.eventListeners[eventType];
			    if(eventHandlers) {
			    	var handlerLength = eventHandlers.length;
			        for(var i = 0; i < handlerLength; i++) {
			        //	if(source != eventHandlers[i].source)
			             if(eventHandlers[i].call(this.owner, eventData));
			        }
		/*	        this.analytics.eventOccur({
			         'eventType':eventType,
			         'eventData':eventData,
			         'source':source
			        });*/
			    }	
			}else{
				window.falseEventArray.push(eventType);
				console.log(window.falseEventArray)
			};
		}
		
	
	};
	EventHandler.prototype.reEmit = function(eventData){
		for(var i = 0 ; i<window.falseEventArray.length;i++){
			var result = configManager.result(window.falseEventArray[i]);
			if(result === true){
				//window.falseEventArray = [];
				if(!eventData)
					eventData = {};
				var eventHandlers = this.eventListeners[window.falseEventArray[i]];
			    if(eventHandlers) {
			    	var handlerLength = eventHandlers.length;
			        for(var i = 0; i < handlerLength; i++) {
			        //	if(source != eventHandlers[i].source)
			             if(eventHandlers[i].call(this.owner, eventData));
			             
			        }
			        window.falseEventArray.splice(i,1);
		/*	        this.analytics.eventOccur({
			         'eventType':eventType,
			         'eventData':eventData,
			         'source':source
			        });*/
			    }	
			}
		}
		
	}

	/**
	 * off listen to handler
	 * @memberof EventHandler
	 * @method off
	 * @param {string} eventType
	 * @param {function} eventHandler
	 */
	EventHandler.prototype.off = function(eventType,handler){
		var handlerLength = this.eventListeners[eventType].length,index = this.eventListeners[eventType].indexOf(handler);
/*			for(var i=0; i<handlerLength; i++){
				 if(this.eventListeners[eventType][i].source === source){
					 	index = i;
					 	break;
				 }
			}*/
	    if(index >= 0) this.eventListeners[eventType].splice(index, 1); // removing the event handler from the handler array 
	};
	
	/**
	 * bind eventHandler to a specific this
	 * @memberof EventHandler
	 * @method bindThis
	 * @param {object} owner this of the required scope
	 */
	EventHandler.prototype.bindThis = function(owner){
		this.owner = owner;
	};
		
	return EventHandler;
});
;/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/.
 *
 * Owner: david@famo.us
 * @license MPL 2.0
 * @copyright Famous Industries, Inc. 2014
 */

define('Matrix',[],function() {
	/**
	 * @namespace Matrix
	 */
	 var Matrix = {};

	    // WARNING: these matrices correspond to WebKit matrices, which are
	    //    transposed from their math counterparts
	    Matrix.precision = 1e-6;
	    Matrix.identity = [1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1,0,0,0];

	    /**
	     * Multiply two or more Matrix matrix types to return a Matrix matrix.
	     *
	     * @method multiply4x4
	     * @static
	     * @param {Matrix} a left matrix
	     * @param {Matrix} b right matrix
	     * @return {Matrix} the resulting matrix
	     * @memberof Matrix
	     */
	    Matrix.multiply4x4 = function multiply4x4(a, b) {
	        return [
	            a[0] * b[0] + a[4] * b[1] + a[8] * b[2] + a[12] * b[3],
	            a[1] * b[0] + a[5] * b[1] + a[9] * b[2] + a[13] * b[3],
	            a[2] * b[0] + a[6] * b[1] + a[10] * b[2] + a[14] * b[3],
	            a[3] * b[0] + a[7] * b[1] + a[11] * b[2] + a[15] * b[3],
	            a[0] * b[4] + a[4] * b[5] + a[8] * b[6] + a[12] * b[7],
	            a[1] * b[4] + a[5] * b[5] + a[9] * b[6] + a[13] * b[7],
	            a[2] * b[4] + a[6] * b[5] + a[10] * b[6] + a[14] * b[7],
	            a[3] * b[4] + a[7] * b[5] + a[11] * b[6] + a[15] * b[7],
	            a[0] * b[8] + a[4] * b[9] + a[8] * b[10] + a[12] * b[11],
	            a[1] * b[8] + a[5] * b[9] + a[9] * b[10] + a[13] * b[11],
	            a[2] * b[8] + a[6] * b[9] + a[10] * b[10] + a[14] * b[11],
	            a[3] * b[8] + a[7] * b[9] + a[11] * b[10] + a[15] * b[11],
	            a[0] * b[12] + a[4] * b[13] + a[8] * b[14] + a[12] * b[15],
	            a[1] * b[12] + a[5] * b[13] + a[9] * b[14] + a[13] * b[15],
	            a[2] * b[12] + a[6] * b[13] + a[10] * b[14] + a[14] * b[15],
	            a[3] * b[12] + a[7] * b[13] + a[11] * b[14] + a[15] * b[15]
	        ];
	    };

	    /**
	     * Fast-multiply two or more Matrix matrix types to return a
	     *    Matrix, assuming bottom row on each is [0 0 0 1].
	     *
	     * @method multiply
	     * @static
	     * @param {Matrix} a left matrix
	     * @param {Matrix} b right matrix
	     * @return {Matrix} the resulting matrix
	     * @memberof Matrix
	     */
	    Matrix.multiply = function multiply(a, b) {
	        return [
	            a[0] * b[0] + a[4] * b[1] + a[8] * b[2],
	            a[1] * b[0] + a[5] * b[1] + a[9] * b[2],
	            a[2] * b[0] + a[6] * b[1] + a[10] * b[2],
	            0,
	            a[0] * b[4] + a[4] * b[5] + a[8] * b[6],
	            a[1] * b[4] + a[5] * b[5] + a[9] * b[6],
	            a[2] * b[4] + a[6] * b[5] + a[10] * b[6],
	            0,
	            a[0] * b[8] + a[4] * b[9] + a[8] * b[10],
	            a[1] * b[8] + a[5] * b[9] + a[9] * b[10],
	            a[2] * b[8] + a[6] * b[9] + a[10] * b[10],
	            0,
	            a[0] * b[12] + a[4] * b[13] + a[8] * b[14] + a[12],
	            a[1] * b[12] + a[5] * b[13] + a[9] * b[14] + a[13],
	            a[2] * b[12] + a[6] * b[13] + a[10] * b[14] + a[14],
	            1
	        ];
	    };

	    /**
	     * Return a Matrix translated by additional amounts in each
	     *    dimension. This is equivalent to the result of
	     *
	     *    Matrix.multiply(Matrix.translate(t[0], t[1], t[2]), m).
	     *
	     * @method thenMove
	     * @static
	     * @param {Matrix} m a matrix
	     * @param {Array.Number} t floats delta vector of length 2 or 3
	     * @return {Matrix} the resulting translated matrix
	     * @memberof Matrix
	     */
	    Matrix.thenMove = function thenMove(m, t) {
	        if (!t[2]) t[2] = 0;
	        return [m[0], m[1], m[2], 0, m[4], m[5], m[6], 0, m[8], m[9], m[10], 0, m[12] + t[0], m[13] + t[1], m[14] + t[2], 1,m[16],m[17],m[18]];
	    };

	    /**
	     * Return a Matrix atrix which represents the result of a Matrix matrix
	     *    applied after a move. This is faster than the equivalent multiply.
	     *    This is equivalent to the result of:
	     *
	     *    Matrix.multiply(m, Matrix.translate(t[0], t[1], t[2])).
	     *
	     * @method moveThen
	     * @static
	     * @param {Array.Number} v vector representing initial movement
	     * @param {Matrix} m matrix to apply afterwards
	     * @return {Matrix} the resulting matrix
	     * @memberof Matrix
	     */
	    Matrix.moveThen = function moveThen(v, m) {
	        if (!v[2]) v[2] = 0;
	        var t0 = v[0] * m[0] + v[1] * m[4] + v[2] * m[8];
	        var t1 = v[0] * m[1] + v[1] * m[5] + v[2] * m[9];
	        var t2 = v[0] * m[2] + v[1] * m[6] + v[2] * m[10];
	        return Matrix.thenMove(m, [t0, t1, t2]);
	    };

	    /**
	     * Return a Matrix which represents a translation by specified
	     *    amounts in each dimension.
	     *
	     * @method translate
	     * @static
	     * @param {Number} x x translation
	     * @param {Number} y y translation
	     * @param {Number} z z translation
	     * @return {Matrix} the resulting matrix
	     * @memberof Matrix
	     */
	    Matrix.translate = function translate(x, y, z) {
	        if (z === undefined) z = 0;
	        return [1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, x, y, z, 1];
	    };

	    /**
	     * Return a Matrix scaled by a vector in each
	     *    dimension. This is a more performant equivalent to the result of
	     *
	     *    Matrix.multiply(Matrix.scale(s[0], s[1], s[2]), m).
	     *
	     * @method thenScale
	     * @static
	     * @param {Matrix} m a matrix
	     * @param {Array.Number} s delta vector (array of floats &&
	     *    array.length == 3)
	     * @return {Matrix} the resulting translated matrix
	     * @memberof Matrix
	     */
	    Matrix.thenScale = function thenScale(m, s) {
	        return [
	            s[0] * m[0], s[1] * m[1], s[2] * m[2], 0,
	            s[0] * m[4], s[1] * m[5], s[2] * m[6], 0,
	            s[0] * m[8], s[1] * m[9], s[2] * m[10], 0,
	            s[0] * m[12], s[1] * m[13], s[2] * m[14], 1
	        ];
	    };

	    /**
	     * Return a Matrix which represents a scale by specified amounts
	     *    in each dimension.
	     *
	     * @method scale
	     * @static
	     * @param {Number} x x scale factor
	     * @param {Number} y y scale factor
	     * @param {Number} z z scale factor
	     * @return {Matrix} the resulting matrix
	     * @memberof Matrix
	     */
	    Matrix.scale = function scale(x, y, z) {
	        if (z === undefined) z = 1;
	        return [x, 0, 0, 0, 0, y, 0, 0, 0, 0, z, 0, 0, 0, 0, 1];
	    };

	    /**
	     * Return a Matrix which represents a clockwise
	     *    rotation around the x axis.
	     *
	     * @method rotateX
	     * @static
	     * @param {Number} theta radians
	     * @return {Matrix} the resulting matrix
	     * @memberof Matrix
	     */
	    Matrix.rotateX = function rotateX(theta) {
	        var cosTheta = Math.cos(theta),
	            sinTheta = Math.sin(theta);
	            return [1, 0, 0, 0, 0, cosTheta, sinTheta, 0, 0, -sinTheta, cosTheta, 0, 0, 0, 0, 1,theta,0,0];
	    };

	    /**
	     * Return a Matrix which represents a clockwise
	     *    rotation around the y axis.
	     *
	     * @method rotateY
	     * @static
	     * @param {Number} theta radians
	     * @return {Matrix} the resulting matrix
	     * @memberof Matrix
	     */
	    Matrix.rotateY = function rotateY(theta) {
	        var cosTheta = Math.cos(theta),
	            sinTheta = Math.sin(theta);
	        return [cosTheta, 0, -sinTheta, 0, 0, 1, 0, 0, sinTheta, 0, cosTheta, 0, 0, 0, 0, 1,0,theta,0];
	    };

	    /**
	     * Return a Matrix which represents a clockwise
	     *    rotation around the z axis.
	     *
	     * @method rotateZ
	     * @static
	     * @param {Number} theta radians
	     * @return {Matrix} the resulting matrix
	     * @memberof Matrix
	     */
	    Matrix.rotateZ = function rotateZ(theta) {
	        var cosTheta = Math.cos(theta),
	          sinTheta = Math.sin(theta);
	        return [cosTheta, sinTheta, 0, 0, -sinTheta, cosTheta, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1,0,0,theta];
	    };

	    /**
	     * Return a Matrix which represents composed clockwise
	     *    rotations along each of the axes. Equivalent to the result of
	     *    Matrix.multiply(rotateX(phi), rotateY(theta), rotateZ(psi)).
	     *
	     * @method rotate
	     * @static
	     * @param {Number} phi radians to rotate about the positive x axis
	     * @param {Number} theta radians to rotate about the positive y axis
	     * @param {Number} psi radians to rotate about the positive z axis
	     * @return {Matrix} the resulting matrix
	     * @memberof Matrix
	     */
	    Matrix.rotate = function rotate(phi, theta, psi) {
	        var cosPhi = Math.cos(phi),
	            sinPhi = Math.sin(phi),
	            cosTheta = Math.cos(theta),
	            sinTheta = Math.sin(theta),
	            cosPsi = Math.cos(psi),
	            sinPsi = Math.sin(psi);
	   
	        var result = [
	            cosTheta * cosPsi,
	            cosPhi * sinPsi + sinPhi * sinTheta * cosPsi,
	            sinPhi * sinPsi - cosPhi * sinTheta * cosPsi,
	            0,
	            -cosTheta * sinPsi,
	            cosPhi * cosPsi - sinPhi * sinTheta * sinPsi,
	            sinPhi * cosPsi + cosPhi * sinTheta * sinPsi,
	            0,
	            sinTheta,
	            -sinPhi * cosTheta,
	            cosPhi * cosTheta,
	            0,
	            0, 0, 0, 1,phi,theta,psi
	        ];
	        return result;
	    };

	    /**
	     * Return a Matrix which represents an axis-angle rotation
	     *
	     * @method rotateAxis
	     * @static
	     * @param {Array.Number} v unit vector representing the axis to rotate about
	     * @param {Number} theta radians to rotate clockwise about the axis
	     * @return {Matrix} the resulting matrix
	     * @memberof Matrix
	     */
	    Matrix.rotateAxis = function rotateAxis(v, theta) {
	        var sinTheta = Math.sin(theta);
	        var cosTheta = Math.cos(theta);
	        var verTheta = 1 - cosTheta; // versine of theta

	        var xxV = v[0] * v[0] * verTheta;
	        var xyV = v[0] * v[1] * verTheta;
	        var xzV = v[0] * v[2] * verTheta;
	        var yyV = v[1] * v[1] * verTheta;
	        var yzV = v[1] * v[2] * verTheta;
	        var zzV = v[2] * v[2] * verTheta;
	        var xs = v[0] * sinTheta;
	        var ys = v[1] * sinTheta;
	        var zs = v[2] * sinTheta;

	        var result = [
	            xxV + cosTheta, xyV + zs, xzV - ys, 0,
	            xyV - zs, yyV + cosTheta, yzV + xs, 0,
	            xzV + ys, yzV - xs, zzV + cosTheta, 0,
	            0, 0, 0, 1
	        ];
	        return result;
	    };

	    /**
	     * Return a Matrix which represents a Matrix matrix applied about
	     * a separate origin point.
	     *
	     * @method aboutOrigin
	     * @static
	     * @param {Array.Number} v origin point to apply matrix
	     * @param {Matrix} m matrix to apply
	     * @return {Matrix} the resulting matrix
	     * @memberof Matrix
	     */
	    Matrix.aboutOrigin = function aboutOrigin(v, m) {
	        var t0 = v[0] - (v[0] * m[0] + v[1] * m[4] + v[2] * m[8]);
	        var t1 = v[1] - (v[0] * m[1] + v[1] * m[5] + v[2] * m[9]);
	        var t2 = v[2] - (v[0] * m[2] + v[1] * m[6] + v[2] * m[10]);
	        return Matrix.thenMove(m, [t0, t1, t2]);
	    };

	    /**
	     * Return a Matrix representation of a skew Matrixation
	     *
	     * @method skew
	     * @static
	     * @param {Number} phi scale factor skew in the x axis
	     * @param {Number} theta scale factor skew in the y axis
	     * @param {Number} psi scale factor skew in the z axis
	     * @return {Matrix} the resulting matrix
	     * @memberof Matrix
	     */
	    Matrix.skew = function skew(phi, theta, psi) {
	        return [1, 0, 0, 0, Math.tan(psi), 1, 0, 0, Math.tan(theta), Math.tan(phi), 1, 0, 0, 0, 0, 1,0,0,0];
	    };

	    /**
	     * Returns a perspective Matrix matrix
	     *
	     * @method perspective
	     * @static
	     * @param {Number} focusZ z position of focal point
	     * @return {Matrix} the resulting matrix
	     * @memberof Matrix
	     */
	    Matrix.perspective = function perspective(focusZ) {
	        return [1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, -1 / focusZ, 0, 0, 0, 1,0,0,0];
	    };

	    /**
	     * Return translation vector component of given Matrix
	     *
	     * @method getTranslate
	     * @static
	     * @param {Matrix} m matrix
	     * @return {Array.Number} the translation vector [t_x, t_y, t_z]
	     * @memberof Matrix
	     */
	    Matrix.getTranslate = function getTranslate(m) {
	        return [m[12], m[13], m[14]];
	    };

	    /**
	     * Return inverse affine matrix for given Matrix.
	     *   Note: This assumes m[3] = m[7] = m[11] = 0, and m[15] = 1.
	     *   Will provide incorrect results if not invertible or preconditions not met.
	     *
	     * @method inverse
	     * @static
	     * @param {Matrix} m matrix
	     * @return {Matrix} the resulting inverted matrix
	     * @memberof Matrix
	     */
	    Matrix.inverse = function inverse(m) {
	        // only need to consider 3x3 section for affine
	        var c0 = m[5] * m[10] - m[6] * m[9];
	        var c1 = m[4] * m[10] - m[6] * m[8];
	        var c2 = m[4] * m[9] - m[5] * m[8];
	        var c4 = m[1] * m[10] - m[2] * m[9];
	        var c5 = m[0] * m[10] - m[2] * m[8];
	        var c6 = m[0] * m[9] - m[1] * m[8];
	        var c8 = m[1] * m[6] - m[2] * m[5];
	        var c9 = m[0] * m[6] - m[2] * m[4];
	        var c10 = m[0] * m[5] - m[1] * m[4];
	        var detM = m[0] * c0 - m[1] * c1 + m[2] * c2;
	        var invD = 1 / detM;
	        var result = [
	            invD * c0, -invD * c4, invD * c8, 0,
	            -invD * c1, invD * c5, -invD * c9, 0,
	            invD * c2, -invD * c6, invD * c10, 0,
	            0, 0, 0, 1
	        ];
	        result[12] = -m[12] * result[0] - m[13] * result[4] - m[14] * result[8];
	        result[13] = -m[12] * result[1] - m[13] * result[5] - m[14] * result[9];
	        result[14] = -m[12] * result[2] - m[13] * result[6] - m[14] * result[10];
	        return result;
	    };

	    /**
	     * Returns the transpose of a 4x4 matrix
	     *
	     * @method transpose
	     * @static
	     * @param {Matrix} m matrix
	     * @return {Matrix} the resulting transposed matrix
	     * @memberof Matrix
	     */
	    Matrix.transpose = function transpose(m) {
	        return [m[0], m[4], m[8], m[12], m[1], m[5], m[9], m[13], m[2], m[6], m[10], m[14], m[3], m[7], m[11], m[15]];
	    };

	    function _normSquared(v) {
	        return (v.length === 2) ? v[0] * v[0] + v[1] * v[1] : v[0] * v[0] + v[1] * v[1] + v[2] * v[2];
	    }
	    function _norm(v) {
	        return Math.sqrt(_normSquared(v));
	    }
	    function _sign(n) {
	        return (n < 0) ? -1 : 1;
	    }

	    /**
	     * Decompose Matrix into separate .translate, .rotate, .scale,
	     *    and .skew components.
	     *
	     * @method interpret
	     * @static
	     * @param {Matrix} M tranform matrix
	     * @return {Object} matrix spec object with component matrices .translate,
	     *    .rotate, .scale, .skew
	     *  @memberof Matrix
	     */
	    Matrix.interpret = function interpret(M) {

	        // QR decomposition via Householder reflections
	        //FIRST ITERATION

	        //default Q1 to the identity matrix;
	        var x = [M[0], M[1], M[2]];                // first column vector
	        var sgn = _sign(x[0]);                     // sign of first component of x (for stability)
	        var xNorm = _norm(x);                      // norm of first column vector
	        var v = [x[0] + sgn * xNorm, x[1], x[2]];  // v = x + sign(x[0])|x|e1
	        var mult = 2 / _normSquared(v);            // mult = 2/v'v

	        //bail out if our Matrix is singular
	        if (mult >= Infinity) {
	            return {translate: Matrix.getTranslate(M), rotate: [0, 0, 0], scale: [0, 0, 0], skew: [0, 0, 0]};
	        }

	        //evaluate Q1 = I - 2vv'/v'v
	        var Q1 = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1];

	        //diagonals
	        Q1[0]  = 1 - mult * v[0] * v[0];    // 0,0 entry
	        Q1[5]  = 1 - mult * v[1] * v[1];    // 1,1 entry
	        Q1[10] = 1 - mult * v[2] * v[2];    // 2,2 entry

	        //upper diagonal
	        Q1[1] = -mult * v[0] * v[1];        // 0,1 entry
	        Q1[2] = -mult * v[0] * v[2];        // 0,2 entry
	        Q1[6] = -mult * v[1] * v[2];        // 1,2 entry

	        //lower diagonal
	        Q1[4] = Q1[1];                      // 1,0 entry
	        Q1[8] = Q1[2];                      // 2,0 entry
	        Q1[9] = Q1[6];                      // 2,1 entry

	        //reduce first column of M
	        var MQ1 = Matrix.multiply(Q1, M);

	        //SECOND ITERATION on (1,1) minor
	        var x2 = [MQ1[5], MQ1[6]];
	        var sgn2 = _sign(x2[0]);                    // sign of first component of x (for stability)
	        var x2Norm = _norm(x2);                     // norm of first column vector
	        var v2 = [x2[0] + sgn2 * x2Norm, x2[1]];    // v = x + sign(x[0])|x|e1
	        var mult2 = 2 / _normSquared(v2);           // mult = 2/v'v

	        //evaluate Q2 = I - 2vv'/v'v
	        var Q2 = [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1];

	        //diagonal
	        Q2[5]  = 1 - mult2 * v2[0] * v2[0]; // 1,1 entry
	        Q2[10] = 1 - mult2 * v2[1] * v2[1]; // 2,2 entry

	        //off diagonals
	        Q2[6] = -mult2 * v2[0] * v2[1];     // 2,1 entry
	        Q2[9] = Q2[6];                      // 1,2 entry

	        //calc QR decomposition. Q = Q1*Q2, R = Q'*M
	        var Q = Matrix.multiply(Q2, Q1);      //note: really Q transpose
	        var R = Matrix.multiply(Q, M);

	        //remove negative scaling
	        var remover = Matrix.scale(R[0] < 0 ? -1 : 1, R[5] < 0 ? -1 : 1, R[10] < 0 ? -1 : 1);
	        R = Matrix.multiply(R, remover);
	        Q = Matrix.multiply(remover, Q);

	        //decompose into rotate/scale/skew matrices
	        var result = {};
	        result.translate = Matrix.getTranslate(M);
	        result.rotate = [Math.atan2(-Q[6], Q[10]), Math.asin(Q[2]), Math.atan2(-Q[1], Q[0])];

	        if (!result.rotate[0]) {
	            result.rotate[0] = 0;
	            result.rotate[2] = Math.atan2(Q[4], Q[5]);
	        }
	        
	        for(var i in result.rotate){
	        	var direction = _sign(M[16+parseInt(i)]),
	        	 noOfTurns = parseInt(Math.abs(M[16+parseInt(i)]/(2*Math.PI)));
	        	if(direction<0){
	        		if(result.rotate[i]>0){
	        		noOfTurns = noOfTurns <1?1:noOfTurns;
	           		result.rotate[i] -= (2*noOfTurns)*Math.PI;
	        		}
	        		else if(noOfTurns >=1){
		        		result.rotate[i] -= (2*noOfTurns)*Math.PI;
	        		}
	        	}else if(direction>0){
	        		if(result.rotate[i]<0){
	        			noOfTurns = noOfTurns <1?1:noOfTurns;
	        		result.rotate[i] += (2*noOfTurns)*Math.PI;
	        		}
	        		else if(noOfTurns >=1){
		        		result.rotate[i] += (2*noOfTurns)*Math.PI;
	        		}
	        	}
	        }
	        result.scale = [R[0], R[5], R[10]];
	        result.skew = [Math.atan2(R[9], result.scale[2]), Math.atan2(R[8], result.scale[2]), Math.atan2(R[4], result.scale[0])];

/*	        //double rotation workaround
	        if (Math.abs(result.rotate[0]) + Math.abs(result.rotate[2]) > 1.5 * Math.PI) {
	            result.rotate[1] = Math.PI - result.rotate[1];
	            if (result.rotate[1] > Math.PI) result.rotate[1] -= 2 * Math.PI;
	            if (result.rotate[1] < -Math.PI) result.rotate[1] += 2 * Math.PI;
	            if (result.rotate[0] < 0) result.rotate[0] += Math.PI;
	            else result.rotate[0] -= Math.PI;
	            if (result.rotate[2] < 0) result.rotate[2] += Math.PI;
	            else result.rotate[2] -= Math.PI;
	        }*/

	        return result;
	    };

	    /**
	     * Weighted average between two matrices by averaging their
	     *     translation, rotation, scale, skew components.
	     *     f(M1,M2,t) = (1 - t) * M1 + t * M2
	     *
	     * @method average
	     * @static
	     * @param {Matrix} M1 f(M1,M2,0) = M1
	     * @param {Matrix} M2 f(M1,M2,1) = M2
	     * @param {Number} t
	     * @return {Matrix} resulting matrix
	     * @memberof Matrix
	     */
	    Matrix.average = function average(M1, M2, t) {
	        t = (t === undefined) ? 0.5 : t;
	        var specM1 = Matrix.interpret(M1);
	        var specM2 = Matrix.interpret(M2);

	        var specAvg = {
	            translate: [0, 0, 0],
	            rotate: [0, 0, 0],
	            scale: [0, 0, 0],
	            skew: [0, 0, 0]
	        };

	        for (var i = 0; i < 3; i++) {
	            specAvg.translate[i] = (1 - t) * specM1.translate[i] + t * specM2.translate[i];
	            specAvg.rotate[i] = (1 - t) * specM1.rotate[i] + t * specM2.rotate[i];
	            specAvg.scale[i] = (1 - t) * specM1.scale[i] + t * specM2.scale[i];
	            specAvg.skew[i] = (1 - t) * specM1.skew[i] + t * specM2.skew[i];
	        }
	        return Matrix.build(specAvg);
	    };

	    /**
	     * Compose .translate, .rotate, .scale, .skew components into
	     * Matrix matrix
	     *
	     * @method build
	     * @static
	     * @param {matrixSpec} spec object with component matrices .translate,
	     *    .rotate, .scale, .skew
	     * @return {Matrix} composed martix
	     * @memberof Matrix
	     */
	    Matrix.build = function build(spec) {
	        var scaleMatrix = Matrix.scale(spec.scale[0], spec.scale[1], spec.scale[2]);
	        var skewMatrix = Matrix.skew(spec.skew[0], spec.skew[1], spec.skew[2]);
	        var rotateMatrix = Matrix.rotate(spec.rotate[0], spec.rotate[1], spec.rotate[2]);
	        return Matrix.thenMove(Matrix.multiply(Matrix.multiply(rotateMatrix, skewMatrix), scaleMatrix), spec.translate);
	    };

	    /**
	     * Determine if two Matrixs are component-wise equal
	     *   Warning: breaks on perspective Matrixs
	     *
	     * @method equals
	     * @static
	     * @param {Matrix} a matrix
	     * @param {Matrix} b matrix
	     * @return {boolean}
	     * @memberof Matrix
	     */
	    Matrix.equals = function equals(a, b) {
	        return !Matrix.notEquals(a, b);
	    };

	    /**
	     * Determine if two Matrixs are component-wise unequal
	     *   Warning: breaks on perspective Matrixs
	     *
	     * @method notEquals
	     * @static
	     * @param {Matrix} a matrix
	     * @param {Matrix} b matrix
	     * @return {boolean}
	     * @memberof Matrix
	     */
	    Matrix.notEquals = function notEquals(a, b) {
	        if (a === b) return false;
	        if (!(a && b)) return true;

	        // shortci
	        return !(a && b) ||
	            a[12] !== b[12] || a[13] !== b[13] || a[14] !== b[14] ||
	            a[0] !== b[0] || a[1] !== b[1] || a[2] !== b[2] ||
	            a[4] !== b[4] || a[5] !== b[5] || a[6] !== b[6] ||
	            a[8] !== b[8] || a[9] !== b[9] || a[10] !== b[10];
	    };

	    /**
	     * Constrain angle-trio components to range of [-pi, pi).
	     *
	     * @method normalizeRotation
	     * @static
	     * @param {Array.Number} rotation phi, theta, psi (array of floats
	     *    && array.length == 3)
	     * @return {Array.Number} new phi, theta, psi triplet
	     *    (array of floats && array.length == 3)
	     *    @memberof Matrix
	     */
	    Matrix.normalizeRotation = function normalizeRotation(rotation) {
	        var result = rotation.slice(0);
	        if (result[0] === Math.PI * 0.5 || result[0] === -Math.PI * 0.5) {
	            result[0] = -result[0];
	            result[1] = Math.PI - result[1];
	            result[2] -= Math.PI;
	        }
	        if (result[0] > Math.PI * 0.5) {
	            result[0] = result[0] - Math.PI;
	            result[1] = Math.PI - result[1];
	            result[2] -= Math.PI;
	        }
	        if (result[0] < -Math.PI * 0.5) {
	            result[0] = result[0] + Math.PI;
	            result[1] = -Math.PI - result[1];
	            result[2] -= Math.PI;
	        }
	        while (result[1] < -Math.PI) result[1] += 2 * Math.PI;
	        while (result[1] >= Math.PI) result[1] -= 2 * Math.PI;
	        while (result[2] < -Math.PI) result[2] += 2 * Math.PI;
	        while (result[2] >= Math.PI) result[2] -= 2 * Math.PI;
	        return result;
	    };

	    Matrix.formatCSS = function(m) {
	        var n = m.slice(0);
	        for(var i = 0; i < n.length; i++) if(n[i] < 0.000001 && n[i] > -0.000001) n[i] = 0;
	        return 'matrix3d(' + n.join() + ')';
	    };
	    
	    /**
	     * (Property) Array defining a translation forward in z by 1
	     *
	     * @property {array} inFront
	     * @static
	     * @final
	     * @memberof Matrix
	     */
	    Matrix.inFront = [1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 1e-3, 1];

	    /**
	     * (Property) Array defining a translation backwards in z by 1
	     *
	     * @property {array} behind
	     * @static
	     * @final
	     * @memberof Matrix
	     */
	    Matrix.behind = [1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, -1e-3, 1];
 return Matrix;
});
;define('Scene', ['EventHandler', 'View', 'ViewController', 'SimObject', 'Slider', 'Graph', 'Matrix', 'Toggle'], function(eventHandler, View, ViewController, SimObject, Slider, Graph, Matrix, Toggle) {


    /**
     *  Creates instance of scene
     *  @constructor Scene
     */
    function Scene(options) {
        this.options = {};
        this.options.name =  options.name || "";
        this.view = new View(options);
        this.sliders = [];
        this.toggles = [];
        this.graphs = [];
        this.actors = [];
        this.groups = {};
        this.groupArray = [];
        this.utils = [];
        this._size = [];
        this.eventHandler = new eventHandler();
        this.eventForwader = function(event) {
            this.eventHandler.emit(event.type, event);
        }.bind(this);

        this.on('resize', this.reSize, this);
        this.set();
        ViewController.apply(this, [this.el]);
    }

    Scene.prototype = Object.create(ViewController.prototype);
    Scene.prototype.constructor = Scene;


    Scene.prototype.bindEvents = function(type, target) {
        target.addEventListener(type, this.eventForwader);
    };

    Scene.prototype.unBindEvents = function(type, target) {
        target.removeEventListener(type, this.eventForwader);
    };

    Scene.prototype.on = function(type, handler, simObject) {
        //this.bindEvents(type,el);
        this.eventHandler.on(type, handler, simObject);
    };

    Scene.prototype.off = function(type, el, handler, simObject) {
        //this.unBindEvents(type,el);
        this.eventHandler.off(type, handler, simObject);
    };

    Scene.prototype.emit = function(eventType, eventData, simObject) {
        this.eventHandler.emit(eventType, eventData, simObject);
    };

    /**
     * add an objects to the scene(simObject, Graph, Slider,Utility)
     * @memberof Scene
     * @method addSimObject
     * @param {SimObject} SimObject
     */
    Scene.prototype.addsimObject = function(simObject) {
        if (simObject instanceof SimObject)
            this.actors.push(simObject);
        else if (simObject instanceof Slider)
            this.sliders.push(simObject);
        else if (simObject instanceof Toggle)
            this.toggles.push(simObject);
        else if (simObject instanceof Graph)
            this.graphs.push(simObject);
        else
            this.utils.push(simObject);
        simObject.scene = this.el;
        simObject.render(this.el);
    };

    /**
     * @memberof Scene
     * @method add
     * @param {simObject | simObject[]} takes array of simObjects or a single simObject
     */
    Scene.prototype.add = function(simObjects) {
        if (simObjects instanceof Array)
            for (var i=0; i < simObjects.length; i++) {
                this.addsimObject(simObjects[i]);
            } else {
            this.addsimObject(simObjects)
        }
    };

    Scene.prototype.createGroup = function(group, identity) {
        var length = group.length;
        this.groups[identity.name] = [];
        this.groupArray.push(identity.name);
        for (var i = 0; i < length; i++)
            this.groups[identity.name].push(group[i]);
    };

    /**
     * remove an objects from the scene(simObject, graph, slider)
     * @memberof Scene
     * @method removesimObject
     * @param {simObject} simObject
     */
    Scene.prototype.removesimObject = function(simObject) {
        var index;
        if (simObject instanceof SimObject) {
            index = this.actors.indexOf(simObject);
            this.actors.splice(index, 1);
        } else if (simObject instanceof Graph) {
            index = this.graphs.indexOf(simObject);
            this.actors.splice(index, 1);
        } else if (simObject instanceof Slider) {
            index = this.sliders.indexOf(simObject);
            this.actors.splice(index, 1);
        } else if (simObject instanceof Toggle) {
            index = this.toggles.indexOf(simObject);
            this.actors.splice(index, 1);
        }
        


        var simObjectElem = document.getElementById(simObject.name);
        simObjectElem.parentNode.removeChild(simObjectElem);
    };

    Scene.prototype.set = function() {
        this.view.set();
        this.el = this.view.el;
        this.bindEvents('resize', window);
        this.eventHandler.bindThis(this);
    };

    Scene.prototype.render = function(container) {
        container.innerHTML = this.el;
    };

    Scene.prototype.getSize = function() {
        return this._size;
    };

    Scene.prototype.setSize = function(size) {
        if (size instanceof Array) {
            this._size[0] = size[0];
            this._size[1] = size[1];
        }
    };

    Scene.prototype.reSize = function() {
        this._size[0] = this.el.clientWidth;
        this._size[1] = this.el.clientHeight;
    };

    Scene.prototype.resetActors = function(actors) {
        if (actors instanceof Array)
            for (var x = 0; x < actors.length;x++) {
                actors[x].resetTransform();
            }
    };

    Scene.prototype.pause = function() {
    	var length = this.actors.length;
        for (var x = 0; x < length; x++) {
            this.actors[x].pause();
        }
        length = this.utils.length;
        for (var x = 0; x < length; x++) {
            if (this.utils[x].pause){
                this.utils[x].pause();	
            }
        }
    };

    Scene.prototype.update = function() {
        var self = this;
        this.actors.forEach(function(actor) {
            var transformation = actor.manipulate();
            if (self._size.length === 0) {
                self._size[0] = self.el.clientWidth;
                self._size[1] = self.el.clientHeight;
            }
            if (transformation.origin) {
                var origin = transformation.origin,
                    el = actor.el,
                    size = [el.clientWidth, el.clientHeight],
                    pos = [(origin[0] * self._size[0]) - (origin[0] * size[0]), (origin[1] * self._size[1]) - (origin[1] * size[1]), 0];
                transformation.transform = Matrix.thenMove(transformation.transform, pos);
            }
            actor.update(transformation.transform, transformation.size, transformation.opacity, transformation.origin);
        });
        
        for (var x = 0; x < this.utils.length; x++) {
            if (this.utils[x].update){
                this.utils[x].update();	
            }
        }
    };



    return Scene;
});;define('SceneController', ['EventHandler', 'utility', 'ViewController', 'ChallengeView', 'MoreView', 'ToolBarView', 'AboutView' , 'ConceptView' , 'ReportIssueView', 'ReplayView', 'NavView', 'UserProfileView','MessageView','MessageModalView','WalkthroughVideo','HostURLs','ShareViaEmail'/*'http://www.ck12.org/media/common/js/views/share.via.email.view.js'*/], function(eventHandler, utility, ViewController, ChallengeView, MoreView, ToolBarView, AboutView, ConceptView, ReportIssueView,ReplayView, NavView, UserProfileView,MessageView,MessageModalView,WalkthroughVideo,HostURLs,shareViaEmail) {

 
	//require(['//dvninqhj78q4x.cloudfront.net/dexterjs/dexterjs.min.js']);
    var isPlay = false, timeSpent = 0, startTime = Date.now(), currentTime = 0, visitedScene = '', navReferrer,
	    pageTypes = {
		"coverScene":"coverPage",
		"videoScene":"coverVideo",
		"sandBoxScene":"sandBox",
		"quizScene":"quiz",
		"rweScene":"RWE"
    	};
    var simUrlString = window.location.href ;
	simUrlString = simUrlString.slice(0,simUrlString.indexOf('/app'));
	var simulationName = simUrlString.slice(simUrlString.lastIndexOf('/')+1 , simUrlString.length);
	var simSource = "?referrer=simulation&simulationName="+simulationName;
	var interactivesBrowse = "http://interactives.ck12.org/simulations/index.html"
	var referrer;
    /**
     * creates Instanceof SceneController
     * @constructor SceneController
     */
    function SceneController() {
        this.scenes = [];
        this.sceneViews = {}; //scene-name + render function
        this.sceneObjects = {};
        this.sceneIndex = 0;
        this.scenesData = {};
        this.userProfile = false;
        this.eventHandler = new eventHandler();
        this.sceneContainer = document.createElement('div');
        ViewController.apply(this, [this.sceneContainer]);
        this.localStorageSupport = utility.isLocalStorage();
        this.backURL = ( utility.getUrlParameters("backUrl")  || interactivesBrowse )+ simSource ;
    }


    SceneController.prototype = Object.create(ViewController.prototype);
    SceneController.prototype.constructor = SceneController;
    


    /**
     * adds a scene to the sceneController
     * @memberof SceneController
     * @method addScene
     * @param {string} scene name of the scene
     * @param {function} constructor constructor of the scene
     */
    SceneController.prototype.addScene = function(scene, sceneObject) {
        this.sceneViews[scene] = sceneObject;
        this.scenes.push(scene);
    };

    /**
     * adds scenes to the sceneController
     * @memberof SceneController
     * @method addScenes
     * @param {scenes[]} scenes array of scenes
     */
    SceneController.prototype.addScenes = function(scenes) {
        for (var sceneName in scenes){
        	if (scenes.hasOwnProperty(sceneName)) {
            this.addScene(sceneName, scenes[sceneName]);	
        	}
        }
    };


    /**
     * remove scene from the sceneController
     * @memberof SceneController
     * @method removeScene
     * @param {string} scene name of the scene to be removed
     */
    SceneController.prototype.removeScene = function(scene) {
        var index = this.scenes.indexOf(scene);
        this.scenes.splice(index, 1);
        delete this.sceneViews[scene];
    };

    /**
     * navigate to the next scene
     * @memberof SceneController
     * @method next
     */
    SceneController.prototype.next = function() {
    	//**change for Quiz mode*//
    	if(document.getElementById("errorView") != null){
    		window.falseEventArray = [];
    		document.getElementById("MessageView").classList.remove("showConfigMsg");
        	document.getElementById("errorView").classList.add("hide-error-model");
        	document.getElementById("navNext").classList.remove("z-ind-1000");
    		document.getElementById("navPrev").classList.remove("z-ind-1000");
    	}
    	if(!isPlay){
    		navReferrer = "rightArrow" ; 
    	
    	}else{
    		
    		navReferrer = "playButton" ; 
    	}
    	//_dexterEvents.call(this,navReferrer);
    	this.sceneIndex++;
        
        this.viewObjs['NavView'].next.classList.remove('bounceActive');
        this.viewObjs['NavView'].next.classList.remove('navigationBounce');
        if (this.sceneIndex === 1 && !isPlay) {
            this.sceneIndex++;
        } else {
            isPlay = false;
            this.viewObjs['NavView'].next.classList.add('bounceActive');
        }
        if (this.sceneIndex === this.scenes.length - 1 || this.sceneIndex === 1) {
            this.viewObjs['NavView'].hide('prev');
        }
        if (this.sceneIndex === this.scenes.length) {
            this.sceneIndex--;
        } else {
            this.setScene(this.scenes[this.sceneIndex]);
            if (this.sceneIndex != 1) {
                this.viewObjs['NavView'].show('prev');
            }
        }
        if (this.sceneIndex === 2) {} else {}
    };

    /**
     * navigate to the previoud scene
     * @memberof SceneController
     * @method prev
     */
    SceneController.prototype.prev = function() {
    	//**change for Quiz mode*//
    	if(document.getElementById("errorView") != null){
    		window.falseEventArray = [];
    		document.getElementById("MessageView").classList.remove("showConfigMsg");
        	document.getElementById("errorView").classList.add("hide-error-model");
        	document.getElementById("navNext").classList.remove("z-ind-1000");
    		document.getElementById("navPrev").classList.remove("z-ind-1000");
    	}
    	navReferrer = "leftArrow" ;
    	//_dexterEvents.call(this,navReferrer);
        this.sceneIndex--;

        if (this.sceneIndex === 1) {
            this.sceneIndex--;
        }
        if (this.sceneIndex === 0) {
            this.viewObjs['NavView'].hide('prev');
        }
        if (this.sceneIndex < 0) {
            this.sceneIndex++;
        } else {
            this.setScene(this.scenes[this.sceneIndex]);
            this.viewObjs['NavView'].show('next');
        }

        if (this.sceneIndex === 2) {} else {}
    };

    SceneController.prototype.restart = function() {
        this.setScene(this.scenes[this.sceneIndex]);
    };

    SceneController.prototype.setSceneOrder = function(scenes) {
        this.scenes = scenes;
    };

    /**
     * get the current scene
     * @method getScene
     * @memberof SceneController
     * @return {object} currentScene
     */
    SceneController.prototype.getScene = function() {
        return this.currentScene;
    };

    /**
     * stores data in the localStorage
     * @memberof SceneController
     * @method setStorages
     * @param {string} key
     * @param {number | string | object | array} value value to the key
     */
    SceneController.prototype.setStorage = function(key, value) {
        if (this.localStorageSupport) {
            localStorage.setItem(key, value);
        }
    };

    SceneController.prototype.setCookie = function(key, value) {
        if (this) {
            document.cookie = key + " = " + value + "; expires=0;";
        }
    };
    SceneController.prototype.getCookie = function(c_name) {
    	var c_start, c_end;
        if (document.cookie.length > 0) {
            c_start = document.cookie.indexOf(c_name + "=");
            if (c_start !== -1) {
                c_start = c_start + c_name.length + 1;
                c_end = document.cookie.indexOf(";", c_start);
                if (c_end === -1) c_end = document.cookie.length;
                return decodeURI(document.cookie.substring(c_start, c_end));
            }
        }
        return "";
    };

    /**
     * get the value of the particular key stored in the local storage
     * @memberof SceneController
     * @method getStorage
     * @return{number | string | object | array} value value of the key
     */
    SceneController.prototype.getStorage = function(key) {
        if (this.localStorageSupport) {
            return localStorage.getItem(key);
        }
    };

    /**
     * removes data from the localStorage
     * @memberof SceneController
     * @method removeStorage
     * @param {string} key
     */
    SceneController.prototype.removeStorage = function(key) {
        if (this.localStorageSupport) {
            localStorage.removeItem(key);
        }
    };

    /**
     * sets the scene
     * @memberof SceneController
     * @method setScene
     * @param {string} scene name of the scene to be set
     */

    SceneController.prototype.setScene = function(scene) {
        this.currentData = undefined;
        if (scene === "sandBoxScene") {
            this.currentData = this.scenesData.sandbox;
        }
        else if (scene === "quizScene") {
            this.currentData = this.scenesData.similarExamples;
        }else if (scene === "rweScene") {
            this.currentData = this.scenesData.similarExamples;
        } else if (scene === "coverScene") {
            this.currentData = this.scenesData.cover;
        } else if (scene === "videoScene") {
            this.currentData = this.scenesData.video;
        }
        var sceneObject = this.sceneViews[scene];
        this.sceneIndex = this.scenes.indexOf(scene);
        this.currentScene = scene;

        if (this.sceneIndex === this.scenes.length - 1) {
            this.viewObjs['NavView'].hide('next');
        } else if (this.sceneIndex === 0) {
            this.viewObjs['NavView'].hide('prev');
        }

        if (!this.sceneObjects[scene]) {
            this.activesceneObject = new sceneObject({
                name: scene
            }, this.currentData, this.eventHandler);
            this.sceneObjects[scene] = this.activesceneObject;
        } else {
            this.activesceneObject = this.sceneObjects[scene];
        }
        this.viewObjs['ToolBarView'].updateView(scene);
        this.activateScene(scene);
        //sharePlane(this.scenesData.userInfo);
       
    };

    /**
     * activate the given scene,setScene method calls this method internally
     * @memberof SceneController
     * @method activateScene
     * @param {string} scene name of the scene to be activated
     */
    SceneController.prototype.activateScene = function(scene) {
        this.reset();
        if (scene === 'sandBoxScene') {
            this.showView('ChallengeView');
        }
        this.setCookie(document.querySelector('title').id, scene);
        this.activeScene = this.activesceneObject;
        this.activeScene.render(this.scenesController, this.currentData);
        this.eventHandler.emit('render' + scene);
    };

    /**
     * reset the scene controller. empties the content of the sceneController
     * @memberof SceneController
     * @method reset
     */
    SceneController.prototype.reset = function() {
        utility.emptyElement(this.scenesController);
        utility.emptyElementFromFirstNode(this.sceneContainer);
        this.showView('ToolBarView');
        this.showView('MoreView');
        this.showView('NavView');
        this.showView('MessageView');
        if (this.userProfile) {
            this.showView('UserProfileView');
        }
    };

    SceneController.prototype.setScenesData = function(data) {
        this.scenesData = data;
        _setupController.call(this);
    };

    SceneController.prototype.on = function(eventType, Handler) {
        this.eventHandler.on(eventType, Handler, this);
    };

    SceneController.prototype.off = function(eventType, Handler) {
        this.eventHandler.off(eventType, Handler, this);
    };

    

    /**
     * gives the time spent in scene. 
     * @memberof Private
     * @method _timeSpentInScene
     */

    function _timeSpentInScene(){
	    prevScene = pageTypes[this.scenes[this.sceneIndex]],
	 	currentTime = Date.now();
	 	timeSpent = (currentTime - startTime)/1000;
	 	startTime = currentTime;
    }
    
    /**
     * Logs the ADS events 
     * @memberof Private
     * @method _dexterEvents
     */
    
    
    function _dexterEvents(){/*
    	_timeSpentInScene.call(this)
  	  	dexterjs.logEvent("FBS_SIMULATION_TIMESPENT", {
            referrer : navReferrer ,
            pageType : prevScene ,
            timeSpent : timeSpent 
        });
    */}
    
    
    
    
    
    
    function _setupController() {
    	
    	var info = JSON.parse(this.scenesData.userInfo);
    	info = info.response;
    	
        this.scenesController = document.createElement('div');
        this.scenesController.classList.add('scenes-controller');
        this.scenesController.id = 'scenesController';
        this.sceneContainer.appendChild(this.scenesController);
        this.ChallengeView = new ChallengeView(this.scenesData.sandbox.question);
        this.moreView = new MoreView(info);
        this.AboutView = new AboutView(this.scenesData.packageData);
        this.ConceptView = new ConceptView(this.scenesData.packageData);
        this.ReportIssueView = new ReportIssueView(this.scenesData.packageData);
        this.navView = new NavView();
        this.messageView = new MessageView();
        this.messageModalView = new MessageModalView();
        this.WalkthroughVideo = new WalkthroughVideo(this.scenesData.similarExamples);
        /**Adding Replay View*/
        toolbarOptions = {
           /* 'walkThroughURL': this.scenesData.sandbox.walkThrough*/
        };
       /*adding walkthrough view*/
        /*if(this.scenesData.sandbox.walkThrough){*/
        //add it for ADMIN 
       
      /*  }*/
        /**Adding Replay View*/
        this.replayView = new ReplayView();
   
        
        this.toolBarView = new ToolBarView(info);

        this.addView({
            'ChallengeView': this.ChallengeView,
            'MoreView': this.moreView,
            /*'ConceptView': this.ConceptView,*/
            'ToolBarView': this.toolBarView,
            'AboutView': this.AboutView,
            'ReportIssueView': this.ReportIssueView,
            'NavView': this.navView,
            'MessageView': this.messageView,
            'MessageModalView': this.messageModalView,
            'ReplayView':this.replayView,
        	'WalkthroughVideo':this.WalkthroughVideo
          
        });

        //_loadUserProfile.call(this,this.scenesData.userInfo);
        /*_LoadSharePlane();*/
        
        
        
        this.sceneContainer.classList.add('scene-container');
        this.sceneContainer.id = 'sceneController';

        var fontStored = this.getCookie('font');
        
        this.eventHandler.on('openConceptIframe', function() {
        	this.ConceptView.openSab();
        }.bind(this));
        
        
        
        if (fontStored) {
            var font = this.viewObjs['ToolBarView'].updateFont(fontStored,null);
            this.sceneContainer.classList.add(fontStored + 'Font');
        } else {
            this.sceneContainer.classList.add('smallFont');
        }

        this.eventHandler.on('exampleOverlayActive', function() {
            this.hideView('ToolBarView');
            this.hideView('NavView');
        }.bind(this));

        this.eventHandler.on('exampleOverlayInActive', function() {
            this.showView('ToolBarView');
            this.showView('NavView');
        }.bind(this));

        var body = document.querySelector('body');
        body.appendChild(this.sceneContainer);
        _bindEvents.call(this);
    }
    
    //.................Load Share Module.....................//
    
    	window.sharePlane = function(userInfo){
	    	userInfo = JSON.parse(userInfo);
	        userInfo = userInfo.response;
        this.locAPP = utility.getUrlParameters("loc");
    	if(this.locAPP == "app"){
    		var disableSocialShare = true;
    		var disableShareLink = true;
    	}else{
    		var disableSocialShare = false;
    		var disableShareLink = false;
    	}
	        var title = document.querySelector("title");
	        title = title.innerHTML;
//	        var shareUrl = window.location.origin + window.location.pathname;
//	        var clipIndex = shareUrl.search('app');
//	        var shareImg = shareUrl.substring(0, clipIndex) + 'res/thumbnail.jpg';
//	        window.shareRootPath = "//gamma.ck12.org";
			
//	        if(/Android|Build/.test(navigator.userAgent)){
//				var pathName = window.location.pathname.split('files')[1];			// for android
//	        }else if(/iOS|Build/.test(navigator.userAgent)){
//	        	var pathName = window.location.pathname.split('NoCloud')[1];			// for ios
//	        }
	        
	        var clipI = window.location.pathname.search('app');
	        var a = window.location.pathname.substring(0,clipI);
	        var b = a.split('/');
	        var simName = b[b.length-2];
	        var pathName = simName + "/app/index.html";
	        var shareUrl = "http://interactives.ck12.org/simulations/physics/" + pathName;
	        var clipIndex = shareUrl.search('app');
	        var shareImg = shareUrl.substring(0, clipIndex) + 'res/thumbnail.jpg';
	        window.shareRootPath = "http://www.ck12.org";
	
	        
	        shareViaEmail.open({
					'shareImage':shareImg,
					'shareUrl':shareUrl,
					'shareTitle':title,
					'context':'Share Simulation',
				'disableSocialShare':disableSocialShare,
				'disableShareLink':disableShareLink,
					'payload': {
		                'memberID': userInfo.id,
		                'page': "Simulation"
					},
					'userSignedIn': true
				})
	        
	//    	window.loadSharePlane({
	//			'planeContainerId': 'sceneController',
	//			'requireShareModalPath': URL.SHARE_VIA_EMAIL,
	//			'shareData': {
	//				'shareImage':shareImg,
	//				'shareUrl':shareUrl,
	//				'shareTitle':title,
	//				'context':'Share Simulation',
	//				'payload': {
	//	                'memberID': userInfo.id,
	//	                'page': "Simulation"
	//				},
	//				'userSignedIn': true,
	//			}
	//		});
    }
    /*window.onload = function(){
    	sharePlane();
    	
    	shareData: {
     *          shareImage': Image of the Resource to be shared,
                shareUrl': Url of the resource ,
                shareTitle': Title of the resource,
                context': Share context such as 'Share Subjects','Share Modality', etc
                payload': {
                    'memberID': ,
                    'page': name of the page
                },
            'userSignedIn': window.ck12_signed_in || false,
     *      },
    };*/
    
    
    function _loadUserProfile(info) {

        if (!/^[\],:{}\s]*$/.test(info.replace(/\\["\\\/bfnrtu]/g, '@').replace(/"[^"\\\n\r]*"|true|false|null|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?/g, ']').replace(/(?:^|:|,)(?:\s*\[)+/g, ''))) {
        	this.info = {};
        	this.info.imageUrl = false;
            return false;
        }
        info = JSON.parse(info);
        this.info = info = info.response;
        
          
            /****** DexterJs config Update ******/
         /*   dexterjs.set("config", {
                memberID   : this.info.id ,
            });*/
            /****** DexterJs config Update ******/
            
        if (!info.email) {
        	this.info.imageUrl = false;
            return false;
        }
        
        if (!info.imageURL) {
            info.imageURL = (info.gender === "male") ? URL.SIMULATION_HOST_URL+'/simulations/common/allspark/assets/images/avatar_male.png' : URL.SIMULATION_HOST_URL+'/simulations/common/allspark/assets/images/avatar_female.png';
        }
        if (typeof String.prototype.startsWith != 'function') {
      	  String.prototype.startsWith = function (str){
      	    return this.indexOf(str) === 0;
      	  };
      	}
          var urlData = info.imageURL;
          var flxUrl = '/flx/show/image';
          if(urlData.startsWith(flxUrl)){
          	info.imageURL = urlData.replace("/flx/show/image", URL.FLX_HOST_URL+"show/image");
          }
          
        this.info.imageUrl = info.imageURL;
        toolbarOptions.userAvatar = this.info.imageUrl;

        //that.toolBarView = new ToolBarView(toolbarOptions);
//        this.userProfile = true;
//        this.UserProfileView = new UserProfileView(info);
//        this.addView({
//            'UserProfileView': this.UserProfileView
//        });
//        this.showView('UserProfileView');
        
        
        this.MoreView = new MoreView(info);
        this.addView({
          'MoreView': this.MoreView
        });
        this.showView('MoreView');
        this.viewObjs['ToolBarView'].updateUser(toolbarOptions);


    }

    function _bindEvents() {

        this.eventHandler.on('prev', function(e) {
            this.eventHandler.emit('previousButton', e, this.prevButton);
            this.prev();
        }.bind(this));


        this.eventHandler.on('next', function(e) {
            this.eventHandler.emit('nextButton', e, this.prevButton);
            this.next();
        }.bind(this));
        
        this.eventHandler.on('showNextArrow',function(){
        	this.viewObjs['NavView'].show('next');
        }.bind(this));

        this.eventHandler.on('activateBounce', function(e) {
            this.viewObjs['NavView'].hide('next');
            this.showView('ReplayView');
        }.bind(this));

        this.eventHandler.on('deActivateBounce', function(e) {
            this.viewObjs['NavView'].next.classList.remove('navigationBounce');
        }.bind(this));

        this.eventHandler.on('play', function(e) {
            isPlay = true;
            this.next();
            this.eventHandler.emit('startVideo');
        }.bind(this));
        
        this.eventHandler.on('replay', function(e) {
            isPlay = true;
            this.hideView("ReplayView");
            this.viewObjs['NavView'].show('next');
            this.eventHandler.emit('startVideo');
        }.bind(this));
        
        this.eventHandler.on('showMore', function() {
            this.viewObjs['MoreView'].open();
        }.bind(this));
        
        this.eventHandler.on('showConcepts', function() {
        	  this.showView('ConceptView');
        }.bind(this));

        this.eventHandler.on('showAbout', function() {
        	this.AboutView.resetAboutView();
            this.showView('AboutView');
        }.bind(this));

        this.eventHandler.on('showReportIssue', function(info) {
            this.showView('ReportIssueView');
            if(info&&info.ID)
            	this.ReportIssueView.updateHeader(info.ID);
        }.bind(this));
        
        this.eventHandler.on('showWalkThrough', function(info) {
            
            this.WalkthroughVideo.loadVideoLink();
            this.showView('WalkthroughVideo');
        }.bind(this));
        this.eventHandler.on('loadWalkThrough', function(info) {
            this.WalkthroughVideo.loadVideoLink();   
        }.bind(this));
        this.eventHandler.on('removeWalkThroughFromToolBar', function(info) {
        	this.toolBarView.walkThroughURL=false;
        }.bind(this));
        this.eventHandler.on('addWalkThroughInToolBar', function(info) {
        	this.toolBarView.walkThroughURL=true;
        }.bind(this));
        this.eventHandler.on('hideAbout', function() {
            this.hideView('AboutView');
        }.bind(this));
        
        this.eventHandler.on('hideConcept', function() {
            this.hideView('ConceptView');
        }.bind(this));

        this.eventHandler.on('hideReportIssue', function() {
            this.hideView('ReportIssueView');
        }.bind(this));
        
        this.eventHandler.on('hideWalkThrough', function() {
            this.hideView('WalkthroughVideo');
        }.bind(this));

        this.eventHandler.on('skip', function(e) {
            this.next();
        }.bind(this));

        this.eventHandler.on('openChallenges', function(e) {
            this.viewObjs['ChallengeView'].openChallenges(e);
        }.bind(this));

        this.eventHandler.on('restart', function(e) {
            this.restart();
        }.bind(this));

        this.eventHandler.on('hideMore', function(e) {
            this.viewObjs['MoreView'].close(e);
        }.bind(this));

        this.eventHandler.on('closeFont', function() {
            this.viewObjs['ToolBarView'].closeFont();
        }.bind(this));
 
        this.eventHandler.on('goBackToSrc', function(e) {
        	navReferrer = "backArrow"
//        	_dexterEvents.call(this,navReferrer);
        	 //window.location = this.backURL;
        	this.locAPP = utility.getUrlParameters("loc");
        	if(this.backURL && this.locAPP != "app"){
//        		window.location = this.backURL;
        		document.getElementById('backToSrc').href = this.backURL;
        	}else{
        		window.history.back();        		
        	}
        }.bind(this));
        
        this.eventHandler.on('showProfile', function(e) {
            this.viewObjs['UserProfileView'].openProfile();
        }.bind(this));
        
        this.eventHandler.on('showMessage', function(info) {
        	if(info)
        		this.viewObjs['MessageView'].popMessage(info.message);
        }.bind(this));

        this.eventHandler.on('showMessageModal', function(info) {
        	if(info)
        		this.viewObjs['MessageModalView'].createMessageModal(info);
        		this.showView('MessageModalView');
        		
        }.bind(this));
        this.eventHandler.on('hideMessageModal', function() {
        	this.hideView('MessageModalView');        		
        }.bind(this));
        
        this.sceneEl.addEventListener('click', function(e) {
            _closeOnDocument.call(this, e);
        }.bind(this));
        
        var eventTypes = ['click', 'keydown', 'keyup', 'keypress', '', 'touchstart'];
        for (var i = 0; i < eventTypes.length; i++) {
            var type = eventTypes[i];
            document.addEventListener(type, function(event) {
                this.eventHandler.emit(event.type, event, false);
            }.bind(this), false);
        }

        this.eventHandler.on('fontUpdated', function(e) {
            var font = this.viewObjs['ToolBarView'].fonts[this.viewObjs['ToolBarView'].data.fontID];
            this.viewObjs['ToolBarView'].closeFont();
            this.sceneContainer.classList.remove("smallFont");
            this.sceneContainer.classList.remove("largeFont");
            this.sceneContainer.classList.remove("mediumFont");
            this.sceneContainer.classList.add(font + 'Font');
            this.setCookie('font', font);
        }.bind(this));

        this.eventHandler.on('share', function(e) {
        	sharePlane(this.scenesData.userInfo);
        }.bind(this));
    }
    
    function _closeOnDocument(e) {
        //e.stopPropagation();
        this.eventHandler.emit('hideMore', e);
        this.viewObjs['ChallengeView'].closeChallenge(e);
        this.viewObjs['ToolBarView'].closeFont();
        if(this.viewObjs['UserProfileView']){
        this.viewObjs['UserProfileView'].closeProfile(e);
        this.viewObjs['MessageView'].closeMessage();
        }
    }


    return SceneController;
});;define('SimObject', ['EventHandler', 'SoModel', 'Matrix', 'AnimTransform'], function(eventHandler, SoModel, Matrix, AnimTransform) {

    var prefix = document.body.style.webkitTransform !== undefined;
    /**
     * creates an instance of simObjects, which can render in to the scene. provides support for animations,eventhandling
     * @constructor SimObject
     * @param {options} options name of the SimObject is compulsory
     */
    function SimObject(options) {
        if (!options.name) {
            //console.error('name for a simObject is compulsory');
            return;
        }

        this.innerContent = options.innerContent || "" ;
        this.name = options.name;
        this.elementType = options.type || "div";
        this.parent = options.parent || undefined;
        this.eventHandler = new eventHandler();
        this.data = options.data || {};
        this.styles = {};
        this.soModel = new SoModel();
        this.classes = options.classes || [];
        this._matrix = undefined;
        this._opacity = 1 || options.opacity;
        this._origin = options.origin || undefined;
        this._size = undefined;
        this.size =  options.size || undefined;
        AnimTransform.apply(this, [{
            opacity: this._opacity,
            size: this.size,
            origin: this._origin,
            transform: Matrix.identity
        }]);

        this.eventForwarder = function(event) {
            this.eventHandler.emit(event.type, event);
        }.bind(this);
        _set.call(this,this.elementType);

    }

    SimObject.prototype = Object.create(AnimTransform.prototype);
    SimObject.prototype.constructor = SimObject;

    /**
     * set of events SimObject supports
     * @this {SimObject}
     * @private
     */
    SimObject.prototype.Events = [
        "touchstart",
        "touchmove",
        "touchend",
        "touchcancel",
        "click",
        "mousedown",
        "mouseup",
        "mousemove",
        "mouseover",
        "mouseout",
        "mouseenter",
        "mouseleave",
        "mousewheel",
        "wheel"
    ];

    /**
     * addClass from SimObject, take a single classes or array containing different classes, chaining is also allowed
     * @method addClass
     * @param {class | class[]} class addclass or array of class
     * @memberof SimObject
     * @returns {SimObject}
     */
    SimObject.prototype.addClass = function(cls) {
        if (cls instanceof Array) {
            for (var i = 0; i < cls.length; i++)
                this.el.classList.add(cls[i]);
        } else
            this.el.classList.add(cls);
        return this;
    };

    /**
     * removeClass from simObject, take a single classes or array containing different classes, chaining is also allowed
     * @method removeClass
     * @param {class | class[]} class addclass or array of class
     * @memberof SimObject
     * @returns {SimObject}
     */
    SimObject.prototype.removeClass = function(cls) {
        if (cls instanceof Array) {
            for (var i = 0; i < cls.length; i++)
                this.el.classList.remove(cls[i]);
        } else
            this.el.classList.remove(cls);
        return this;
    };

    /**
     * set CSS style of the simOject.take an array as argument
     * @method setStyle
     * @memberof SimObject
     * @param {object} styles
     * @returns {SimObject}
     */
    SimObject.prototype.setStyle = function(styles) {
        for (var n in styles) {
        if(styles.hasOwnProperty(n)){
            this.styles[n] = styles[n];	
        }
        }
        for (var n in styles) {
          if(styles.hasOwnProperty(n)){
            this.el.style[n] = this.styles[n];
            }
        }
        return this;
    };

    /**
     * remove inline CSS style from the SimObject
     * @method removeStyle
     * @memberof SimObject
     * @returns {SimObject}
     */
    SimObject.prototype.removeStyle = function() {
        for (var n in this.styles) {
        	if(this.styles.hasOwnProperty(n)){
                this.el.style[n] = '';	
        	}
        }
        return this;
    };

    /**
     * eventListener for the SimObject. chaining is not allowed at present
     * @method on
     * @memberof SimObject
     */
    SimObject.prototype.on = function(eventType, handler) {
        this.eventHandler.on(eventType, handler, this);
    };

    /**
     * remove eventListener form the SimObject. chaining is not allowed at present
     * @method off
     * @memberof SimObject
     */
    SimObject.prototype.off = function(eventType, handler) {
        this.eventHandler.off(eventType, handler);
    };

    /**
     * trigger eventListener of the SimObject. chaining is not allowed at present. currently doesnot supports DOM events
     * @method emit
     * @memberof SimObject
     * @this {SimObject}
     */
    SimObject.prototype.emit = function(eventType, eventData) {
        this.eventHandler.emit(eventType, eventData, this);
    };

    /**
     * InnerContent of the SimObject can be added. accepts string or HTML snippets, chaining is allowed
     * @method addInnerContent
     * @memberof SimObject
     * @param {sting | HTML} content string or HTML
     * @retuns {this}
     */
    SimObject.prototype.addInnerContent = function(content) {
        this.el.innerHTML = content;
    };

    SimObject.prototype.addsimObject = function(simObject) {
        if (simObject instanceof Array) {
            for (var i = 0; i < simObject.length; i++)
                this.el.appendChild(simObject[i].el);
        } else
            this.el.appendChild(simObject.el);
    };

    SimObject.prototype.addElement = function(el) {
        this.el.appendChild(el);
    };

    /**
     * empty SimObject
     * @method removeInnerContent
     * @memberof SimObject
     * @retuns {this}
     */
    SimObject.prototype.removeInnerContent = function() {
        this.el.innerHTML = "";
    };

    /**
     * reset the existing transformation on the SimObject
     * @method resetTransform
     * @memberof SimObject
     * @return {this}
     */
    SimObject.prototype.resetTransform = function() {
        this._resetTransform();
        return this;
    };

    /**
     * initial setting of the SimObject
     * @method set
     * @memberof SimObject
     */
     function _set(type) {
        this.el = document.createElement(type);
        this.el.id = this.name;
        var length = this.classes.length;
        for (var i = 0; i < length; i++)
            this.addClass(this.classes[i]);

        _bindEvents.call(this, this.el);
    }

    SimObject.prototype.setData = function(data) {
        this.data = data;
        this.soModel.set(data);
    };

    /**
     * listens for the data changes on SimObject model. whole object can be listened or particular attribute of the data can be listened
     * @method eyesOn
     * @memberof SimObject
     * @param {callback} callback change handler
     * @param {key} key listen to particular key in data object
     */
    SimObject.prototype.eyesOn = function(callback, key) {
        this.soModel.eyesOn(callback, key);
    };

    /**
     * remove listeners on model data change. whole object can be listened or particular attribute of the data can be listened
     * @method eyesOff
     * @memberof SimObject
     * @param {function} callback
     * @param {key} key
     */
    SimObject.prototype.eyesOff = function(callback, key) {
        this.soModel.eyesOff(callback, key);
    };

    SimObject.prototype.emitEyesOn = function(key) {
        this.soModel.emitEyesOn(key);
    };

    SimObject.prototype.render = function(parent) {
        if (this.parent !== undefined) {
            this.parent.appendChild(this.el);
        } else {
            this.parent = parent;
            parent.appendChild(this.el);
        }
    };


    SimObject.prototype.updateCSSMatrix = function(matrix) {
        if (prefix)
            this.el.style.webkitTransform = Matrix.formatCSS(matrix);
        else
            this.el.style.transform = Matrix.formatCSS(matrix);
    };

    SimObject.prototype.updateOrigin = function(origin) {
        if (prefix)
            this.el.style.webkitTransformOrigin = _formatCSSOrigin(origin);
        else
            this.el.style.transformOrigin = _formatCSSOrigin(origin);
    };

    SimObject.prototype._setSize = function(size) {
        this.size = size ? [size[0], size[1]] : undefined;
        this._sizeDirty = true;
    };


    /**
     * add background image to the simObject
     * @method background
     * @memberof SimObject
     * @param {string} url url of the image
     */
    SimObject.prototype.background = function(url) {
        this.el.style.backgroundImage = 'url(' + url + ')';
        return this;
    };
    SimObject.prototype.transformDelay = function(delay, callback) {

        this.transform(Matrix.identity, {
            duration: delay
        }, callback);

    };

    /**
     * translate SimObject with respect to the scene
     * @method translateByPercentage
     * @memberof SimObject
     * @param {translate[]} translate translation values in percentages
     * @param {object} transition
     * @param {function} callback
     */
    SimObject.prototype.translateByPercentage = function(translate, transition, callback) {
    	var absolueTranslate;
        if (transition) {
            absolueTranslate = this.translateInAbsolute(translate);
            this.transform(Matrix.translate(absolueTranslate[0], absolueTranslate[1], 0), transition, callback);
        } else {
            this.transformTranslateState.halt();
        }
        this._output.transform = Matrix.thenMove(Matrix.identity, absolueTranslate);
        return absolueTranslate;
    };


    /**
     * converts translation values from percentage to absolute values
     * @method translateInAbsolute
     * @memberof SimObject
     * @param {translate[]} translate
     * @return {translate[]} translate in absolute
     */
    SimObject.prototype.translateInAbsolute = function(translate) {
        var size = [this.scene.clientWidth, this.scene.clientHeight];
        var absoluteTranslate = [size[0] * (translate[0] / 100), size[1] * (translate[1] / 100), 0];
        return absoluteTranslate;
    };



    function _formatCSSOrigin(origin) {
        return (100 * origin[0]).toFixed(6) + '% ' + (100 * origin[1]).toFixed(6) + '%';
    }


    function _bindEvents(target) {
        for (var i = this.Events, j = 0; j < i.length; j++) {
            target.addEventListener(i[j], this.eventForwarder);
        }
    }

    function _xyNotEquals(a, b) {
        return (a && b) ? (a[0] !== b[0] || a[1] !== b[1]) : a !== b;
    }

    /**
     * update SimObject
     * @method update
     * @memberof SimObject
     * @param {matrix[]} matrix
     * @param {size[]} size
     * @param {number} opacity
     * @param {origin[]} origin
     * @return {translate[]} translate in absolute
     */
    SimObject.prototype.update = function(matrix, size, opacity, origin) {

        if (this.size) {
            var origSize = size;
            size = [this.size[0], this.size[1]];
            if (size[0] === undefined && origSize[0]) size[0] = origSize[0];
            if (size[1] === undefined && origSize[1]) size[1] = origSize[1];
        }

        if (_xyNotEquals(this._size, size)) {
            if (size) {
                this._size = [size[0], size[1]];
                this._sizeDirty = true;
            }
        }


        if (!Matrix.equals(matrix, this._matrix)) {
            var matrixRefactor = _refactorMatrix(matrix);
            if (!matrix) matrix = Matrix.identity;
            this._matrix = matrix;
            var aaMatrix = matrixRefactor;
            this.updateCSSMatrix(matrixRefactor);
        }
        if (this._opacity !== opacity) {
            this._opacity = opacity;
            this.el.style.opacity = (opacity >= 1) ? '0.999999' : opacity;
        }


        if (this._sizeDirty) {
            if (this._size) {
                this.el.style.width = this._size[0] + 'px';
                this.el.style.height = this._size[1] + 'px';
            }
            this._sizeDirty = false;
        }

    };

    function _refactorMatrix(m) {
        var r = [];
        for (var i = 0; i <= 15; i++)
            r.push(m[i]);
        return r;
    }

    return SimObject;
});;/**
 * soModel is basic data object in the simulation framework
 * soModel is the objects which holds the data and related methods for computations and transformations on the data
 * soModel also has functions to notify the universal event handler through scene object when the data inside it changes
 *
 *
 * Usage
 *
 *  var electricField = new soModel(data);
 *
 *
 *
 *  Methods
 *
 *   	electricField.set(data);
 *
 *  	electricField.get();
 *
 *  	electricField.hasChanged()
 *  		returns boolean value, when the data changes
 *
 *  	electricField.destroy()
 *  		 destroy the elctricField model
 *
 *  	electricField.clear()
 *  		  clears the saved data inside the model
 *
 *  Utility functions
 *  	isEmpty(obj)
 *  	 	check for whether an object is empty.
 *
 */
define('SoModel', [], function() {

    /**
     * creates an instanceof sim Object Model(SoModel)
     * SoModel is basic data object in the simulation framework
     * SoModel is the objects which holds the data and related methods for computations and transformations on the data
     * SoModel also has functions to notify the universal event handler through scene object when the data inside it changes
     * @constructor SoModel
     * @param {data} data data for the model
     * @param {options} options
     * @example
     * var electricField = new SoModel(data);
     * electricField.set(data);
     *
     */
    function SoModel(data, options) {
        this.data = data || {};
        this.options = options || {};
        this.changeHandler = changeHandler();
    }

    /**
     * set data of the SoModel
     * @memberof SoModel
     * @method set
     * @param {object} data
     */
    SoModel.prototype.set = function(data) {
        this.data = data;
    }

    /**
     * get data from the SoModel
     * @method get
     * @memberof SoModel
     * @return {object} data
     */
    SoModel.prototype.get = function() {
        return this.data;
    }

    /**
     * check if data object of the SoModel is empty
     * @memberof SoModel
     * @method hasData
     * @return {boolean}
     */
    SoModel.prototype.hasData = function() {
        return isEmpty(this.data);
    }

    /**
     * clear the data object of SoModel
     * @method clear
     * @memberof SoModel
     */
    SoModel.prototype.clear = function() {
        for (var i in this.data)
            delete this.data[i];
    }

    SoModel.prototype.destroy = function() {

    }

    /**
     * start listening to changes of data object,it also listen to changes of a particular key inside the data object
     * @method eyesOn
     * @memberof SoModel
     * @param {function} callback function to be called after data object or particular key changes
     * @param {key} key
     */
    SoModel.prototype.eyesOn = function(callback, key) {
        if (key)
            this.changeHandler.eyesOn(this.data, key, callback);
        else
            this.changeHandler.eyesOn(this.data, callback);
    }

    /**
     * stop listening to changes of data object,it can also stop listen to changes of a particular key inside the data object
     * @method eyesOff
     * @memberof SoModel
     * @param {function} callback function to be called after data object or particular key changes
     * @param {key} key
     */
    SoModel.prototype.eyesOff = function(callback, key) {
        if (key)
            this.changeHandler.eyesOff(this.data, key, callback);
        else
            this.changeHandler.eyesOff(this.data, callback);
    }

    SoModel.prototype.emitEyesOn = function(key) {
        this.changeHandler.emitEyesOn(this.data, key);
    }

    function isEmpty(object) {
        if (Object.getOwnPropertyNames(obj).length > 0)
            return false;
        else
            return true;
    }


    function changeHandler() {

        var changeHandler = {
                noMore: false
            },
            lengthsubjects = [];

        var isFunction = function(functionToCheck) {
            var getType = {};
            return functionToCheck && getType.toString.call(functionToCheck) == '[object Function]';
        };

        var isInt = function(x) {
            return x % 1 === 0;
        };

        var isArray = function(obj) {
            return Object.prototype.toString.call(obj) === '[object Array]';
        };

        var getObjDiff = function(a, b) {
            var aplus = [],
                bplus = [];

            if (!(typeof a == "string") && !(typeof b == "string")) {

                if (isArray(a)) {
                    for (var i = 0; i < a.length; i++) {
                        if (b[i] === undefined) aplus.push(i);
                    }
                } else {
                    for (var i in a) {
                        if (a.hasOwnProperty(i)) {
                            if (b[i] === undefined) {
                                aplus.push(i);
                            }
                        }
                    }
                }

                if (isArray(b)) {
                    for (var j = 0; j < b.length; j++) {
                        if (a[j] === undefined) bplus.push(j);
                    }
                } else {
                    for (var j in b) {
                        if (b.hasOwnProperty(j)) {
                            if (a[j] === undefined) {
                                bplus.push(j);
                            }
                        }
                    }
                }
            }

            return {
                added: aplus,
                removed: bplus
            }
        };

        var clone = function(obj) {

            if (null == obj || "object" != typeof obj) {
                return obj;
            }

            var copy = obj.constructor();

            for (var attr in obj) {
                copy[attr] = obj[attr];
            }

            return copy;

        }

        var defineGetAndSet = function(obj, propName, getter, setter) {
            try {

                Object.observe(obj[propName], function(data) {
                    setter(data); //TODO: adapt our callback data to match Object.observe data spec
                });

            } catch (e) {

                try {
                    Object.defineProperty(obj, propName, {
                        get: getter,
                        set: setter,
                        enumerable: true,
                        configurable: true
                    });
                } catch (e2) {
                    try {
                        Object.prototype.__defineGetter__.call(obj, propName, getter);
                        Object.prototype.__defineSetter__.call(obj, propName, setter);
                    } catch (e3) {
                        throw new Error("changeHandler error: browser not supported :/")
                    }
                }

            }
        };

        var defineProp = function(obj, propName, value) {
            try {
                Object.defineProperty(obj, propName, {
                    enumerable: false,
                    configurable: true,
                    writable: false,
                    value: value
                });
            } catch (error) {
                obj[propName] = value;
            }
        };

        var watch = function() {

            if (isFunction(arguments[1])) {
                watchAll.apply(this, arguments);
            } else if (isArray(arguments[1])) {
                watchMany.apply(this, arguments);
            } else {
                watchOne.apply(this, arguments);
            }

        };


        var watchAll = function(obj, watcher, level, addNRemove) {

            if ((typeof obj == "string") || (!(obj instanceof Object) && !isArray(obj))) { //accepts only objects and array (not string)
                return;
            }

            var props = [];


            if (isArray(obj)) {
                for (var prop = 0; prop < obj.length; prop++) { //for each item if obj is an array
                    props.push(prop); //put in the props
                }
            } else {
                for (var prop2 in obj) { //for each attribute if obj is an object
                    if (obj.hasOwnProperty(prop2)) {
                        props.push(prop2); //put in the props
                    }
                }
            }

            watchMany(obj, props, watcher, level, addNRemove); //watch all items of the props

            if (addNRemove) {
                pushToLengthSubjects(obj, "$$watchlengthsubjectroot", watcher, level);
            }
        };


        var watchMany = function(obj, props, watcher, level, addNRemove) {

            if ((typeof obj == "string") || (!(obj instanceof Object) && !isArray(obj))) { //accepts only objects and array (not string)
                return;
            }

            for (var prop in props) { //watch each attribute of "props" if is an object
                if (props.hasOwnProperty(prop)) {
                    watchOne(obj, props[prop], watcher, level, addNRemove);
                }
            }

        };

        var watchOne = function(obj, prop, watcher, level, addNRemove) {

            if ((typeof obj == "string") || (!(obj instanceof Object) && !isArray(obj))) { //accepts only objects and array (not string)
                return;
            }

            if (isFunction(obj[prop])) { //dont watch if it is a function
                return;
            }

            if (obj[prop] != null && (level === undefined || level > 0)) {
                watchAll(obj[prop], watcher, level !== undefined ? level - 1 : level); //recursively watch all attributes of this
            }

            defineWatcher(obj, prop, watcher, level);

            if (addNRemove && (level === undefined || level > 0)) {
                pushToLengthSubjects(obj, prop, watcher, level);
            }

        };

        var unwatch = function() {

            if (isFunction(arguments[1])) {
                unwatchAll.apply(this, arguments);
            } else if (isArray(arguments[1])) {
                unwatchMany.apply(this, arguments);
            } else {
                unwatchOne.apply(this, arguments);
            }

        };

        var unwatchAll = function(obj, watcher) {

            if (obj instanceof String || (!(obj instanceof Object) && !isArray(obj))) { //accepts only objects and array (not string)
                return;
            }

            var props = [];


            if (isArray(obj)) {
                for (var prop = 0; prop < obj.length; prop++) { //for each item if obj is an array
                    props.push(prop); //put in the props
                }
            } else {
                for (var prop2 in obj) { //for each attribute if obj is an object
                    if (obj.hasOwnProperty(prop2)) {
                        props.push(prop2); //put in the props
                    }
                }
            }

            unwatchMany(obj, props, watcher); //watch all itens of the props
        };


        var unwatchMany = function(obj, props, watcher) {

            for (var prop2 in props) { //watch each attribute of "props" if is an object
                if (props.hasOwnProperty(prop2)) {
                    unwatchOne(obj, props[prop2], watcher);
                }
            }
        };

        var defineWatcher = function(obj, prop, watcher, level) {

            var val = obj[prop];

            watchFunctions(obj, prop);

            if (!obj.watchers) {
                defineProp(obj, "watchers", {});
            }

            if (!obj.watchers[prop]) {
                obj.watchers[prop] = [];
            }

            for (var i = 0; i < obj.watchers[prop].length; i++) {
                if (obj.watchers[prop][i] === watcher) {
                    return;
                }
            }


            obj.watchers[prop].push(watcher); //add the new watcher in the watchers array


            var getter = function() {
                return val;
            };


            var setter = function(newval) {
                var oldval = val;
                val = newval;

                if (level !== 0 && obj[prop]) {
                    // watch sub properties
                    watchAll(obj[prop], watcher, (level === undefined) ? level : level - 1);
                }

                watchFunctions(obj, prop);

                if (!changeHandler.noMore) {
                    //if (JSON.stringify(oldval) !== JSON.stringify(newval)) {
                    if (oldval !== newval) {
                        callWatchers(obj, prop, "set", newval, oldval);
                        changeHandler.noMore = false;
                    }
                }
            };

            defineGetAndSet(obj, prop, getter, setter);

        };

        var callWatchers = function(obj, prop, action, newval, oldval) {
            if (prop) {
                for (var wr = 0; wr < obj.watchers[prop].length; wr++) {
                    obj.watchers[prop][wr].call(obj, prop, action, newval, oldval);
                }
            } else {
                for (var prop in obj) { //call all
                    if (obj.hasOwnProperty(prop)) {
                        callWatchers(obj, prop, action, newval, oldval);
                    }
                }
            }
        };

        // @todo code related to "watchFunctions" is certainly buggy
        var methodNames = ['pop', 'push', 'reverse', 'shift', 'sort', 'slice', 'unshift'];
        var defineArrayMethodWatcher = function(obj, prop, original, methodName) {
            defineProp(obj[prop], methodName, function() {
                var response = original.apply(obj[prop], arguments);
                watchOne(obj, obj[prop]);
                if (methodName !== 'slice') {
                    callWatchers(obj, prop, methodName, arguments);
                }
                return response;
            });
        };

        var watchFunctions = function(obj, prop) {

            if ((!obj[prop]) || (obj[prop] instanceof String) || (!isArray(obj[prop]))) {
                return;
            }

            for (var i = methodNames.length, methodName; i--;) {
                methodName = methodNames[i];
                defineArrayMethodWatcher(obj, prop, obj[prop][methodName], methodName);
            }

        };

        var unwatchOne = function(obj, prop, watcher) {
            for (var i = 0; i < obj.watchers[prop].length; i++) {
                var w = obj.watchers[prop][i];

                if (w == watcher) {
                    obj.watchers[prop].splice(i, 1);
                }
            }

            removeFromLengthSubjects(obj, prop, watcher);
        };

        var loop = function() {

            for (var i = 0; i < lengthsubjects.length; i++) {

                var subj = lengthsubjects[i];

                if (subj.prop === "$$watchlengthsubjectroot") {

                    var difference = getObjDiff(subj.obj, subj.actual);

                    if (difference.added.length || difference.removed.length) {
                        if (difference.added.length) {
                            watchMany(subj.obj, difference.added, subj.watcher, subj.level - 1, true);
                        }

                        subj.watcher.call(subj.obj, "root", "differentattr", difference, subj.actual);
                    }
                    subj.actual = clone(subj.obj);


                } else {

                    var difference = getObjDiff(subj.obj[subj.prop], subj.actual);

                    if (difference.added.length || difference.removed.length) {
                        if (difference.added.length) {
                            for (var j = 0; j < subj.obj.watchers[subj.prop].length; j++) {
                                watchMany(subj.obj[subj.prop], difference.added, subj.obj.watchers[subj.prop][j], subj.level - 1, true);
                            }
                        }

                        callWatchers(subj.obj, subj.prop, "differentattr", difference, subj.actual);
                    }

                    subj.actual = clone(subj.obj[subj.prop]);

                }

            }

        };

        var pushToLengthSubjects = function(obj, prop, watcher, level) {

            var actual;

            if (prop === "$$watchlengthsubjectroot") {
                actual = clone(obj);
            } else {
                actual = clone(obj[prop]);
            }

            lengthsubjects.push({
                obj: obj,
                prop: prop,
                actual: actual,
                watcher: watcher,
                level: level
            });
        };

        var removeFromLengthSubjects = function(obj, prop, watcher) {

            for (var i = 0; i < lengthsubjects.length; i++) {
                var subj = lengthsubjects[i];

                if (subj.obj == obj && subj.prop == prop && subj.watcher == watcher) {
                    lengthsubjects.splice(i, 1);
                }
            }

        };

        changeHandler.eyesOn = watch;
        changeHandler.eyesOff = unwatch;
        changeHandler.emitEyesOn = callWatchers;

        return changeHandler;

    }

    return SoModel;
});;define('Transition',['Tweening'],function(Tweening) {


    function Transition(start) {
        this.currentAction = null;
        this.actionQueue = [];
        this.callbackQueue = [];

        this.state = 0;
        this._callback = undefined;
        this._engineInstance = null;
        this._currentMethod = null;

        this.set(start);
    };

    var transitionMethods = {};

    Transition.registerMethod = function(name, engineClass) {
        if(!(name in transitionMethods)) {
            transitionMethods[name] = engineClass;
            return true;
        }
        else return false;
    };

    Transition.unregisterMethod = function(name) {
        if(name in transitionMethods) {
            delete transitionMethods[name];
            return true;
        }
        else return false;
    };

    function _loadNext() {
        if(this._callback) {
            var callback = this._callback;
            this._callback = undefined;
            callback();
        }
        if(this.actionQueue.length <= 0) {
            this.set(this._engineInstance); // no update required
            return;
        }
        this.currentAction = this.actionQueue.shift();
        this._callback = this.callbackQueue.shift();

        var method = null;
        var endValue = this.currentAction[0];
        var transition = this.currentAction[1];
        if(transition instanceof Object && transition.method) {
            method = transition.method;
            if(typeof method === 'string') method = transitionMethods[method];
        }
        else {
            method = Tweening;
        }
        if(this._currentMethod !== method) {
            if(!(endValue instanceof Object) || method.SUPPORTS_MULTIPLE === true || endValue.length <= method.SUPPORTS_MULTIPLE) {
                this._engineInstance = new method();
            }
            else {
                //this._engineInstance = new MultipleTransition(method);
            }
            this._currentMethod = method;
        }
        this._engineInstance.reset(this.state);
        this._engineInstance.set(endValue, transition, _loadNext.bind(this));
    };

    Transition.prototype.set = function(endState, transition, callback) {
        if(!transition) {
            this.reset(endState);
            if(callback) callback();
            return;
        }

        var action = [endState, transition];
        this.actionQueue.push(action);
        this.callbackQueue.push(callback);
        if(!this.currentAction) _loadNext.call(this);
    };


    Transition.prototype.reset = function(startState) {
        this._currentMethod = null;
        this._engineInstance = null;
        this.state = startState;
        this.currentAction = null;
        this.actionQueue = [];
        this.callbackQueue = [];
    };


    Transition.prototype.delay = function(duration, callback) {
        this.set(this._engineInstance, {duration: duration, curve: function() { return 0; }}, callback);
    };


    Transition.prototype.get = function(timestamp) {
        if(this._engineInstance) this.state = this._engineInstance.get(timestamp);
        return this.state;
    };


    Transition.prototype.isActive = function() {
        return !!this.currentAction;
    };

    Transition.prototype.halt = function() {
        this.set(this.get());
    };
    
    Transition.prototype.pause = function() {
    	if(this._engineInstance) this._engineInstance.pause();
    };

    return Transition;
});
;
define('Tweening',[],function() {


    function Tweening(options) {
        this.options = Object.create(Tweening.DEFAULT_OPTIONS);
        if (options) this.setOptions(options);

        this._startTime = 0;
        this._startValue = 0;
        this._updateTime = 0;
        this._endValue = 0;
        this._curve = undefined;
        this._duration = 0;
        this._active = false;
        this._callback = undefined;
        this.state = 0;
        this.velocity = undefined;
    }

    Tweening.Curves = {
        linear: function(t) {
            return t;
        },
        easeIn: function(t) {
            return t*t;
        },
        easeOut: function(t) {
            return t*(2-t);
        },
        easeInOut: function(t) {
            if (t <= 0.5) return 2*t*t;
            else return -2*t*t + 4*t - 1;
        },
        easeOutBounce: function(t) {
            return t*(3 - 2*t);
        },
        spring: function(t) {
            return (1 - t) * Math.sin(6 * Math.PI * t) + t;
        }
    };

    Tweening.SUPPORTS_MULTIPLE = true;
    Tweening.DEFAULT_OPTIONS = {
        curve: Tweening.Curves.linear,
        duration: 500,
        speed: 0 /* considered only if positive */
    };

    var registeredCurves = {};


    Tweening.registerCurve = function registerCurve(curveName, curve) {
        if (!registeredCurves[curveName]) {
            registeredCurves[curveName] = curve;
            return true;
        }
        else {
            return false;
        }
    };


    Tweening.unregisterCurve = function unregisterCurve(curveName) {
        if (registeredCurves[curveName]) {
            delete registeredCurves[curveName];
            return true;
        }
        else {
            return false;
        }
    };


    Tweening.getCurve = function getCurve(curveName) {
        return registeredCurves[curveName];
    };


    Tweening.getCurves = function getCurves() {
        return registeredCurves;
    };

     // Interpolate: If a linear function f(0) = a, f(1) = b, then return f(t)
    function _interpolate(a, b, t) {
        return ((1 - t) * a) + (t * b);
    }

    function _clone(obj) {
        if (obj instanceof Object) {
            if (obj instanceof Array) return obj.slice(0);
            else return Object.create(obj);
        }
        else return obj;
    }

    // Fill in missing properties in "transition" with those in defaultTransition, and
    //   convert internal named curve to function object, returning as new
    //   object.
    function _normalize(transition, defaultTransition) {
        var result = {curve: defaultTransition.curve};
        if (defaultTransition.duration) result.duration = defaultTransition.duration;
        if (defaultTransition.speed) result.speed = defaultTransition.speed;
        if (transition instanceof Object) {
            if (transition.duration !== undefined) result.duration = transition.duration;
            if (transition.curve) result.curve = transition.curve;
            if (transition.speed) result.speed = transition.speed;
        }
        if (typeof result.curve === 'string') result.curve = Tweening.getCurve(result.curve);
        return result;
    }


    Tweening.prototype.setOptions = function setOptions(options) {
        if (options.curve !== undefined) this.options.curve = options.curve;
        if (options.duration !== undefined) this.options.duration = options.duration;
        if (options.speed !== undefined) this.options.speed = options.speed;
    };


    Tweening.prototype.set = function set(endValue, transition, callback) {
        if (!transition) {
            this.reset(endValue);
            if (callback) callback();
            return;
        }

        this._startValue = _clone(this.get());
        transition = _normalize(transition, this.options);
        if (transition.speed) {
            var startValue = this._startValue;
            if (startValue instanceof Object) {
                var variance = 0;
                for (var i in startValue) variance += (endValue[i] - startValue[i]) * (endValue[i] - startValue[i]);
                transition.duration = Math.sqrt(variance) / transition.speed;
            }
            else {
                transition.duration = Math.abs(endValue - startValue) / transition.speed;
            }
        }

        this._startTime = Date.now();
        this._endValue = _clone(endValue);
        this._lapseTime = 0;
        this._pause = false;
        this._startVelocity = _clone(transition.velocity);
        this._duration = transition.duration;
        this._curve = transition.curve;
        this._active = true;
        this._callback = callback;
    };


    Tweening.prototype.reset = function reset(startValue, startVelocity) {
        if (this._callback) {
            var callback = this._callback;
            this._callback = undefined;
            callback();
        }
        this.state = _clone(startValue);
        this.velocity = _clone(startVelocity);
        this._startTime = 0;
        this._duration = 0;
        this._updateTime = 0;
        this._lapseTime = 0;
        this._pause = false;
        this._startValue = this.state;
        this._startVelocity = this.velocity;
        this._endValue = this.state;
        this._active = false;
    };


    Tweening.prototype.getVelocity = function getVelocity() {
        return this.velocity;
    };


    Tweening.prototype.get = function get(timestamp) {
        this.update(timestamp);
        return this.state;
    };

    function _calculateVelocity(current, start, curve, duration, t) {
        var velocity;
        var eps = 1e-7;
        var speed = (curve(t) - curve(t - eps)) / eps;
        if (current instanceof Array) {
            velocity = [];
            for (var i = 0; i < current.length; i++)
                velocity[i] = speed * (current[i] - start[i]) / duration;
        }
        else velocity = speed * (current - start) / duration;
        return velocity;
    }

    function _calculateState(start, end, t) {
        var state;
        if (start instanceof Array) {
            state = [];
            for (var i = 0; i < start.length; i++)
                state[i] = _interpolate(start[i], end[i], t);
        }
        else state = _interpolate(start, end, t);
        return state;
    }


    Tweening.prototype.update = function update(timestamp) {
        if (!this._active) {
            if (this._callback) {
                var callback = this._callback;
                this._callback = undefined;
                callback();
            }
            return;
        }

        if (!timestamp) timestamp = Date.now();
        if (this._updateTime >= timestamp) return;
        this._updateTime = timestamp;
        
        var timeSinceStart = timestamp - this._startTime;
        
        if(this._pause){
        	this._startTime = Date.now();
        	timeSinceStart = 0;
        	this._duration   = this._duration - this._lapseTime;
        	this._startValue =  this.state;
        	this._curve = Tweening.Curves.linear;
        	this._pause = false;
        }
        
        if (timeSinceStart >= this._duration) {
            this.state = this._endValue;
            this.velocity = _calculateVelocity(this.state, this._startValue, this._curve, this._duration, 1);
            this._active = false;
        }
        else if (timeSinceStart < 0) {
            this.state = this._startValue;
            this.velocity = this._startVelocity;
        }
        else{
            var t = timeSinceStart / this._duration;
            this._lapseTime = timeSinceStart;
            this.state = _calculateState(this._startValue, this._endValue, this._curve(t));
            this.velocity = _calculateVelocity(this.state, this._startValue, this._curve, this._duration, t);
        }
    };


    Tweening.prototype.isActive = function isActive() {
        return this._active;
    };


    Tweening.prototype.halt = function halt() {
        this.reset(this.get());
    };
    
    Tweening.prototype.pause = function(){
    	this._pause = true;
    }



    Tweening.customCurve = function customCurve(v1, v2) {
        v1 = v1 || 0; v2 = v2 || 0;
        return function(t) {
            return v1*t + (-2*v1 - v2 + 3)*t*t + (v1 + v2 - 2)*t*t*t;
        };
    };

    return Tweening;
});;define('Draggable', [], function() {
    /**
     * Creates an instance of Draggable.
     *
     * @constructor Draggable
     * @this {Draggable}
     * @param {object} desired options to the draggable
     * @example
     * var draggable = new Draggable({
     * 		el:element,
     * 		startCallBack:function(){},
     * 		moveCallBack:function(){},
     * 		resizeHandle:false,
     * 		restrict:{
     * 					outer:{
     * 								top:ypx,
     * 								bottom:ypx,
     * 								left:xpx,
     * 								right:xpx
     * 						  },
     * 					inner :{
     * 
     * 							
     * 						   }
     * 					}
     * 
     * })
     *
     */

	function Draggable(options){
		this.el = options.el ;
		this.startCallBack = options.startCallBack || null;
		this.moveCallBack = options.moveCallBack ;
		this.resizeHandle = options.resizeHandle || false;
		this.restrict = options.restrict || false;
		this.windowHeight = window.innerHeight;
		this.windowWidth = window.innerWidth;
		_init.call(this);
	 }
	
		function _init(){
		this.mouseDownHandler = function(e){
			e.preventDefault();
			e.stopPropagation();
	        if (e.touches) e = e.touches[0];
	        this.startLeft = this._translateX || 0;
	        this.startTop = this._translateY || 0;
	        
	        this.startX = e.clientX;
	        this.startY = e.clientY;
			
			document.addEventListener('mousemove',this.mouseMoveHandler,false);
			document.addEventListener('touchmove',this.mouseMoveHandler,false);
			document.addEventListener('mouseup',this.mouseUpHandler,false);
			document.addEventListener('touchend',this.mouseUpHandler,false);
			if(this.startCallBack){
				this.startCallBack({x:e.clientX,y:e.clientY});
			}
		}.bind(this)
		this.mouseMoveHandler = function(e){
			e.preventDefault();
			e.stopPropagation();
			 if (e.touches) e = e.touches[0];
			    this.positionX = e.clientX;
		        this.positionY = e.clientY;
		        
		        this.moving_x = this.startLeft + this.positionX - this.startX;
		        this.moving_y = this.startTop + this.positionY - this.startY;
		        

		        this._translateX = this.startLeft + this.positionX - this.startX;

		        if(this.restrict&&(-50)<=(this.moving_y+this.el.clientTop+this.el.clientHeight)&&(this.moving_y+this.el.clientTop)<=(this.windowHeight-150)){
		        	this._translateY = this.startTop + this.positionY - this.startY;
		        }
		        
		      
		        if(!this.resizeHandle){
		        	
		        	  this.el.style.webkitTransform = 'translate('+this._translateX+'px,'+this._translateY+'px)';
				        this.el.style.transform =  'translate('+this._translateX+'px,'+this._translateY+'px)';
		        }
		      
		        if(this.moveCallBack){
		        	this.moveCallBack({x:e.clientX,y:e.clientY,event:e,translateX:this._translateX,translateY:this._translateY});
		        }
			
		}.bind(this)
		this.mouseUpHandler = function(e){
			e.preventDefault();
			e.stopPropagation();
			document.removeEventListener('mousemove',this.mouseMoveHandler);
			document.removeEventListener('touchmove',this.mouseMoveHandler);
			document.removeEventListener('mouseup',this.mouseUpHandler);
			document.removeEventListener('touchend',this.mouseUpHandler);
		}.bind(this)
		
		_bind_event.call(this);
	}
		function _bind_event(){
		this.el.addEventListener('mousedown',this.mouseDownHandler,false);
		this.el.addEventListener('touchstart',this.mouseDownHandler,false);
		if(!this.resizeHandle){
		this.el.classList.add('draggable-cursor');
		}
	}

	    /**
	     * remove Draggable
	     * @memberof Draggable
	     * @method removeDraggable
	     * @this {Draggable}
	     */
		Draggable.prototype.removeDraggable = function(){
			this.el.removeEventListener('mousedown',this.mouseDownHandler);
			this.el.removeEventListener('touchstart',this.mouseDownHandler);
			if(!this.resizeHandle){
			this.el.classList.remove('draggable-cursor');
			}
		}
	return Draggable

});;
define('FileDropUpload',[],function(){
	
	/**
     * Upgrades htmlObjects to a drag-droppable file input element 
     *
     * @constructor FileDropUpload
     * @this {FileDropUpload}
     * @param {object} html object reference
     * @param {object} desired options to the FileDropUpload
     * @example
     * var uploadFile = new FileDropUpload(document.querySelector('.drag-drop-container'),{
     * 			fileDraggable : true,
     * 			acceptedTypes : {
	 *				'image/png' : true, 
	 *				'image/jpeg' : true,
	 *				'image/gif' : true,
	 *				'image/jpg' : true 
	 *			},
	 *			hoverInCallback : _hoverDropHolder,
	 *			hoverOutCallback : _hoverOutDropHolder,
	 *			endCallback : _sendDroppedFile,
	 *			previewElement : FileDropUpload(document.querySelector('.image-container') //image tag
     * })
     *
     */
	
	var defaultAcceptedTypes = {
			'image/png' : true, 
			'image/jpeg' : true,
			'image/gif' : true,
			'image/jpg' : true 
	};
	var DragOvertemplate = 	'<div class="drag-over">'+
								'<div class="drag-animating"></div>'+
								'<div class="drag-over-icon"></div>'+
								'<div class="drag-over-text">Drop your file here.</div>'+
							'</div>'+
							'<div class="top-layer"></div>';
	var FileDropUpload = function(htmlObject,options){
		this.el = htmlObject;
		this.options = options;
		_init.call(this);
	};
	
	var _init = function _init(){
		this.fileDraggable = this.options.fileDraggable;
		this.imgContainer = this.options.previewElement ? this.options.previewElement : new Image();
		this.acceptedTypes = this.options.acceptedTypes ? this.options.acceptedTypes : defaultAcceptedTypes; 
		this.inputFile = document.createElement('input');
		this.uploadBtn = document.createElement('div');
		this.inputFile.type = "file";
		this.inputFile.classList.add('input-file');
		this.uploadBtn.classList.add('upload-btn');
		/*this.uploadBtn.appendChild(this.inputFile);*/
		if(!this.options.previewElement){
			this.el.appendChild(this.imgContainer);
		}
		this.el.appendChild(this.uploadBtn);
		this.el.appendChild(this.inputFile);
		this.file = "";
		
		_bindEvents.call(this);
		
	};
	
	/**
	 * get attached file
	 * @memberof FileDropUpload
	 * @method getFile
	 * @this {FileDropUpload}
	 * @returns {string} image file as base64 string
	 */
	FileDropUpload.prototype.getFile = function(){
		return this.file;
	};
	FileDropUpload.prototype.resetFile = function(){
		this.inputFile.value = "";
	};
	
	function _bindEvents(){
		this.inputFile.addEventListener('change',function(e){
			_previewImageFile.call(this,e.currentTarget.files[0]);
		}.bind(this));
		
		if(this.fileDraggable){
			 	this.overlay = document.createElement('div');
			 	this.overlay.className = "drag-overlay";
			 	this.overlay.classList.add('hide');
				this.overlay.innerHTML =  DragOvertemplate;
				
				document.body.appendChild(this.overlay);
				this.topLayer = this.overlay.querySelector('.top-layer');
			document.addEventListener('dragover',function(e){
				e.stopPropagation();
				e.preventDefault();
			}.bind(this),false);
				
			this.topLayer.addEventListener('dragleave',function(e){
				e.stopPropagation();
				e.preventDefault();
				this.overlay.classList.add('hide');
				this.overlay.querySelector('.drag-animating').classList.remove('drag-over-animation');
				if(this.options&&(this.options.hoverOutCallback)&&(this.options.hoverOutCallback instanceof Function)){
					this.options.hoverOutCallback.call();
				}
			}.bind(this),false);
			
			document.addEventListener('dragenter',function(e){
				e.stopPropagation();
				e.preventDefault();
				if(e.dataTransfer.types[0]==("Files")||e.dataTransfer.types[0]==("application/x-moz-file")){
					this.overlay.classList.remove('hide');
					this.overlay.querySelector('.drag-animating').classList.add('drag-over-animation');
				}
			
				
				if(this.options&&(this.options.hoverInCallback)&&(this.options.hoverInCallback instanceof Function)){
					this.options.hoverInCallback.call();
				}
			}.bind(this),false);
			
			document.addEventListener('dragend',function(e){
				e.stopPropagation();
				e.preventDefault();
			}.bind(this),false);
			
			document.addEventListener('drop',function(e){
				e.stopPropagation();
				e.preventDefault();
				if(e.dataTransfer.types[0]===("Files")||e.dataTransfer.types[0]===("application/x-moz-file")){
					this.overlay.classList.add('hide');
					this.overlay.querySelector('.drag-animating').classList.remove('drag-over-animation');
					_previewImageFile.call(this,e.dataTransfer.files[0]);
				}
			}.bind(this),false);
		}
	}
	
	function _previewImageFile(file){
		if (this.acceptedTypes[file.type] === true) {
		    var reader = new FileReader();
		    reader.onload = function (event) {
		      var image = this.imgContainer;
		      this.file = event.target.result;
		      image.src = this.file;
		      image.width = this.el.clientWidth;
		      image.height = this.el.clientHeight;
		      if(this.options&&this.options.endCallback&&(this.options.endCallback instanceof Function)){
					this.options.endCallback.call(this,file);
		      }
		    }.bind(this);
		    reader.readAsDataURL(file);
		}else{
			   if(this.options&&this.options.endCallback&&(this.options.endCallback instanceof Function)){
					this.options.error.call(this,file);
		      }
		}
	}
	return FileDropUpload;
});;
define('PathAnimate',[],function(){
	/**
	 * Animate an object svg or html along a svg path
	 * It creates an instance of PathAnimate
	 * @constructor PathAnimate
	 * @param {path} path 
	 */
	function PathAnimate(path){
		if(path){
			this.set(path);
		}
	}
	PathAnimate.prototype = {
			/**
			 * start Animating along the svg path 
			 * @method animate
			 * @memberof PathAnimate
			 * @param {number} duration
			 * @param {number} move function to be called on each movement of the animating object
			 * @param {number} startPercentage
			 * @param {number} endPercentage
			 * @param {function} callback function to be called after animation complete
			 */
			animate : function(duration,move,startPercentage,endPercentage,callback){
				this._duration = duration;
				this._startValue = startPercentage;
				this._endValue   = endPercentage; 
				this._startTime = Date.now();
				this._state = 0;
				this._pause = false;
				this._stopped = false;
				this._lapseTime = 0;
				this._callback = callback;
				this._move = move;
				this.animationLoop();
			},
			/**
			 * Update the animating point
			 * @method update
			 * @memberof PathAnimate
			 */
			animationLoop: function(){
				var timeStamp = Date.now(),
					timeSinceStart = timeStamp-this._startTime,
					self = this,
					point = [],
					angle;
					
			        if(this._pause){
			        	timeSinceStart = 0;
			        	return;
			        }
			        
			        if (timeSinceStart >= this._duration) {
			        	this._state = this._endValue;
			        	this._callback();
			        	this.cancelFrame();
			        	return;
			        }
			        else{
			            var t = timeSinceStart / this._duration;
			            this._lapseTime = timeSinceStart;
			            this._state = this.interpolate(this._startValue,this._endValue,t);
			        	point[0] = self.getPoint( this._state  - 1 );
			        	point[1] = self.getPoint( this._state  + 1 );
			        	angle = Math.atan2(point[1].y-point[0].y,point[1].x-point[0].x)*180 / Math.PI;
			        	if(!this._stopped){
			        		self._move.call( self, self.getPoint( this._state), angle );
			        	}
			        }
			        this.ID = requestAnimationFrame(function(){self.animationLoop();});
			        
			},
			/** 
			 * stop the animation, gives the lastpoint coordinates
			 * @method stop
			 * @memberof PathAnimate
			 */
			stop : function(){
				var point = [], angle;
			  	this._state = this._endValue;
			  	this._stopped = true;
	        	point[0] = this.getPoint( this._state  - 1 );
	        	point[1] = this.getPoint( this._state  + 1 );
	        	angle = Math.atan2(point[1].y-point[0].y,point[1].x-point[0].x)*180 / Math.PI;
	        	this._move.call( this, this.getPoint( this._state), angle );
	        	this.cancelFrame();
			},
			/**
			 * cancel the current animation frame
			 * @method cancelFrame
			 * @memberof PathAnimate
			 */
			cancelFrame :  function(){
				cancelAnimationFrame(this.ID);
			},
			/**
			 * get the point on the path 
			 * @method getPoint
			 * @param {number} percentage
			 * @memberof PathAnimate
			 */
			getPoint:function(percent){
					return this.path.getPointAtLength( this.length * percent/100 );
			},
			/**
			 * pause animating
			 * @method pause
			 * @memberof PathAnimate
			 */
			pause: function(){
				this._pause = true;
			},
			/**
			 * resume the paused animation
			 * @method play
			 * @memberof PathAnimate
			 */
			play : function(){
	        	this._startTime = Date.now();
	        	this._duration   = this._duration - this._lapseTime;
	        	this._startValue =  this._state;
				this._pause = false;
				this.animationLoop();
			},
			/**
			 * set the path
			 * @method set
			 * @memberof PathAnimate
			 * @param {path} path
			 */
			set :function(path){
				this.path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
				this.path.setAttribute('d', path);
				this.length = this.path.getTotalLength();
			},
			/**
			 * linear interpolation method
			 * @method interpolate
			 * @memberof PathAnimate
			 * @param {number} a startValue
			 * @param {number} b endValue
			 * @param {number} t normalized time (0->1]
			 */
		    interpolate :function (a, b, t) {
		        return ((1 - t) * a) + (t * b);
		    }
	};
	return PathAnimate;
});
;define('Resizable', ['Draggable'], function(Draggable) {
	
	/**
     * Creates an instance of Resizable.
     *
     * @constructor Resizable
     * @this {Resizable}
     * @param {object} desired options to the Resizable
     * @example
     * var resizable = new Resizable({
     * 		container : el,
	  * 	direction:{1:true,2:true,3:true,4:true}, // 1: top-left , 2: top-right , 3: bottom-right , 4: bottom-left 
	  * 	min_height:ypx,
	  * 	min_width:xpx	
     * 	});
     *
     */

	function Resizable(options){
		this.container = options.container;
		this.min_height = options.min_height;
		this.min_width = options.min_width;
		this.resizeCallback = options.resizeCallBack;
		this.rotatable = options.rotatable || false;
		for(var i in resizable_defaults){
			if(options[i]== undefined){
				options[i] = resizable_defaults[i]
			}
		}
		this.options = options;
		_init.call(this);
	 }
	
	
	
	var resizable_defaults = {
			direction:{
				3: true
			}
	} 

		function _init(){
		this.handle_top_left = this.create('div', 'handle_top_left');
		this.handle_top_right = this.create('div', 'handle_top_right');
		this.handle_bottom_right = this.create('div', 'handle_bottom_right');
		this.handle_bottom_left = this.create('div', 'handle_bottom_left');
		this.handle_mid_top = this.create('div', 'handle_mid_top');
		this.handle_mid_right = this.create('div', 'handle_mid_right');
		this.handle_mid_bottom = this.create('div', 'handle_mid_bottom');
		this.handle_mid_left = this.create('div', 'handle_mid_left');
		
		this.handle_rotate = this.create('div', 'handle_rotate');
		
		this.handle = {
				"1":this.handle_top_left,
				"2":this.handle_top_right,
				"3":this.handle_bottom_right,
				"4":this.handle_bottom_left,
				"5":this.handle_mid_top,
				"6":this.handle_mid_right,
				"7":this.handle_mid_bottom,
				"8":this.handle_mid_left
		}
		this._draggableHandles = [];
		_bind_resize_event.call(this);
		this.container.classList.add("resizableElement");
	}
	function _bind_resize_event(){
		if(this.options.direction[3]){
			var draggableHandle = new Draggable({
				el :this.handle[3],
				resizeHandle : true,
				startCallBack:function(data){
					this.startPosX = data.x;
					this.startPosY = data.y;
					this.initialHeight = parseFloat(this.container.style.height)||this.container.clientHeight;
					this.initialWidth = parseFloat(this.container.style.width)||this.container.clientWidth;
				}.bind(this),
				moveCallBack:function(data){
					//code for resize parent
					this.currentPosX = data.x;
					this.currentPosY = data.y;	
					this.container.style.height = this.initialHeight + (this.currentPosY- this.startPosY)+'px';
					this.container.style.width  = this.initialWidth +  (this.currentPosX- this.startPosX)+'px';
					
					this.resizeCallback({
						height : this.container.style.height,
						width : this.container.style.width,
					});
				}.bind(this)
			});
			this._draggableHandles.push(draggableHandle);
			this.container.appendChild(this.handle[3]);
		}
		if(this.options.direction[2]){
			var draggableHandle = new Draggable({
				el :this.handle[2],
				resizeHandle : true,
				startCallBack:function(data){
					this.startPosX = data.x;
					this.startPosY = data.y;
					this.leftPos = 	this.container.offsetLeft;
					this.topPos = 	this.container.offsetTop;
					this.initialHeight = parseFloat(this.container.style.height)||this.container.clientHeight;
					this.initialWidth = parseFloat(this.container.style.width)||this.container.clientWidth;
				}.bind(this),
				moveCallBack:function(data){
					//code for resize parent
					this.currentPosX = data.x;
					this.currentPosY = data.y;	
					this.container.style.top = this.topPos + (this.currentPosY- this.startPosY)+'px';
					this.container.style.height = this.initialHeight - (this.currentPosY- this.startPosY)+'px';
					this.container.style.width  = this.initialWidth +  (this.currentPosX- this.startPosX)+'px';
					
					this.resizeCallback({
						height : this.container.style.height,
						width : this.container.style.width,
					});
				}.bind(this)
			});
			this._draggableHandles.push(draggableHandle);
			this.container.appendChild(this.handle[2]);
		}
		if(this.options.direction[1]){
			var draggableHandle = new Draggable({
				el :this.handle[1],
				resizeHandle : true,
				startCallBack:function(data){
					this.startPosX = data.x;
					this.startPosY = data.y;
					this.leftPos = 	this.container.offsetLeft;
					this.topPos = 	this.container.offsetTop;
					this.initialHeight = parseFloat(this.container.style.height)||this.container.clientHeight;
					this.initialWidth = parseFloat(this.container.style.width)||this.container.clientWidth;
				}.bind(this),
				moveCallBack:function(data){
					//code for resize parent
					this.currentPosX = data.x;
					this.currentPosY = data.y;	
					this.container.style.top = this.topPos + (this.currentPosY- this.startPosY)+'px';
					this.container.style.left = this.leftPos + (this.currentPosX- this.startPosX)+'px';
					this.container.style.height = this.initialHeight - (this.currentPosY- this.startPosY)+'px';
					this.container.style.width  = this.initialWidth - (this.currentPosX- this.startPosX)+'px';
					
					this.resizeCallback({
						height : this.container.style.height,
						width : this.container.style.width,
					});
				}.bind(this)
			});
			this._draggableHandles.push(draggableHandle);
			this.container.appendChild(this.handle[1]);
		}	
		if(this.options.direction[4]){
			var draggableHandle = new Draggable({
				el :this.handle[4],
				resizeHandle : true,
				startCallBack:function(data){
					this.startPosX = data.x;
					this.startPosY = data.y;
					this.leftPos = 	this.container.offsetLeft;
					this.topPos = 	this.container.offsetTop;
					this.initialHeight = parseFloat(this.container.style.height)||this.container.clientHeight;
					this.initialWidth = parseFloat(this.container.style.width)||this.container.clientWidth;
				}.bind(this),
				moveCallBack:function(data){
					//code for resize parent
					this.currentPosX = data.x;
					this.currentPosY = data.y;	
					this.container.style.left = this.leftPos + (this.currentPosX- this.startPosX)+'px';
					this.container.style.height = this.initialHeight + (this.currentPosY- this.startPosY)+'px';
					this.container.style.width  = this.initialWidth - (this.currentPosX- this.startPosX)+'px';
					
					this.resizeCallback({
						height : this.container.style.height,
						width : this.container.style.width,
					});
				}.bind(this)
			});
			this._draggableHandles.push(draggableHandle);
			this.container.appendChild(this.handle[4]);
		}
		if(this.options.direction[5]){
			var draggableHandle = new Draggable({
				el :this.handle[5],
				resizeHandle : true,
				startCallBack:function(data){
					this.startPosX = data.x;
					this.startPosY = data.y;
					this.leftPos = 	this.container.offsetLeft;
					this.topPos = 	this.container.offsetTop;
					this.initialHeight = parseFloat(this.container.style.height)||this.container.clientHeight;
					this.initialWidth = parseFloat(this.container.style.width)||this.container.clientWidth;
				}.bind(this),
				moveCallBack:function(data){
					//code for resize parent
					this.currentPosX = data.x;
					this.currentPosY = data.y;	
					this.container.style.top = this.topPos + (this.currentPosY- this.startPosY)+'px';
					this.container.style.height = this.initialHeight - (this.currentPosY- this.startPosY)+'px';
					
					this.resizeCallback({
						height : this.container.style.height,
						width : this.container.style.width,
					});
				}.bind(this)
			});
			this._draggableHandles.push(draggableHandle);
			this.container.appendChild(this.handle[5]);
		}
		
		if(this.options.direction[6]){
			var draggableHandle = new Draggable({
				el :this.handle[6],
				resizeHandle : true,
				startCallBack:function(data){
					this.startPosX = data.x;
					this.startPosY = data.y;
					this.leftPos = 	this.container.offsetLeft;
					this.topPos = 	this.container.offsetTop;
					this.initialHeight = parseFloat(this.container.style.height)||this.container.clientHeight;
					this.initialWidth = parseFloat(this.container.style.width)||this.container.clientWidth;
				}.bind(this),
				moveCallBack:function(data){
					//code for resize parent
					this.currentPosX = data.x;
					this.currentPosY = data.y;	
					this.container.style.width  = this.initialWidth +(this.currentPosX- this.startPosX)+'px';
					this.resizeCallback({
						height : this.container.style.height,
						width : this.container.style.width,
					});
				}.bind(this)
			});
			this._draggableHandles.push(draggableHandle);
			this.container.appendChild(this.handle[6]);
		}
		
		if(this.options.direction[7]){
			var draggableHandle = new Draggable({
				el :this.handle[7],
				resizeHandle : true,
				startCallBack:function(data){
					this.startPosX = data.x;
					this.startPosY = data.y;
					this.leftPos = 	this.container.offsetLeft;
					this.topPos = 	this.container.offsetTop;
					this.initialHeight = parseFloat(this.container.style.height)||this.container.clientHeight;
					this.initialWidth = parseFloat(this.container.style.width)||this.container.clientWidth;
				}.bind(this),
				moveCallBack:function(data){
					//code for resize parent
					this.currentPosX = data.x;
					this.currentPosY = data.y;	
					this.container.style.height = this.initialHeight + (this.currentPosY- this.startPosY)+'px';
					
					this.resizeCallback({
						height : this.container.style.height,
						width : this.container.style.width,
					});
				}.bind(this)
			});
			this._draggableHandles.push(draggableHandle);
			this.container.appendChild(this.handle[7]);
		}
		
		if(this.options.direction[8]){
			var draggableHandle = new Draggable({
				el :this.handle[8],
				resizeHandle : true,
				startCallBack:function(data){
					this.startPosX = data.x;
					this.startPosY = data.y;
					this.leftPos = 	this.container.offsetLeft;
					this.topPos = 	this.container.offsetTop;
					this.initialHeight = parseFloat(this.container.style.height)||this.container.clientHeight;
					this.initialWidth = parseFloat(this.container.style.width)||this.container.clientWidth;
				}.bind(this),
				moveCallBack:function(data){
					//code for resize parent
					this.currentPosX = data.x;
					this.currentPosY = data.y;	
					this.container.style.left = this.leftPos + (this.currentPosX- this.startPosX)+'px';
					this.container.style.width  = this.initialWidth - (this.currentPosX- this.startPosX)+'px';
					
					this.resizeCallback({
						height : this.container.style.height,
						width : this.container.style.width,
					});
				}.bind(this)
			});
			this._draggableHandles.push(draggableHandle);
			this.container.appendChild(this.handle[8]);
		}
		
		if(this.rotatable){
			var draggableHandle = new Draggable({
				el :this.handle_rotate,
				resizeHandle : true,
				startCallBack:function(data){
					this.startPosX = data.x;
					this.startPosY = data.y;
					this.transform = this.container.style.webkitTransform || this.container.style.transform;


				}.bind(this),
				moveCallBack:function(data){
					//code for rotate parent
					this.currentPosX = data.x;
					this.currentPosY = data.y;	
				
				/*	this.container.style.webkitTransform = this.transform + "rotate("++"deg)";*/
					this.resizeCallback({
						height : this.container.style.height,
						width : this.container.style.width,
					});
				}.bind(this)
			});
			this.container.appendChild(this.handle_rotate);
		}
	}
	Resizable.prototype.create = function(type,className){
		var el = document.createElement(type);
		el.classList.add(className);
		return el;
	}	
	
	
	 /**
     * remove Resizable
     * @memberof Resizable
     * @method removeResizable
     * @this {Resizable}
     */
	
	Resizable.prototype.removeResizable = function(){

		this.container.removeChild(this.handle_top_left);
		this.container.removeChild(this.handle_top_right);
		this.container.removeChild(this.handle_bottom_right);
		this.container.removeChild(this.handle_bottom_left);
		this.container.removeChild(this.handle_mid_top);
		this.container.removeChild(this.handle_mid_right);
		this.container.removeChild(this.handle_mid_bottom);
		this.container.removeChild(this.handle_mid_left);
		
		this.container.classList.remove("resizableElement");
		this.container.removeAttribute("style");
	}
	return Resizable

});;define('StaticObject',['EventHandler'],function(eventHandler){

/**
 * creates a instance of static objects. For examples, normal text elements, containers,also provides support for eventHandling
 * @constructor StaticObject
 * @param {object} options
 */
	function StaticObject(options){
		if(!options.name){
			console.erroe('name for a StaticObject is compulsory');
			return;
		}
			this.innerContent = "" || options.innerContent;
			this.name = options.name;
			this.elementType = options.type || "div";
			this.parent = options.parent || undefined;
			this.styles = {};
			this.eventHandler = new eventHandler();
			this.eventHandler.bindThis(this);
			this.classes = options.classes || [];
            this.eventForwarder = function(event) 
            {
                this.eventHandler.emit(event.type, event);
            }.bind(this);
			this.set(this.elementType);
	}
	StaticObject.prototype.Events = [
                                  "touchstart", 
                                  "touchmove", 
                                  "touchend", 
                                  "touchcancel", 
                                  "click", 
                                  "mousedown", 
                                  "mouseup", 
                                  "mousemove", 
                                  "mouseover", 
                                  "mouseout", 
                                  "mouseenter", 
                                  "mouseleave"
                              ];
	
	/**
	 * addClass from StaticObjectect, take a single classes or array containing different classes, chaining is also allowed
	 * @method addClass
	 * @param {class | class[]} class addclass or array of class
	 * @memberof StaticObject
	 * @returns {StaticObject}
	 */
	StaticObject.prototype.addClass = function(cls){
		if(cls instanceof Array)
			{
				for(var i = 0; i < cls.length; i++)
					this.el.classList.add(cls[i]);
			}
		else
		this.el.classList.add(cls);
		return this;
	};
	/**
	 * removeClass from StaticObject, take a single classes or array containing different classes, chaining is also allowed
	 * @method removeClass
	 * @param {class | class[]} class addclass or array of class
	 * @memberof StaticObject
	 * @returns {StaticObject}
	 */
	StaticObject.prototype.removeClass = function(cls){
		if(cls instanceof Array)
		{
			for(var i = 0; i < cls.length; i++)
				this.el.classList.remove(cls[i]);
		}
	else
	this.el.classList.remove(cls);
		return this;
	};


/**
 * set CSS style of the simOject.take an array as argument
 * @method setStyle
 * @memberof StaticObject
 * @param {object} styles
 * @returns {StaticObject}
 */
	StaticObject.prototype.setStyle = function(styles) {
		 for (var n in styles) {
			 if(styles.hasOwnProperty(n)){
		          this.styles[n] = styles[n]; 
			 }
		 }
        for (var n in styles) {
			 if(styles.hasOwnProperty(n)){
		          this.el.style[n] = this.styles[n]; 
			 }
        }
        return this;
    };
	/**
	 * remove inline CSS style from the StaticObject
	 * @method removeStyle
	 * @memberof StaticObject
	 * @returns {StaticObject}
	 */
	StaticObject.prototype.removeStyle = function() {
        for (var n in this.styles) {
        	if(this.styles.hasOwnProperty(n)){
                this.el.style[n] = '';	
        	}
        }
        return this;
    };
	/**
	 * eventListener for the StaticObject. chaining is not allowed at present
	 * @method on
	 * @memberof StaticObject
	 */
	StaticObject.prototype.on = function(eventType,handler){
		this.eventHandler.on(eventType, handler,this);
	};
	/**
	 * remove eventListener form the StaticObject. chaining is not allowed at present
	 * @method off
	 * @memberof StaticObject
	 */
	StaticObject.prototype.off = function(eventType,handler){
		this.eventHandler.off(eventType,handler);
	};
	/**
	 * trigger eventListener of the StaticObject. chaining is not allowed at present. currently doesnot supports DOM events
	 * @method emit
	 * @memberof StaticObject
	 * @this {StaticObject}
	 */
	StaticObject.prototype.emit = function(eventType,eventData){
		this.eventHandler.emit(eventType,eventData,this);
	};
	/**
	 * InnerContent of the StaticObject can be added. accepts string or HTML snippets, chaining is allowed
	 * @method addInnerContent
	 * @memberof StaticObject
	 * @param {sting | HTML} content string or HTML
	 * @retuns {this}
	 */
	StaticObject.prototype.addInnerContent = function(content){
		this.el.innerHTML = content;
	};
	
    /**
     * add background image to the StaticObject
     * @method background
     * @memberof SoModel
     * @param {string} url url of the image
     */
	StaticObject.prototype.background = function(url){
		this.el.style.backgroundImage = 'url('+url+')';
		return this;
	};
	
	/**
	 * empty StaticObject
	 * @method removeInnerContent
	 * @memberof StaticObject
	 * @retuns {this}
	 */
	StaticObject.prototype.removeInnerContent = function(){
		this.el.innerHTML = "";
	};
	
	
	/**
	 * add another static/simObject to this object
	 * @method addSimObject
	 * @memberof StaticObject
	 * @param {staticobject[]} staticobject
	 */
	StaticObject.prototype.addsimObject  = function(staticobject){
		if(staticobject instanceof Array)	{
			 for(var i = 0; i < staticobject.length ; i++)
				 this.el.appendChild(staticobject[i].el);
			}else
		      this.el.appendChild(staticobject.el);
	};
	
	function bindEvents(target){
        for (var i = this.Events, j = 0; j < i.length; j++) {
        	target.addEventListener(i[j], this.eventForwarder);
        }
	}
	StaticObject.prototype.set = function(type){
			this.el = document.createElement(type);
			this.el.id = this.name;
			var length = this.classes.length;
				for(var i=0;i<length;i++)
					this.addClass(this.classes[i]);
			
			bindEvents.call(this,this.el);
		};
	
	StaticObject.prototype.render = function(parent){
		if(this.parent !== undefined){
			this.parent.appendChild(this.el);
		}
		else{
		this.parent = parent;
		parent.appendChild(this.el);
		}
	};
	
	return StaticObject;
});
;
define('ajax',[],function(){
	
	/**
	 * @namespace ajax
	 */
	var ajax = {};
	
	/**
	 * AJAX GET method
	 * @method loadURL
	 * @memberof ajax
	 * @param {string} URI to the location
	 * @param {function | object} callback function callback to the ajax request, if Object is passed callback would be included inside the object
	 */
    ajax.loadURL = function(url,options) {
    	var callback = options,
        xhr = new XMLHttpRequest();
    	
    	if(options instanceof Object && !(options instanceof Function)){
           callback = options.callback;
            for(var x in options){
            	if(options.hasOwnProperty(x)){
            		xhr[x] = options[x];	
            	}
            }
    	}
    	
        xhr.onreadystatechange = function() {
            if(this.readyState === 4) {
                if(callback) callback(this);
            }
        };
        xhr.open('GET', url);
        xhr.send();
    };
    
    /**
     * AJAX POST method
     * @method send
     * @memberof ajax
     * @param {string} URI to the location
     * @param {function | object} callback function callback to the ajax request, if Object is passed callback would be included inside the object
     */
    ajax.send  = function(url,options){
    	var callback = options,
    		message,
    		xhr = new XMLHttpRequest();
    	xhr.withCredentials = true;
    	
    	if(options.message){
    		message = options.message;
    	}
    	
    	if(options instanceof Object && !(options instanceof Function)){
            callback = options.callback;
             for(var x in options){
             	if(options.hasOwnProperty(x)){
             		xhr[x] = options[x];	
             	}
             }
     	}
    	
    	xhr.onreadystatechange = function(){
    		if(this.readyState === 4){
    			callback.call(callback, this.responseText );
    		}
    	};
    	xhr.open("POST", url);
    	xhr.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
    	if(message)
    	xhr.send(JSON.stringify(message));
    	else
    	xhr.send();
    };
    
    /**
     * AJAX POST method, post form data to the specified URI
     * @method sendFormData
     * @memberof ajax
     * @param {string} URI to the location
     * @param {function | object} callback function callback to the ajax request, if Object is passed callback would be included inside the object
     */
   ajax.sendFormData = function(url,options){
	   	var callback = options,
	   		message,
	   		xhr = new XMLHttpRequest();
	   	xhr.withCredentials = true;
	   	
	   	if(options.message){
    		message = options.message;
    	}
	   	
	   	if(options instanceof Object && !(options instanceof Function)){
            callback = options.callback;
             for(var x in options){
             	if(options.hasOwnProperty(x)){
             		xhr[x] = options[x];	
             	}
             }
     	}
	   	
		xhr.onreadystatechange = function(){
			if(this.readyState === 4){
				callback.call(callback, JSON.parse(this.responseText).response );
			}
		};
		xhr.open("POST", url);
		xhr.send(message);
   };
   
    return ajax;
	
});;      	
define('keyCode',[],function(){

var keyCodes = {
            0: 48,
            1: 49,
            2: 50,
            3: 51,
            4: 52,
            5: 53,
            6: 54,
            7: 55,
            8: 56,
            9: 57,
            A: 65,
            B: 66,
            C: 67,
            D: 68,
            E: 69,
            F: 70,
            G: 71,
            H: 72,
            I: 73,
            J: 74,
            K: 75,
            L: 76,
            M: 77,
            N: 78,
            O: 79,
            P: 80,
            Q: 81,
            R: 82,
            S: 83,
            T: 84,
            U: 85,
            V: 86,
            W: 87,
            X: 88,
            Y: 89,
            Z: 90,
            a: 97,
            b: 98,
            c: 99,
            d: 100,
            e: 101,
            f: 102,
            g: 103,
            h: 104,
            i: 105,
            j: 106,
            k: 107,
            l: 108,
            m: 109,
            n: 110,
            o: 111,
            p: 112,
            q: 113,
            r: 114,
            s: 115,
            t: 116,
            u: 117,
            v: 118,
            w: 119,
            x: 120,
            y: 121,
            z: 122,
            ENTER: 13,
            LEFT_ARROW: 37,
            RIGHT_ARROW: 39,
            UP_ARROW: 38,
            DOWN_ARROW: 40,
            SPACE: 32,
            SHIFT: 16,
            TAB: 9,
            ESC:27
        };

return keyCodes
});;define('rAF',[],function(){
	window.requestAnimationFrame = function(){

		return (
			window.requestAnimationFrame       || 
			window.webkitRequestAnimationFrame || 
			window.mozRequestAnimationFrame    || 
			window.oRequestAnimationFrame      || 
			window.msRequestAnimationFrame     || 
			function(callback){
				window.setTimeout(callback, 1000 / 60);
			}
		);
	}();
	window.cancelAnimationFrame = function(){
		
		return (
			window.cancelAnimationFrame       || 
			window.webkitCancelAnimationFrame || 
			window.mozCancelAnimationFrame    || 
			window.oCancelAnimationFrame      || 
			window.msCancelAnimationFrame     || 
			function(id){
				window.clearTimeout(id);
			}
		);
	}();
	
});;
define('ShareViaEmail',[], function() {
	"use strict";


    var Base64 = {
 
        // private property
        _keyStr : "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",
     
        // public method for encoding
        encode : function (input) {
            var output = "";
            var chr1, chr2, chr3, enc1, enc2, enc3, enc4;
            var i = 0;
     
            input = Base64._utf8_encode(input);
     
            while (i < input.length) {
     
                chr1 = input.charCodeAt(i++);
                chr2 = input.charCodeAt(i++);
                chr3 = input.charCodeAt(i++);
     
                enc1 = chr1 >> 2;
                enc2 = ((chr1 & 3) << 4) | (chr2 >> 4);
                enc3 = ((chr2 & 15) << 2) | (chr3 >> 6);
                enc4 = chr3 & 63;
     
                if (isNaN(chr2)) {
                    enc3 = enc4 = 64;
                } else if (isNaN(chr3)) {
                    enc4 = 64;
                }
     
                output = output +
                this._keyStr.charAt(enc1) + this._keyStr.charAt(enc2) +
                this._keyStr.charAt(enc3) + this._keyStr.charAt(enc4);
     
            }
     
            return output;
        },
     
        // public method for decoding
        decode : function (input) {
            var output = "";
            var chr1, chr2, chr3;
            var enc1, enc2, enc3, enc4;
            var i = 0;
     
            input = input.replace(/[^A-Za-z0-9\-_\.]/g, "");
     
            while (i < input.length) {
     
                enc1 = this._keyStr.indexOf(input.charAt(i++));
                enc2 = this._keyStr.indexOf(input.charAt(i++));
                enc3 = this._keyStr.indexOf(input.charAt(i++));
                enc4 = this._keyStr.indexOf(input.charAt(i++));
     
                chr1 = (enc1 << 2) | (enc2 >> 4);
                chr2 = ((enc2 & 15) << 4) | (enc3 >> 2);
                chr3 = ((enc3 & 3) << 6) | enc4;
     
                output = output + String.fromCharCode(chr1);
     
                if (enc3 != 64) {
                    output = output + String.fromCharCode(chr2);
                }
                if (enc4 != 64) {
                    output = output + String.fromCharCode(chr3);
                }
     
            }
     
            output = Base64._utf8_decode(output);
     
            return output;
     
        },
     
        // private method for UTF-8 encoding
        _utf8_encode : function (string) {
            string = string.replace(/\r\n/g,"\n");
            var utftext = "";
     
            for (var n = 0; n < string.length; n++) {
     
                var c = string.charCodeAt(n);
     
                if (c < 128) {
                    utftext += String.fromCharCode(c);
                }
                else if((c > 127) && (c < 2048)) {
                    utftext += String.fromCharCode((c >> 6) | 192);
                    utftext += String.fromCharCode((c & 63) | 128);
                }
                else {
                    utftext += String.fromCharCode((c >> 12) | 224);
                    utftext += String.fromCharCode(((c >> 6) & 63) | 128);
                    utftext += String.fromCharCode((c & 63) | 128);
                }
     
            }
     
            return utftext;
        },
     
        // private method for UTF-8 decoding
        _utf8_decode : function (utftext) {
            var string = "";
            var i = 0;
            var c = c1 = c2 = 0;
     
            while ( i < utftext.length ) {
     
                c = utftext.charCodeAt(i);
     
                if (c < 128) {
                    string += String.fromCharCode(c);
                    i++;
                }
                else if((c > 191) && (c < 224)) {
                    c2 = utftext.charCodeAt(i+1);
                    string += String.fromCharCode(((c & 31) << 6) | (c2 & 63));
                    i += 2;
                }
                else {
                    c2 = utftext.charCodeAt(i+1);
                    c3 = utftext.charCodeAt(i+2);
                    string += String.fromCharCode(((c & 15) << 12) | ((c2 & 63) << 6) | (c3 & 63));
                    i += 3;
                }
     
            }
     
            return string;
        },

        jqSafe : function(str) {
            str = str.replace(/\./g, '\\.');
            return str.replace(/:/g, '\\:');
        }
     
    }

    function initializeModal() {
        var options = {},
            closeTimeout,
            openTimeout,
            hostPath;

        //load the google classroom JS
        //Keeping it here, to reduce dependency on <script> tag in other files.
        if(!document.getElementById('googleClassroomScript')) {
            window.___gcfg = {
                parsetags: 'explicit'
            };

            var gcScript = document.createElement('SCRIPT');
            gcScript.id = 'googleClassroomScript';
            gcScript.setAttribute("type", "text/javascript");
            gcScript.setAttribute("src", "https://apis.google.com/js/platform.js");
            document.head.appendChild(gcScript);
        }


        function open(dataOptions) {
            hostPath = dataOptions._ck12 ? '' : window.shareRootPath;
            if(!document.getElementById('shareEmailCss')) {
                var link = document.createElement('LINK');
                link.id = 'shareEmailCss';
                link.setAttribute("type", "text/css");
                link.setAttribute("href", hostPath + "/media/common/css/share.via.email.css");
                link.setAttribute("rel", "stylesheet");
                document.head.appendChild(link);
            }

            if(dataOptions) {
                options.shareImage = dataOptions.shareImage || '';
                options.shareTitle = dataOptions.shareTitle || '';
                options.resourceType = dataOptions.resourceType || 'resource';
                options.shareUrl = dataOptions.shareUrl || '';
                options.shareBody = dataOptions.shareBody || '';
                options.userSignedIn = dataOptions.userSignedIn || false;
                options.shareContext =  dataOptions.context || 'Share this Resource';
                options.sharePayload = dataOptions.payload || {};
                options.purpose = dataOptions.purpose || 'share';
                options.userEmail = dataOptions.userEmail;
                options.eventType = dataOptions.eventType || 'fbs_share';
                options.shareType = dataOptions.shareType || 'shareoplane';
                options.disableSocialShare = dataOptions.disableSocialShare || false;
                options.disableShareLink = dataOptions.disableShareLink || false;
            }
            logShareAds(options.eventType, options.shareType);
            if(link) {
                link.onload = function(){
                    buildOut();
                }
            } else {
                buildOut();
            }
        }
        function close() {
            clearTimeout(openTimeout);
            options.modal.classList.remove('share-open');
            options.modal.style.top = "-1000px";
            options.overlay.classList.remove('share-open');
            closeTimeout = setTimeout(function(){
                options.overlay.classList.add('hide');
            }, 800);
            var e = document.createEvent('Events');
            e.initEvent("shareClose", true, true);
            document.dispatchEvent(e);
        }
        function buildOut() {
            if(document.getElementById("shareViaEmailModal")) {
                clearTimeout(closeTimeout);
                options.modal.classList.add('share-open');
                openTimeout = setTimeout(function(){
                    options.overlay.classList.add('share-open');
                }, 200);
                options.overlay.classList.remove('hide');
                options.modal.style.top = (window.scrollY || window.pageYOffset) + 100 + "px";
                document.getElementById("email-box-container").classList.remove('hide');
                document.getElementById("email-sent-thanks").classList.add('hide');
                renderPopUp();
            } else {
              //Get the html for share email modal.
                var xmlhttp;
                xmlhttp = new XMLHttpRequest();
                xmlhttp.onreadystatechange = function() {
                    if (xmlhttp.readyState == 4 && xmlhttp.status == 200 && !document.getElementById("shareViaEmailModal")) {
                        createPopup(xmlhttp.responseText);
                        initializeEvents.call();
                        renderPopUp();
                        options.modal.className = options.modal.className + " share-open";
                        options.overlay.className = options.overlay.className + " share-open";
                        options.modal.style.top = (window.scrollY || window.pageYOffset) + 100 + "px";
                    }
                };
                xmlhttp.open("GET", hostPath + "/media/common/js/templates/share.via.email.html", true);
                xmlhttp.send();
            }
        }
        function createPopup(content) {
            var contentHolder, docFrag;
            docFrag = document.createDocumentFragment();

            // Create modal element
            options.modal = document.createElement("div");
            options.modal.className = "share-via-email-modal";
            options.modal.id = "shareViaEmailModal";
            options.modal.style.top = '-1000px';

            options.overlay = document.createElement("div");
            options.overlay.className = "share-overlay";
            docFrag.appendChild(options.overlay);
            
            options.modal.innerHTML = content;
            options.closeButton = document.getElementsByClassName("js-close-share");

            docFrag.appendChild(options.modal);

            document.body.insertBefore(docFrag, document.body.firstChild);
        }

       function getUtmUrl(someUrl,medium,source,content) {
            //remove any existing utm params
            someUrl = removeParamFromUrl("utm_source",someUrl);
            someUrl = removeParamFromUrl("utm_medium",someUrl);
            someUrl = removeParamFromUrl("utm_campaign",someUrl);
            someUrl = removeParamFromUrl("utm_content",someUrl);
            var utmParams = (medium) ? "utm_medium=" + encodeURIComponent(medium) : "";
            utmParams += (source) ? "&utm_source=" + encodeURIComponent(source) : "";
            utmParams += (content) ? "&utm_content=" + encodeURIComponent(content) : "";
            utmParams += "&utm_campaign=product";

            if (someUrl.indexOf("?") !== -1) {
                someUrl = someUrl + "&" + utmParams;
            } else {
                someUrl = someUrl + "?" + utmParams;
            }
            return someUrl;
        }
        
        function renderPopUp() {
            var artifactLink = options.modal.getElementsByClassName("share-artifact-url"),
                shareImageElem = options.modal.getElementsByClassName("artifact-email-image"),
                shareTitleElem = options.modal.getElementsByClassName("share-artifact-title"),
                unregisteredUserRows = options.modal.getElementsByClassName("unregistered-user-row"),
                shareDetailsContainer = options.modal.getElementsByClassName("share-email-artifact-container"),
                ShareBodyElem = options.modal.getElementsByClassName("share-email-body"),
                inputElems = options.modal.getElementsByClassName("input-header"),
                facebookLink = options.modal.getElementsByClassName("share-facebook-link")[0],
                twitterLink = options.modal.getElementsByClassName("share-twitter-link")[0],
                pinterestLink = options.modal.getElementsByClassName("share-pinterest-link")[0],
                googleClassroomLink = options.modal.getElementsByClassName("share-google-classroom-link")[0],
                shareContextText = options.modal.getElementsByClassName("share-context")[0],
                index = 0,
                //shareContext is the only param that shows what type of share this is.
                //Use it for utm_content and replace any spaces with hyphens 
                context= options.shareContext.replace(/\s+/g,"-").trim().toLowerCase();

            if(artifactLink.length) {
                var aLink = getUtmUrl(options.shareUrl, "email","share-content-" + context);
                for(index = 0; index < artifactLink.length; index++) {
                    artifactLink[index].innerHTML = aLink;
                    artifactLink[index].setAttribute("href", aLink);
                }
            }
            if(shareImageElem.length) {
                for(index = 0; index < shareImageElem.length; index++) {
                    shareImageElem[index].setAttribute("src", options.shareImage);
                }
            }
            if(shareTitleElem.length) {
                for(index = 0; index < shareTitleElem.length; index++) {
                    shareTitleElem[index].textContent = options.shareTitle;
                }
            }
            if(ShareBodyElem.length) {
                for(index = 0; index < ShareBodyElem.length; index++) {
                    if(options.shareBody) {
                        shareDetailsContainer[index].style.display = 'none';
                        ShareBodyElem[index].innerHTML = options.shareBody;
                    } else {
                        shareDetailsContainer[index].style.display = 'inline-block';
                        if(options.resourceType === 'Discussion'){
                             ShareBodyElem[index].innerHTML = 'Hi! I\'d like to invite you to join the Forum at CK-12...';
                        }else{
                             ShareBodyElem[index].innerHTML = 'Hi! I have found this great resource at CK-12...';
                        }
                    }
                }
            }
            for(index = 0; index < inputElems.length; index++) {
                inputElems[index].value = '';
            }
            hideErrorelements( options.modal.getElementsByClassName("recepient-box")[0]);
            hideErrorelements(options.modal.getElementsByClassName("fullname-box")[0]);
            hideErrorelements(options.modal.getElementsByClassName("user-email-box")[0]);
            if(options.userSignedIn) {
                for(index = 0; index < unregisteredUserRows.length; index++) {
                    unregisteredUserRows[index].classList.add('hide');
                }
            }
            var socialLink = getUtmUrl(options.shareUrl, "social","share-content-" + context);
            facebookLink.href = 'https://www.facebook.com/sharer.php?u=' + encodeURIComponent(socialLink + "&utm_content=facebook");
            twitterLink.href = 'http://twitter.com?status=Check%20out%20this%20awesome%20resource%20I%20found%20via%20%40ck12foundation%3A' + encodeURIComponent(socialLink + "&utm_content=twitter");
            pinterestLink.href = 'https://www.pinterest.com/pin/create/button/?url=' + encodeURIComponent(socialLink + "&utm_content=pinterest");
           if(options.shareContext.match(/brainflex/gi)) {
                pinterestLink.href += '&media=' + window.location.protocol + '//' + window.location.host + '/assessment/ui/public/lib/summer/brainflex_fb_preview.png&description=' + options.shareTitle;
            } else {
                pinterestLink.href += '&media=' + options.shareImage + '&description=' + options.shareTitle;
            }

            if(googleClassroomLink) {
                googleClassroomLink.setAttribute("data-url", getUtmUrl(options.shareUrl, "lms","share-content-" + context,"google_classroom"));
            }
            if (typeof (gapi) !== "undefined" && typeof (gapi.sharetoclassroom) !== "undefined") {
                gapi.sharetoclassroom.go("google_classroom_share");
            }
            shareContextText.textContent = options.shareContext;
            if (options.disableSocialShare) {
                $(options.modal).addClass('disable-social-share');
            }
            if (options.disableShareLink) {
                $(options.modal).find('.share-artifact-url').addClass('disable-share-link');
            }
        }
        
        function parseEmail(email) {
            var regx = /(^<).+(>$)/gi;
            email =  email.replace(regx,function(match, patt1, patt2){return match.replace(patt1, '').replace(patt2, '');});
            return email;
        }

        function initializeEvents() {
            var sendShareMailElem = document.getElementById("sendShareEmail"),
                recepientListElem = document.getElementById("recepients-list"),
                emptyErrorMsg = options.modal.getElementsByClassName("empty-error-msg")[0],
                errorIcon = options.modal.getElementsByClassName("error-icon")[0],
                invalidMsg = options.modal.getElementsByClassName("invalid-email-msg")[0],
                emailBoxContainer = document.getElementById("email-box-container"),
                emailSentThanks = document.getElementById("email-sent-thanks"),
                loadingElem = document.getElementById("share-mail-loading-icon"),
                pageDisableElem = document.getElementById("share-email-page-disable"),
                userFullname = document.getElementById("share-sender-name"),
                fullnameErrorMsg = document.getElementById("fullname-error-msg"),
                senderEmail = document.getElementById("share-sender-mail"),
                senderEmailErrorMsg = document.getElementById("sender-email-error-msg"),
                senderEmailInvalidMsg = document.getElementById("sender-email-invalid-msg"),
                socialShareLinks = options.modal.getElementsByClassName("socialshare"),
                i;
                
            recepientListElem.addEventListener('keyup', function() {
                hideErrorelements(recepientListElem);
            });
            recepientListElem.addEventListener('paste', function() {
                hideErrorelements(recepientListElem);
            });
            userFullname.addEventListener('keyup', function() {
                hideErrorelements(userFullname);
            });
            senderEmail.addEventListener('keyup', function() {
                hideErrorelements(senderEmail);
            });
            sendShareMailElem.addEventListener('click', function() {
                var recipientEmailList = recepientListElem.value,
                    emailList = recipientEmailList.split(','),
                    nameValid = true,
                    emailValid = true,
                    senderEmailValid = true,
                    senderEmailValue = senderEmail.value,
                    i;
                if(!userFullname.parentElement.classList.contains('hide') && userFullname.value.trim() === '') {
                    fullnameErrorMsg.classList.remove('hide');
                    userFullname.classList.add('input-required');
                    nameValid = false;
                }

                if(!senderEmail.parentElement.classList.contains('hide')) {
                   if(senderEmailValue.trim() === '') {
                    senderEmailErrorMsg.classList.remove('hide');
                    senderEmail.classList.add('input-required');
                    senderEmailValid = false;
                    } else {
                        senderEmailValue = parseEmail(senderEmailValue);
                        if(!validateEmail(senderEmailValue.trim())) {
                            senderEmail.classList.add('input-required');
                            senderEmailInvalidMsg.classList.remove('hide');
                            senderEmailValid = false;
                        }
                    }
                }

                if(recepientListElem.value.trim() === '') {
                    recepientListElem.classList.add('input-required');
                    emptyErrorMsg.classList.remove('hide');
                    errorIcon.classList.remove('hide');
                    emailValid = false;
                } else {
                    for(i=0; i<emailList.length; i++) {
                        emailList[i] = parseEmail(emailList[i]);
                        if(!validateEmail(emailList[i])) {
                            recepientListElem.classList.add('input-required');
                            invalidMsg.classList.remove('hide');
                            errorIcon.classList.remove('hide');
                            emailValid = false;
                        } else {
                            emailValid = true;
                        }
                    }
                    recipientEmailList = emailList.join();
                }
                if(nameValid && emailValid && senderEmailValid) {
                    loadingElem.classList.remove('hide');
                    pageDisableElem.classList.remove('hide');
                    var xmlhttp, emailData, emailResponse, emailBody = document.getElementById("share-email-template").cloneNode(true);
                    if(options.shareBody) {
                        emailBody.removeChild(emailBody.getElementsByClassName('share-email-artifact-container')[0]);
                    }
                    xmlhttp = new XMLHttpRequest();
                    xmlhttp.onreadystatechange = function() {
                        if(xmlhttp.readyState == 4) {
                            if (xmlhttp.status == 200) {
                                emailResponse = JSON.parse(xmlhttp.response);
                                if(emailResponse.response.hasOwnProperty('message')) {
                                    if (emailResponse.responseHeader.status === 10001) {
                                        //log email quota to ADS
                                        logShareAds("fbs_share_email_quota_exceeded","email");
                                    }
                                    alert(emailResponse.response.message);
                                } else {
                                    emailBoxContainer.classList.add('hide');
                                    emailSentThanks.classList.remove('hide');
                                }
                            } else {
                                alert("Sorry, We couldn't perform this action. Please try again after sometime.");
                            }
                            loadingElem.classList.add('hide');
                            pageDisableElem.classList.add('hide');
                        }
                    }
                    xmlhttp.open("POST", hostPath + "/api/flx/send/email", true);
                    xmlhttp.setRequestHeader("Accept","*/*");
                    xmlhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
                    xmlhttp.withCredentials=true;
                    var emailDataJSON = {
                        'receivers': recipientEmailList,
                        'subject': options.shareTitle,
                        'body': emailBody.innerHTML,
                        'senderName' : document.getElementById('share-sender-name').value,
                        'senderEmail': senderEmailValue,
                        'purpose': options.purpose
                    };
                    var encodedData = Base64.encode(JSON.stringify(emailDataJSON));
                    emailData = ('data='+encodeURIComponent( encodedData )).replace(/%20/g, '+');
                    xmlhttp.send(emailData);
                    logShareAds('fbs_share_complete');
                }
            });
            
            for(i = 0; i < socialShareLinks.length; i++) {
                socialShareLinks[i].addEventListener('click', function() {
                    logShareAds('fbs_share', this.dataset.sharetype);
                });
            }
            
            for(i = 0; i < options.closeButton.length; i++) {
                options.closeButton[i].addEventListener('click', close);
            }
            options.overlay.addEventListener('click', close);
        }

        function transitionSelect() {
            var el = document.createElement("div");
            if (el.style.WebkitTransition) return "webkitTransitionEnd";
            if (el.style.OTransition) return "oTransitionEnd";
            return 'transitionend';
        }
    
        function validateEmail(value) {
            return (/(^[-!#$%&'*+\/=?^_`{}|~0-9A-Z]+(\.[-!#$%&'*+\/=?^_`{}|~0-9A-Z]+)*|^"([\001-\010\013\014\016-\037!#-\[\]-\177]|\\[\001-011\013\014\016-\177])*")@(?:[A-Z0-9]+(?:-*[A-Z0-9]+)*\.)+[A-Z]{2,6}$/i).test(value.trim());
        }

        function hideErrorelements(temp) {
            temp.classList.remove('input-required');
            while(temp.previousElementSibling) {
                temp.previousElementSibling.classList.add('hide');
                temp = temp.previousElementSibling;
            }
        }

        function logShareAds(eventType, shareType) {
            if(eventType === 'fbs_share_complete') {
                options.sharePayload["from_email"] = options.userEmail || document.getElementById('share-sender-mail').value || '';
                options.sharePayload["to_email"] = document.getElementById('recepients-list').value;
            }
            options.sharePayload["url"] = options.shareUrl;
            options.sharePayload["social_network"] = shareType || '';
            if(options.sharePayload.hasOwnProperty('timestamp')) {
                delete options.sharePayload["timestamp"];
            }
            if(window.dexterjs) {
                var payload = JSON.parse(JSON.stringify(options.sharePayload));
                window.dexterjs.logEvent(eventType, payload);
            }
            //log to GA as well
            dataLayer = window.dataLayer || {};
            var gtmPayload = {};
            gtmPayload['event'] = eventType;
            for (var property in options.sharePayload) {
                gtmPayload[property] = options.sharePayload[property];
            }
            dataLayer.push(gtmPayload);
        }

        function removeParamFromUrl(parameter, url) {
            return url
                .replace(new RegExp('[?&]' + parameter + '=[^&#]*(#.*)?$'), '$1')
                .replace(new RegExp('([?&])' + parameter + '=[^&]*&'), '$1');
        }
        this.open = open;
    }
    return new initializeModal();
});;define('utility',[],function(){
	
	/**
	 * @namespace utility
	 */
	var utility = {};
	
	/**
	 * Empty a HTML element
	 * @memberof utility
	 * @method emptyElement
	 * @param {element} element pass an element to be emptied
	 */
	utility.emptyElement = function emptyElement(element){
		var childNodes = element.childNodes;
		var length  = childNodes.length;
		 for(var i =0;i<length;i++)
			 element.removeChild(childNodes[0]);
	};
	
	/**
	 * Empty a HTML element expect its first child
	 * @memberof utility
	 * @method emptyElementFromFirstNode
	 * @param {element} element pass an element to be emptied
	 */
	utility.emptyElementFromFirstNode = function emptyElementFromFirstNode(element){
		var childNodes = element.childNodes;
		var length  = childNodes.length;
		 for(var i =0;i<length-1;i++)
			 element.removeChild(childNodes[1]);
	};
	
	/**
	 * call an callback after given number of times 
	 * @memberof utility
	 * @method after
	 * @param {number} count number of times function call back happened
	 * @param {function} callback function callback
	 */
	utility.after = function after(count, callback) {
	        var counter = count;
	        return function() {
	            counter--;
	            if (counter === 0) callback.apply(this, arguments);
	        };
	    };
	 
    /**
     * convert degree to radian
     * @memberof utility	
     * @method degToRadian
     * @param {number} angle 
     */
	 utility.degToRadian = function degToRadian(angle){
		   return (Math.PI/180)*angle;
	   };
	 
	 /**
	  * check if an object is empty
	  * @memberof utility
	  * @method isEmpty
	  * @param {object} obj 
	  * @retun {boolean}
	  */
	 utility.isEmpty = function isEmpty(obj){
			if (Object.getOwnPropertyNames(obj).length > 0) return false;
			else return true;
	 };
	 
	 /**
	  * compute the length of an object
	  * @memberof utility
	  * @param {obj} obj
	  * @return {number} size 
	  */
	 utility.size = function size(obj) {
		    var size = 0, key;
		    for (key in obj) {
		        if (obj.hasOwnProperty(key)) size++;
		    }
		    return size;
		};
		
	utility.isLocalStorage = function(){
	 var testKey = 'test', storage = window.sessionStorage;
	    try 
	    {
	        storage.setItem(testKey, '1');
	        storage.removeItem(testKey);
	        return true;
	    } 
	    catch (error) 
	    {
	        return false;
	    }
	};
	 /**
	  * count the number of words in string
	  * @memberof utility
	  * @method countWords
	  * @param {string} str
	  * @retun {number} noOfWords
	  */
	 utility.countWords = function countWords(str){
		 var noOfWords;
		 	if(str===""){
		 		noOfWords = 0;
		 	}else{
		 		noOfWords = str.trim().replace(/<(?:.|\n)*?>/gm, '').split(/\s/).length;
		 	}
		 		
		 return noOfWords
	 };
	 /**
	  * count the number of characters in string
	  * @memberof utility
	  * @method count characters
	  * @param {string} str
	  * @retun {number} noOfCharacters
	  */
	 utility.countCharacters = function countCharacters(str){
		 var noOfWords;
		 	if(str===""){
		 		noOfCharacters = 0;
		 	}else{
		 		noOfCharacters = str.trim().replace(/<(?:.|\n)*?>/gm, '').length;
		 	}
		 		
		 return noOfCharacters
	 };
	utility.getUrlParameters =  function(parameter) {
		  return decodeURIComponent((new RegExp('[?|&]' + parameter + '=' + '([^&;]+?)(&|#|;|$)').exec(location.search) || [, ""])[1].replace(/\+/g, '%20')) || null;
	};
	
		 /*
		 * DOMParser HTML extension
		 * 2012-09-04
		 *
		 * By Eli Grey, http://eligrey.com
		 * Public domain.
		 * NO WARRANTY EXPRESSED OR IMPLIED. USE AT YOUR OWN RISK.
		 */

		/*! @source https://gist.github.com/1129031 */
		/*global document, DOMParser*/

		(function(DOMParser) {
		    "use strict";

		    var
		      DOMParser_proto = DOMParser.prototype
		    , real_parseFromString = DOMParser_proto.parseFromString
		    ;

		    // Firefox/Opera/IE throw errors on unsupported types
		    try {
		        // WebKit returns null on unsupported types
		        if ((new DOMParser).parseFromString("", "text/html")) {
		            // text/html parsing is natively supported
		            return;
		        }
		    } catch (ex) {}

		    DOMParser_proto.parseFromString = function(markup, type) {
		        if (/^\s*text\/html\s*(?:;|$)/i.test(type)) {
		            var
		              doc = document.implementation.createHTMLDocument("")
		            ;

		            doc.body.innerHTML = markup;
		            return doc;
		        } else {
		            return real_parseFromString.apply(this, arguments);
		        }
		    };
		}(DOMParser));
		
	return utility;
});;define('AboutView',['CommonView'],function(CommonView){
    
    function AboutView(data){
    	
        this.questionNo = 0;
        this.data = data;
        this.isOpened = false;
        var infoNotAvailable = 'Information not available.' ;
        this.description = data.description || infoNotAvailable;
        this.difficultyLevel = data.difficultyLevel || "At Grade";
        this.grades = data.grades || infoNotAvailable;
        this.dateCreated = data.dateCreated || infoNotAvailable;
        this.subject = data.subject || infoNotAvailable;
        var conceptArray = [];
        for(var i=0 ; i < data.concepts.length ; i++){
        	conceptArray.push(data.concepts[i].name);
             } ;
        this.concepts = conceptArray.join(', ');
        
        var template = '<div class="background"></div><div class="about-data-container"><div class="about-container"><div class="header">About</div><div class="info-container"><div class="description about-view-text">'+this.description+'</div>'
         +'<div class="info-block"><div class="title">Difficulty Level:</div><div id="difficulty-level" class="about-view-text">'+this.difficultyLevel+'</div></div><div class="info-block"><div class="title">Grades:</div>'
         +'<div id ="grades" class="about-view-text">'+this.grades+'</div></div><div class="info-block"><div class="title">Date Created:</div><div id="date-created" class="about-view-text">'+this.dateCreated+'</div>'
         +'</div><div class="info-block"><div class="title">Categories:</div><div id="categories" class="about-view-text">'+this.subject+'</div>'+/*author*/'<div class="info-block"><div class="title">Author:</div><div id="author" class="about-view-text">Dr. Byron Philhour</div>'+'</div>'
         +'</div><div class="aboutClose"></div></div>'
         +'</div>'
         +'<div class="author-bio-container go-right"><div class="header">Dr. Byron Philhour</div><div class="info-container single-column">'
         +'<div class="description about-view-text">Dr. Byron Philhour has been involved in physics education for nearly twenty years. He earned his Bachelor\'s Degree in Physics from U.C. Berkeley in 1995 and his Ph.D. in Physics from Caltech in 2002. His work in numerical simulation in physics began in 1993 when he began simulating radioactive background noise in astrophysical gamma-ray detectors. He has taught astronomy, physics, engineering, chemistry, and computer science and the college and high school level for fifteen years. He is currently teaching Honors and AP Physics at San Francisco University High School. His current interests in physics education revolve around modeling instruction, standards-based grading, and student development of numerical simulations. He began working with cK-12 in February, 2014, helping to create this new set of interactive simulations.</div>'
         +'<div class="aboutClose"></div>'
         +'<div class="backArrow"></div></div></div>';
        
        CommonView.apply(this , [{
            template:template,
            name :'aboutView',
            el: 'div',
            classes:['about-screen'],
			initialize: this.init
        }]);
        
        this.events = {
        		'click #author':'openBio',
        		'click .aboutClose':'closeAbout',
        		'click .backArrow':'closeBio',
        		'click .background':'closeAbout'
        };
        
        this.stopPropagation = function(e){
            e.stopPropagation();
        };
        
        this.closeAbout = function(e){
         e.stopPropagation();
         this.eventHandler.emit('hideAbout');
        }.bind(this);
        
        this.openBio = function(e){
        	e.stopPropagation();
        	this.aboutContainer.classList.add('go-left');
        	this.bioContainer.classList.remove('go-right');
        }.bind(this);
        
        this.closeBio = function(e){
        	e.stopPropagation();
        	this.aboutContainer.classList.remove('go-left');
        	this.bioContainer.classList.add('go-right');
        }.bind(this);
        
    }
    
    AboutView.prototype = Object.create(CommonView.prototype);
    AboutView.prototype.constructor = AboutView;
    
    AboutView.prototype.init = function init(){
    	this.aboutContainer = this.el.querySelector('.about-container');
    	this.bioContainer = this.el.querySelector('.author-bio-container');
    	this.bioContainer.classList.add('go-right');
    }
    AboutView.prototype.resetAboutView = function resetAboutView(){
    	this.aboutContainer.classList.remove('go-left');
    	this.bioContainer.classList.add('go-right');
    }
    return AboutView;
    
});;define('AddNewExampleView',['CommonView','ajax','HostURLs'],function(CommonView,ajax,HostURLs){
    
    function AddNewExampleView(data,userData){
    	
        this.questionNo = 0;
        this.isOpened = false;
        var eids = [];
        
        for(var i=0,l=data.concepts.length; i<l; i+=1){
        	eids.push(data.concepts[i].encodedID);
        }
        
        this.createRWEParams = {
        		"simID" : data.artifactID,
        		"ownerID" : userData&&userData.id ? userData.id : "",
        		"eids" : eids
        }
        
        var infoNotAvailable = 'Information not available.' ;
        
    	var template = '<div class="add-new-example-container" id="reportContainer"><div class="header">Add your own examples</div><div class="info-container">'
    		 +'<textarea id="addTitle" rows="1" cols="50" type="text" maxlength="50" class="comment-box" placeholder="Title"></textarea>'
    		 +'<textarea id="addDescription" rows="4" cols="50" type="text" maxlength="300" class="comment-box" placeholder="Description"></textarea></div>'
    		 +'<div id="uploadError" class="hide">File format not supported, use jpg or png</div>'
    		 +'<div class="upload-img-list hide" id="imageList">'
	       	 +'<div class="upload-img">'
	         +'<span class="img-name" id="imageUploaded">Image 01</span>'
	         +'<span class="delete-icon"></span>'
	       	 +'</div>'
	       	 +'</div>'
    		 +'<div class="upload-images"><input class="input-image" id="inputImage" type="file">'
   		  	 +'<span class="upload-icon"></span>'
   		  	 +'<span class="upload-text">Upload Image</span>'
   		  	 +'</div>'
    		 +'<input type="file" name="pic" class="hide" accept="image/*">'
    		 +'<div class="button-container "><div id="createRWE" class="send-button report-button">SUBMIT</div>'
    		 +'<div id="cancelReport" class="cancel-button report-button">CANCEL</div></div>'
    		 +'<div class="add-new-example-close"></div>'
    		 +/*'<div class="terms-conditions hide"><div class="header">Term and Conditions</div></div></div>'*/ '</div>';
        		 
        
        CommonView.apply(this , [{
            template:template,
            name :'AddNewExampleView',
            el: 'div',
            classes:['addNewExample-screen'],
            initialize: this.init
        }]);
        
        
        
        this.events = {
          'click .add-new-example-close':'closeaddNewExample',
          'click #createRWE':'send',
          'click #cancelReport':'closeaddNewExample',
          'blur #addNewExampleText': 'scrollUp',
          'focus #addNewExampleText':'scrollUp',
          'click el':'closeOnClick',
          'click #reportContainer':'stopPropagation',
          'change #inputImage':'imageUploader',
          'click .delete-icon':'deleteImage',
          'keyup #addTitle':'checkForComment',
          'keyup #addDescription':'checkForComment'
        };
        
        this.closeOnClick = function closeOnClick(e){
/*        	 e.stopPropagation();
        	 this.eventHandler.emit('hideAddNewExample');*/
        }.bind(this);

        this.stopPropagation = function stopPropagation(e){
        	e.stopPropagation();
        }	;
        this.checkForComment = function(e){
        	var title = this.el.querySelector('#addTitle'),
        		description = this.el.querySelector('#addDescription'),
        		file = document.querySelector('input[type=file]').files[0];
        	var sendButton = document.getElementById('createRWE');
        	title = title.value.replace(/^\s+|\s+$/g,'');
        	description = description.value.replace(/^\s+|\s+$/g,'');
        	if((title == "")||(description == "")||(!file)){
        		sendButton.classList.remove('Active');
        	}else{
        		sendButton.classList.add('Active');
        	}
        }.bind(this);
        
        this.closeaddNewExample = function(e){
	        if(e)
	         e.stopPropagation();
	         this.imageUploaded.innerHTML = "";
	         this.imageList.classList.add('hide');
	         this.uploadError.classList.add('hide');
	         document.querySelector("#addTitle").value = "";
	         document.querySelector("#addDescription").value = "";
	         var sendButton = document.getElementById('createRWE');
	         sendButton.classList.remove('Active');
	         document.querySelector("#inProgressScreen2").classList.add('hide');
	         this.deleteImage();
	         this.eventHandler.emit('hideAddNewExample');
        }.bind(this);
        
        this.send = function(e){
        	var sendButton = document.getElementById('createRWE');
        	if(sendButton.classList.contains('Active')){
        		document.querySelector("#inProgressScreen2").classList.remove('hide');
        		this.createRWE();
        		//this.closeaddNewExample();
        	}else{
        		return false;
        	}
        }.bind(this);
        
        this.deleteImage = function deleteImage(){
        	this.imageList.classList.add('hide');
        	document.querySelector('#inputImage').value = "";
        	this.checkForComment();
        }.bind(this);
        /*
        this.scrollUp = function scrollUp(e){
        	 if(navigator.userAgent.match(/(iPad|iPhone|iPodN | Nexus One|Nexus S|Galaxy.*Nexu|Nexus 7)/g) ? true : false){
        		 window.scrollTo(0,0);
        	 }
        }.bind(this);
        */
        
        this.imageUploader = function imageUploader(){
        	  var file = this.el.querySelector('input[type=file]').files[0],
        	  	  img = new Image(),
        	  	  reader = new FileReader();
        	  reader.readAsDataURL(file);
        	  
        	  this.uploadError.classList.add('hide');
        	  this.checkForComment();
        	  if(file){
 		    	 var  fileType = file.name.substring(file.name.lastIndexOf('.') + 1);
   		    	 if((fileType == "jpg")||(fileType == "png")||(fileType == "JPG")||(fileType == "PNG")||(fileType == "jpeg")||(fileType == "JPEG")){
   		    		this.imageUploaded.innerHTML = file.name;
   		    		this.imageList.classList.remove('hide');
   		    		var that = this;
   		    		reader.onload = function(_file){
   		    			img.src = _file.target.result;
   		    			img.onload = function(){
   		    				if((this.width<1024)||(this.height<768)){
   		    					that.deleteImage();
   		    					that.uploadError.innerHTML = "Please upload images with minimum resolution of 1024x768";
   		    					that.uploadError.classList.remove('hide');
   		    				}
   		    			}
   		    		}
   		    	}else{
   		    		this.deleteImage();
   		    		this.uploadError.innerHTML = "File format not supported, use jpg or png";
   		    		this.uploadError.classList.remove('hide');
   		    	}
        	  }
        }.bind(this);
        
        
        this.uploadImage = function(callback){
        	  var file    = document.querySelector('input[type=file]').files[0],
        	      reader  = new FileReader(),
        	      timeStamp = new Date().getTime(),
        	      formData ;
        	  var  that = this;
        	  
			    if (window.FormData !== undefined && file !== undefined) {
			     
			        formData = new FormData();
			        var postConfig = {
			        	resourceType: "image",
			            resourceName: file.name,
			            resourceDesc: "",
			            isAttachment: false,
			            isPublic: false
			        };
			        
			        formData.append("resourcePath", file, timeStamp + "_" + file.name);
			        for (var i in postConfig) {
			            if (postConfig.hasOwnProperty(i)) {
			                formData.append(i, postConfig[i]);
			            }
			        }
			        formData.contentType = false;
			        formData.processData = false;
			    }
			    
				ajax.sendFormData(URL.FLX_HOST_URL+"create/resource",{
					withCredentials : true,
					message : formData,
					callback : function(response){
						if(response.satelliteUrl){
							callback.call(that,response.satelliteUrl);
						}else{
							callback.call(that,undefined);
						}
					}
				});
				
				
        }.bind(this);
   
    }
    
    AddNewExampleView.prototype = Object.create(CommonView.prototype);
    AddNewExampleView.prototype.constructor = AddNewExampleView;
    
    AddNewExampleView.prototype.init = function init(){
        this.container  = this.el.querySelector('#reportContainer');
        this.imageList  = this.el.querySelector('#imageList');
        this.uploadError = this.el.querySelector('#uploadError');
        this.imageUploaded = this.el.querySelector('#imageUploaded');
    };
    
    AddNewExampleView.prototype.createRWE = function createRWE(){
    	
    	var title = this.el.querySelector("#addTitle").value;
    		content = this.el.querySelector("#addDescription").value;
    	var createRWEParams = {
    			"title": title,
    			"content": content,
    			"level": "at grade"
    	};
    	
    	function _createRWE(data){
    		var that = this;
    		if(data !== undefined){
    			createRWEParams["imageUrl"] = data;
    		}
        	for(var i in this.createRWEParams){
        		createRWEParams[i] = this.createRWEParams[i];
        	}
        	
        	var formData = new FormData();
        	
        	for(var i in createRWEParams){
        		 formData.append(i, createRWEParams[i]);
        	}
    		
    		ajax.sendFormData(URL.FLX_HOST_URL+"create/rwe",{
    			withCredentials : true,
    			message : formData,
    			callback : function(response){
        			that.closeaddNewExample();
        			that.eventHandler.emit('refreshCardsView',{response : response});
        			//that.eventHandler.emit('showMessage',{'message' : that.messages[that.reasonId]});
        		}
    		});
    	}
    	if(this.el.querySelector('input[type=file]').files[0]){
    		this.uploadImage(_createRWE);
    	}
    	else{
    		_createRWE.call(this,undefined);
    	}
	};
    
    
    return AddNewExampleView;
    
});;define('ChallengeView',['CommonView'],function(CommonView){
	
	function ChallengeView(data){
		
		if(!data){
			console.error('challenge data is missing');
		}
		
		this.questionNo = 0;
		this.data = data;
		this.isOpened = false;
		var template = '<div class="button-challenge-next collapse"></div><div class="button-challenge-prev collapse inactive"></div><div class="question">'+this.data[this.questionNo]+'</div>' ;
		
		CommonView.apply(this , [{
			template:template,
			name :'challengeView',
			el: 'div',
			classes:['challenge-screen','smallFont','animated','bounceOutUp','hide']
		}]);
		
        this.challengePrev = this.el.querySelector('.button-challenge-prev');
        this.challengeNext = this.el.querySelector('.button-challenge-next');
        this.questionC     = this.el.querySelector('.question');
		
		
		this.events = {
				'click el' : 'stopPropagation',
				'click .button-challenge-prev':'prevChallenge',
				'click .button-challenge-next': 'nextChallenge'
		};
		
		this.stopPropagation = function(e){
			e.stopPropagation();
		};
		
		this.closeChallenge = function closeChallenge(event){
			if(!this.isOpened)
				return;
			if(event.currentTarget == this.el){
				return;
			}
			this.closeChallenges(event);
		};
		
		this.prevChallenge = function(e){
			e.stopPropagation();
	        this.questionNo--;

	        if(this.questionNo<=0) {
	              this.questionNo=0;
	              this.challengeNext.classList.remove('inactive');
	              this.challengePrev.classList.add('inactive');
	        }else{
	     	   this.challengePrev.classList.remove('inactive');
	     	   this.challengeNext.classList.remove('inactive');
	        }
	        this.questionC.textContent = this.data[this.questionNo];
		}.bind(this);
		
		this.nextChallenge = function(e){
			e.stopPropagation();
	        this.questionNo++;

	        if(this.questionNo>=this.data.length-1){
	             this.questionNo = this.data.length-1 ;
	             this.challengePrev.classList.remove('inactive');
	             this.challengeNext.classList.add('inactive');
	        }else{
	    	   this.challengePrev.classList.remove('inactive');
	    	   this.challengeNext.classList.remove('inactive');
	        }
	        this.questionC.textContent = this.data[this.questionNo];
		}.bind(this);
		
	}
	
	ChallengeView.prototype = Object.create(CommonView.prototype);
	ChallengeView.prototype.constructor = ChallengeView;
	
	ChallengeView.prototype.openChallenges = function(event){
			if(this.isOpened){
				this.closeChallenges(event);
				return;
			}
			this.eventHandler.emit('hideMore');
		    this.questionNo = 0;
	        this.questionC.textContent = this.data[this.questionNo];
	        this.challengeNext.classList.remove('inactive');
	        this.challengePrev.classList.add('inactive');
        	this.isOpened = true;
        	this.el.classList.remove('hide');
        	this.el.classList.remove('bounceOutUp');
        	this.el.classList.add('animated');
        	this.el.classList.add('bounceInDown');

	};
	

	
	ChallengeView.prototype.closeChallenges = function(e){
		if(e.target == document.querySelector('.challenge'))
			return;
    	this.el.classList.remove('hide');
    	this.el.classList.remove('bounceInDown');
    	this.el.classList.add('animated');
    	this.el.classList.add('bounceOutUp');
    	this.isOpened = false;
    	setTimeout(_hideChallenge.bind(this),600);
	};
	
	function _hideChallenge(){
		this.el.classList.add('hide');
		this.el.classList.remove('bounceInDown');
		this.el.classList.add('animated');
		this.el.classList.add('bounceOutUp');
	}
	
	return ChallengeView;
	
});;define('CommonView', [''], function() {


    /**
     * creates instance of CommonView
     * @constructor CommonView
     * @param {object} options
     */
    function CommonView(options) {
        this.options = options || null;
        this.events = {};
        this.initialize = options.initialize || function() {};

        _set.call(this);

        /**
         * render the CommonView
         * @memberof CommonView
         * @method render
         * @param {string} template html template
         */
        this.render = function(container) {
            _bindEvents.call(this);
            container.appendChild(this.el);
        };

    }
    
    /**
     * Bind events to the selected elements according to the events objects,its a private method
     * @method bindEvents
     * @memberof CommonView
     */
     function _bindEvents() {
        for (var x in this.events) {
            var self = this;
            var targetInfo = x.split(/\s/g);
            var event = targetInfo[0];
            var target = targetInfo[1];
            if (target === 'el') {
                this.el.addEventListener(event, self[self.events[x]]);
            }
            var elements = [].slice.call(this.el.querySelectorAll(target));
            elements.forEach(function(element) {
                element.addEventListener(event, self[self.events[x]]);
            });
        }
    }
     
     /**
      * setup the CommonView, HTML's, its a private method
      * @memberof CommonView
      * @method set
      */
      function _set() {
         this.el = document.createElement(this.options.el || 'div');
         if (this.options.name)
             this.el.id = this.options.name;
         if (this.options.className)
             this.el.className = this.options.className;

         for (var x in this.options.classes)
             this.el.classList.add(this.options.classes[x]);

         // var fragment = document.createDocumentFragment();
         this.el.innerHTML = this.options.template;
     }

    return CommonView;
});;define('ConceptView',['CommonView','utility'],function(CommonView,utility){
    
    function ConceptView(data){
    	
        this.questionNo = 0;
        this.data = data;
        this.iframeFlag = false;
        this.isOpened = false;
        var conceptAnchor = 0;
        var infoNotAvailable = 'Information not available.' ;
        this.description = data.description || infoNotAvailable;
        this.difficultyLevel = data.difficultyLevel || "At Grade";
        this.grades = data.grades || infoNotAvailable;
        this.dateCreated = data.dateCreated || infoNotAvailable;
        this.subject = data.subject || infoNotAvailable;
        this.target = "";
        var conceptArray = [];
        for(var i=0 ; i < data.concepts.length ; i++){
        	var conceptId = data.concepts[i].handle.replace(/ /g , "-");
        	conceptAnchor = '<a class="conceptName" id="'+conceptId+'">'+data.concepts[i].name+'</a>';
        	conceptArray.push(conceptAnchor);
             } ;
        this.concepts = conceptArray.join(', ');
        
        var template = '<div class="background"></div><div class="concept-container withoutIframe"><div class="header">Concepts</div><div class="info-container">'
        	+'<div id="concepts" class="concept-view-text">'+this.concepts+'</div></div><div class="modal-window hide"><div class="iframe-container">'
        	+'<div id="iFrameCont" class="i-frame-cont"><iframe id="conceptIframe" class="i-frame" src="" scrolling="yes" frameborder="0"></iframe></div></div></div>'
        	+'<div class="conceptClose"></div></div>';
        
        CommonView.apply(this , [{
            template:template,
            name :'ConceptView',
            el: 'div',
            classes:['concept-screen']
        }]);
        
        this.events = {
          'click .conceptClose':'closeConcept',
           'click .conceptName':'openConceptIframe'
        };
        /*'click .background':'closeConcept',*/
        
        this.stopPropagation = function(e){
            e.stopPropagation();
        };
        
        this.closeConcept = function(e){
         e.stopPropagation();
         this.el.querySelector('.concept-container').classList.add('withoutIframe');
         this.closeIframe();
         this.el.querySelector('.i-frame').setAttribute("src","");
         this.eventHandler.emit('hideConcept');
        }.bind(this);
        
        this.openSab = function(){
        	//..............fix for APP.............
        	this.locAPP = utility.getUrlParameters("loc");
        	if(this.locAPP =="app"){
        		var refUrl = "http://www.ck12.org/embed/#module=concept&handle="+this.target.id+"&filters=text,multimedia&branch=Physics&view_mode=embed&utm_source=simulations&utm_medium=web&utm_campaign=Embed&referrer=simulation_about";
        		window.open(refUrl, '_blank', 'location=no,zoom=no,enableViewportScale=no');
        	}else{
        	if(!this.iframeFlag){
        		this.iframeFlag = true;
        		this.el.querySelector('.concept-container').classList.remove('withoutIframe');
	        	this.el.querySelector('.modal-window').style.height = "80%";
	        	this.el.querySelector('.modal-window').classList.remove('hide');
	    		this.el.querySelector('.iframe-container').style.top = "0%";
        	}
        	this.el.querySelector('.i-frame').setAttribute("src","");
            
            
            
        	var allConcepts = document.getElementsByClassName('conceptName');
        	for(var i=0 ; i < allConcepts.length ; i++){
        		allConcepts[i].classList.remove('active');
        		};
    		this.el.querySelector('#iFrameCont').innerHTML = "";
    		this.el.querySelector('#iFrameCont').innerHTML = '<iframe id="conceptIframe" class="i-frame" src="" frameborder="0" scrolling="yes"></iframe>';
        	var iFrame = this.el.querySelector('.i-frame'); 
        	var refUrl = "http://www.ck12.org/embed/#module=concept&handle="+this.target.id+"&filters=text,multimedia&branch=Physics&view_mode=embed&utm_source=simulations&utm_medium=web&utm_campaign=Embed&referrer=simulation_about";
        	
    		iFrame.setAttribute("src",refUrl);
    		iFrame.src = iFrame.src; 
    		this.target.classList.add('active');
    		var myIFrame = document.getElementById('conceptIframe');
		    var content = myIFrame.contentWindow.document.body;
		    content.style.overflowY = 'auto';	
        	}
		}.bind(this);
	       this.openConceptIframe = function openConceptIframe(e){
	        	this.target = e.currentTarget
	        	this.eventHandler.emit('openConceptIframe');
	       
	    		
			}.bind(this);

		this.closeIframe = function closeIframe(e){
			this.iframeFlag = false;
			this.el.querySelector('.concept-container').classList.add('withoutIframe');
			this.el.querySelector('.modal-window').classList.add('hide');
			this.el.querySelector('.i-frame').setAttribute("src","");
    		var allConcepts = document.getElementsByClassName('conceptName');
        	for(var i=0 ; i < allConcepts.length ; i++){
        		allConcepts[i].classList.remove('active');
        		};
    	}
        
    }
    
    ConceptView.prototype = Object.create(CommonView.prototype);
    ConceptView.prototype.constructor = ConceptView;
    
    return ConceptView;
    
});;define('CreateQuizView',['CommonView','Carousel','utility','ajax','AbacusSlider','HostURLs'],function(CommonView,Carousel,utility,ajax,AbacusSlider,HostURLs){
	
	function createQuiz(data, scene) {
	
		var questionContent = "Question" ,
		answerContent = "Answer" ,
	    slidersStr ="";
		/*this.currentData = this.data.quiz;*/
		this.data = data ;
        this.scene = scene;
        this.titleDone = false;
        this.descriptionDone = false ;
        this.allDone = false;
        this.next = false;
        this.carouselRendered = false;
        this.editorCreated = false;
        this.answerAdded = false;
        this.answerSliders = [];
        this.currentUserIsAdmin = (function(){
				for(var i in this.data.userData.roles){
					if(this.data.userData.roles[i].name=="admin" || this.data.userData.roles[i].name=="content-admin"|| this.data.userData.roles[i].name=="support-admin" /*|| this.data.userData.roles[i].name=="member"*/)
						return true;
				}
		}).call(this) || false;
        var eids = [];      
        for(var i=0,l=data.packageData.concepts.length; i<l; i+=1){
        	eids.push(data.packageData.concepts[i].encodedID);
        }
        this.createQuestionParams = {
       			questionTypeName:"sim-interactive",
    			submit:true,
    			encodedIDs:eids,
    			questionData:"",
    			generative:false,
    			level:"medium",
    			languageCode:"en",
    			simIDs:[data.packageData.artifactID],
    			instances:10
        }
        
        var noOfWordsInTitle = 0 ,noOfWordsInDescription = 0,noOfCharactersInTitle = 0;
        /**Adding background**/
        
        var background = document.createElement('div');
            background.classList.add('background-rwe');
            background.classList.add('background-quiz');
            background.style.backgroundImage="url('"+data.background+"')";
        var saveSliderValue = "";     
        var message ={
				"0":'<div class="wrong-answer"></div><div class="info-text">Answer is incorrect. Try Again!</div>',
				"1":'<div class="right-answer"></div><div info-text>You got it right!</div>'
		};
            
            /***Adding Slider name and values*/
        this.abacusSlider = new AbacusSlider({sliders:this.scene.additionalScene.sliders,removeCallback:true,addValue:["ANY"]});
  
        /**header for quiz mode question and answer **/    
        var quizModeHeader = '<div id="contentHeader" class="content-header"><div class="level-filter hide">All Levels</div><div class="quiz-content-menus-list" id="contentMenusList"><div class="quiz-content-menu   " id="questionCK12" >'
            +questionContent+'</div><div class="quiz-content-menu " id="answerCK12" >'
            +answerContent+'</div></div></div></div>' 
            +'<div class="msg-overlay hide">'+
				'<div class="msg-box">'+
		 			'<div class="msg-Close"></div>'+
		 			'<div class="msg-infoContainer">Are you sure you want to remove this example permanently?</div>'+
		 			'<div class="button-container ">'+
			 			'<div  class="rwe-delete submit-button report-button">REMOVE</div>'+
			 			'<div  class="rwe-delete-cancel cancel-button report-button">CANCEL</div>'+
		 			'</div>'+
		 		'</div>'+
	 		'</div>';    
        var questionContainer =  '<div class = "dummy-editor">'
        								+'<div class="editor-top addQuestion-editor">Type question here</div>'
        								+'<div class="editor-top addQuestionDescription-editor">Type description here</div>'	
        						+'</div>'
        						+'<div class = "quiz-question-editor">'
        						 +'<textarea id="addQuestion" rows="2" cols="50" type="text" maxlength="100" class="edit-text-box editQuestion hide" placeholder="Type question here"></textarea>'
		 						 +'<textarea id="addQuestionDescription" rows="4" cols="50" type="text" maxlength="300" class="edit-text-box editDescription hide" placeholder="Type description here"></textarea>'
		 						 +'<div class="question-button-container"><div class = "create-quiz-buttons next">Next</div><div class = "create-quiz-buttons cancel">Cancel</div></div></div>';
	    var answerContainer ='<div class="answer-editor-box ">'
		        						+'<div class = "quiz-answer-editor">'
			        						/*+'<div class = "answer-number">'
				        						+'<div class="answer-number-text">Answer'
				        						+'<div class="answer-number-count">1</div>'
			        						+'</div>'
		        						+'</div>'*/
		        						+'<div class = "slider-value-container">'
		        							/*+totalSlider*/
		        						+'</div>'
		        						+'<div class="save-button-container"><div class = "create-quiz-buttons save">Save</div><div id ="previous" class = "create-quiz-buttons">Back</div></div>'
		        						+'<div class="answer-container">'
		        						
		        						+'</div>'
		        						+'<div class="save-button-container"><div id ="done" class = "create-quiz-buttons done-button hide">Done</div></div>'
		        					+'</div>'
		        					
        						+'</div>';
	    this.answerContainerTemplate ='<div class = "quiz-answer">'
												+'<div class = "answer-number">'
													+'<div class="answer-number-text">Answer'
													
												+'</div>'
											+'</div>'
											+'<div class = "slider-value-container">'
												/*+totalSlider*/
											+'</div>'										
										+'</div>';
										
	    this.editAnswerTemplate = '<div class="answer-controles"><div class="quiz example-edit"></div><div class="quiz example-delete"></div></div>';
        /**header for quiz mode question and answer **/
        
        
       
        var sliderObjects = '<div class="quiz-editor"><div class="quiz-editor-child ">'+ questionContainer + answerContainer + '</div></div>';
        
        
        var template = '<div  class="header-tools animated">'+
							'<div id = "closeCurrentView" class="edit-tool-left backFromPreview"></div>'
        					+'<div  class="edit-tool-left create-new-quiz">Create New Question</div>'
        					+'</div>';
        	template = background.outerHTML + template + quizModeHeader + sliderObjects;
      
        CommonView.apply(this , [{
			template:template,
			name :'createQuizView',
			el: 'div',
			initialize: this.init
		}]);
        
  
        this.events = {
         'click #closeCurrentView':'closeCurrentView',
         'click #questionCK12' : 'question_editor',
         'click #answerCK12' : 'answer_editor',
         'click .cancel':'closeCurrentView',
         'keyup #addQuestion':'checkForComment',
         'keyup #addQuestionDescription':'checkForComment',
         'mousedown .editor-top':'showEditor',
         'touchstart .editor-top':'showEditor',
         'click .next':'goToAnswer',
         'click .save':'checkSaveAnswer',
         'click #previous':'question_editor',
         'click #done':'answerSaved'
        };
        this.checkSaveAnswer = function(e){
        	e.stopPropagation();
        	var allAreANY = false;
        	for(var i in this.abacusSlider.abacusSliders){
        		var value = this.abacusSlider.abacusSliders[i].data[""] || this.abacusSlider.abacusSliders[i].data[this.abacusSlider.abacusSliders[i].options.UIValue] || this.abacusSlider.abacusSliders[i].options.UIValue;
        			if(value=="ANY"){
        				allAreANY = true;
        			}else{
        				allAreANY = false;
        				break;
        			}
        	}
        	if(allAreANY){
        		this.eventHandler.emit('showMessage',{ message : "All slider's value can't be set as 'ANY'."}); 
        	}else{
        		this.saveAnswer();
        		
        	}
        	
        }.bind(this);
       this.closeCurrentView = function(e){
    	   e.stopPropagation();
    	   var buttonType = e.target.innerHTML;
    	   tinymce.editors.addQuestion.remove();
    	   tinymce.editors.addQuestionDescription.remove();
    
    	   this.initializeSetting();
    	   this.editorCreated = false;

    	   this.scene.hideView('createQuizView');
           this.scene.showView('quizMainScreen');
           
           //refresh Quiz View
           if(this.questionUpdated){      	   
        	   this.scene.quizView.messageType = "updated";
        	   this.scene.quizView.refreshView();
        	   this.questionUpdated = false;
           }else if(this.questionCreated){
        	   if(this.currentUserIsAdmin){
        		 	this.scene.quizView.messageType = "";
        	   		this.scene.quizView.currentContent = "ck12";
        	   }else{
        		   this.scene.quizView.messageType = "created";
        	   	   this.scene.quizView.currentContent = "community"; 
        	   }
     	  
        	   this.scene.quizView.refreshView();
        	   this.questionCreated = false;
           }
           if(buttonType=="Cancel"){}
          /* dexterjs.logEvent("FBS_SIMULATION_QCREATE_Q", {
       		"button" : buttonType
           });*/
        	
        }.bind(this);
        this.showEditor = function(e){
        	e.currentTarget.classList.add('hide');
        	/*tinymce.activeEditor.contentDocument.activeElement.focus();*/
        }.bind(this);
        this.AddEditorOnQuestion = function(){
        	//this.AddTinyMCE('editQuestion');
        } 
        this.AddEditorOnDescription = function(){
        	//this.AddTinyMCE('editQuestion');
        }
       this.showSliderValues = function(){
    	   this.renderSliderValues(this.sliderParent);
       }.bind(this);
       this.question_editor = function question_editor(event){
       	this.activateContent(this.questionCK12);   
       	this.slidingBox.classList.remove("quiz-sliding-transition");
       	if(event && event.target.innerHTML == "Back"){/*
       		dexterjs.logEvent("FBS_SIMULATION_QCREATE_A", {
        		"button" : "Back"
            });	
       	*/}else if(event && event.target.innerHTML == "Question"){/*
       		dexterjs.logEvent("FBS_SIMULATION_QEDITOR_TOGGLE", {
        		"tab" : "question"
            });
       	*/}
       	
     
       }.bind(this);
       
       this.answer_editor = function answer_editor(e){
    	   if(this.allDone && this.next){
    		   this.activateContent(this.answerCK12) ;
    	       this.slidingBox.classList.add("quiz-sliding-transition");	   
    	   }/*
    		dexterjs.logEvent("FBS_SIMULATION_QEDITOR_TOGGLE", {
        		"tab" : "answer"
            });*/
       }.bind(this);
       this.goToAnswer = function goToAnswer(e){
    	   e.stopPropagation();
    	  /* var buttonType = e.target.innerHTML;*/
    	   if(this.allDone){
    		   this.activateContent(this.answerCK12) ;
    	       this.slidingBox.classList.add("quiz-sliding-transition");
    	       this.next = true;/*
    	   		dexterjs.logEvent("FBS_SIMULATION_QCREATE_Q", {
        		"button" : "Next"
            });*/
    	   }else{
    		  /* if(noOfCharactersInTitle>=this.titleMinCharacters){
    			   this.eventHandler.emit('showMessage',{ message : "Question is incomplete."}); 
    		   }else{*/
    			   this.eventHandler.emit('showMessage',{ message : "Question should have minimum 20 characters."}); 
    		  /* }*/
    		   
    		  
    	   }
    	   
    	
       }.bind(this);
       this.saveAnswer = function(){
    	   if(!this.answerAdded){
    		   this.addNewAnswer();
    		   this.doneButton.classList.remove("hide");
    		   this.answerAdded = true;
    		   if(!this.editQuestionMode){/*
        		   dexterjs.logEvent("FBS_SIMULATION_QCREATE_A", {
               		"button" : "Save"
                   });   
        	   */}
    	   }else{
    			 this.updateAnswer(this.answer);
    			 /*
    			   dexterjs.logEvent("FBS_SIMULATION_QCREATE_A", {
    	           		"button" : "Save"
    	               }); */
    			 
    	   }
    	
    		
        	
        }.bind(this);
        this.answerSaved = function(e){
        	startSendAnim("sending");
        	this.questionObject = {};
        	//owner ID
        	if(!this.editQuestionMode){
        		this.questionObject["ownerID"] = this.currentUserIsAdmin ? "ck12":data.userData.id;  //default userId is added ...(remove if its not required)
        	}else{
        		this.questionObject["ownerID"] = this.currentQuestionData.questionData.ownerID ||data.userData.id;  //default userId is added ...(remove if its not required)
        	}
        
        	//adding Question Text 
        	this.questionObject['questionText'] =  tinymce.editors.addQuestion.getContent();
        	//adding Question Description 
        	this.questionObject['questionDescription'] = tinymce.editors.addQuestionDescription.getContent() ||" ";
        	//addind Answer
        	this.questionObject['answer'] = [];
        	this.questionObject['answer'].push(this.answerObject);
   
        	
        	/****
        	 * //call API for create Question 
        	 *  send object submitAnswer
        	 * 
        	 * ****/
        	var event = e;
        	var createQuestionParams = {};
        	for(var i in this.createQuestionParams){
        		createQuestionParams[i] = this.createQuestionParams[i];
        	}
        	//adding Question data
        	createQuestionParams["questionData"] = JSON.stringify(this.questionObject);
        	var apiLink = ""; 
        	if(this.editQuestionMode){
        		apiLink = URL.UPDATE_ASSESSMENT_QUES_HOST_URL+this.currentQuestionData._id;       	 	
				this.questionUpdated = true;
        	}else{
        		apiLink = URL.CREATE_ASSESSMENT_QUES_HOST_URL;
        		  this.questionCreated = true;
        	}
        	var formData = new FormData();
        	for(var i in createQuestionParams){
       		 formData.append(i, createQuestionParams[i]);
        	}
    		ajax.sendFormData(apiLink,{
    			withCredentials : true,
    			message : formData,
    			callback : function(response){
   		      
    				startSendAnim("sent");
    	        	this.closeCurrentView(event);
        		}.bind(this)
    		});
 
        }.bind(this);
       this.initializeSetting = function(e){
    	   this.titleDone = false;
           this.descriptionDone = true ;
           this.allDone = false;
           this.next = false;
    	   this.title.value = "";
    	   this.description.value = "";
    	   this.question_editor(); 
    	   this.updateSliderValues(this.abacusSlider,[1,1,1,1,1,1,1,1]);
    	   
    	   this.answerBox.innerHTML = "";
    	   this.doneButton.classList.add("hide");
    	   this.carouselRendered = false;
    	   this.answerAdded = false;
    	   this.answerSliders = [];
    	  // this.nextButton.classList.add("hide");
    	   this.editQuestionMode = false;
    	   this.AddTinyMCE();
    	   this.editorTopQuestion.classList.remove('hide');
    	   this.editorTopDescription.classList.remove('hide');
    	   
       }.bind(this);
       
       this.checkForComment = function(e){

    	 //Checking for minimum words require in Title and Description
    	   if(tinyMCE.activeEditor.editorId=="addQuestion"){
    		    noOfWordsInTitle = utility.countWords(this.questionEditorCreator.descEditor.getContent());	
    		    noOfCharactersInTitle = utility.countCharacters(this.questionEditorCreator.descEditor.getContent());	
    		    this.titleDone = /*(noOfWordsInTitle>=this.titleMinLength?true:false) && */(noOfCharactersInTitle>=this.titleMinCharacters?true:false);
    	   }
    	   if(tinyMCE.activeEditor.editorId == "addQuestionDescription"){
    		/*   noOfWordsInDescription = utility.countWords(this.descriptionEditorCreator.descEditor.getContent());
    		   	this.descriptionDone = noOfWordsInDescription>=this.descriptionMinLength?true:false;*/
    	   }
 
       	//setting current Warning message
       	this.checkForDone();
       }.bind(this);
       this.checkForDone = function (e){
    	   if(this.titleDone && this.descriptionDone){
    		   this.allDone = true;
    		   //this.nextButton.classList.remove("hide");
    	   }else{
    		   this.allDone = false;
    		   //this.nextButton.classList.add("hide");
    	   }
    	   
       }.bind(this);
    }

	
	createQuiz.prototype = Object.create(CommonView.prototype);
	createQuiz.prototype.constructor = createQuiz;

   
    
	createQuiz.prototype.init = function init(){
		this.questionCK12 = this.el.querySelector('#questionCK12');
		this.answerCK12 = this.el.querySelector('#answerCK12');
		this.questionCK12.classList.add('active');
		this.sliderScreen = this.el.querySelector(".sliderName");
		this.questionEditor = this.el.querySelector('.quiz-question-editor');
		this.answerEditor = this.el.querySelector('.answer-editor-box');
		this.sliderParent  = this.el.querySelector('.slider-value-container');
		this.slidingBox = this.el.querySelector('.quiz-editor-child');
		this.title = this.el.querySelector('#addQuestion');
		this.description = this.el.querySelector('#addQuestionDescription');
		this.answerBox = this.el.querySelector('.answer-container');
		this.doneButton = this.el.querySelector('#done');
		this.nextButton = this.el.querySelector('.next');
		this.editorTop = this.el.querySelector('.editor-top');
		this.editorTopQuestion = this.el.querySelector('.addQuestion-editor');
		this.editorTopDescription = this.el.querySelector('.addQuestionDescription-editor');
		this.titleMinLength = 2;
		this.titleMinCharacters = 20;
		this.descriptionMinLength = 0;
		
 	   
		
		this.renderSliderValues(this.abacusSlider,this.sliderParent);
	
	};
	createQuiz.prototype.activateContent =  function activateContent(currentTab){
		this.answerCK12.classList.remove('active');
		this.questionCK12.classList.remove('active');
	
 	   	currentTab.classList.add('active') ;
     };
 	createQuiz.prototype.AddTinyMCE =  function AddTinyMCE(){
 		/**adding tinymce editor**/

 	
 			if(!this.editorCreated ){
 				this.questionEditorCreator = null;
 				this.descriptionEditorCreator=null;
 				startLoadingAnim("loading");
 				this.questionEditorCreator = new Qtinymce({className:"editQuestion",height:"7vh",keyUpCallback:this.checkForComment,containerId:"addQuestion",initCallback:function(){/*startLoadingAnim("loaded");*/}});
 	 			this.descriptionEditorCreator = new Qtinymce({className:"editDescription",height:"30vh",keyUpCallback:this.checkForComment,containerId:"addQuestionDescription",initCallback:function(){startLoadingAnim("loaded");}});	
 	 			this.editorCreated = true;
 			}
 			
 	
 		
     };
 	createQuiz.prototype.createCarousel =  function createCarousel(){
		if(!this.carouselRendered){
		    var CarouselOptions = {
	            	container : this.answerBox,
	            	children : "",
	            	paginationDots : true,
	            	navigationArrows : false,
	            	noOfTilesPerPage : [2,1],
	            	marginInPercentage : 1.35
	            } ;
	                
	   this.quizCarousel = new Carousel(CarouselOptions);
	   	this.carouselRendered = true;
		}else{
			return
		}
     };

 	createQuiz.prototype.updateSliderValues = function updateSliderValues(abacus,updatePostion){
 		
 		for(var i in abacus.abacusSliders){
			abacus.abacusSliders[i].update(updatePostion[i]);
		}
 		 this.answerObject = {};
		 for(var i in abacus.abacusSliders ){
			 this.answerObject[abacus.abacusSliders[i].options["parameter"]] = abacus.abacusSliders[i].data[""] || abacus.abacusSliders[i].data[abacus.abacusSliders[i].options.UIValue] || abacus.abacusSliders[i].options.UIValue;
     	}
			
	};
	
	createQuiz.prototype.renderSliderValues = function renderSliderValues(abacus , container){
		for(var i in abacus.abacusSliders){
			if(parseInt(i)){
				var seperator = document.createElement('div');
					seperator.className = 'seperator'; 
				    container.appendChild(seperator);
			}
			abacus.abacusSliders[i].renderAbacusSlider(container);
		}	
	};

	createQuiz.prototype.addNewAnswer = function addNewAnswer(){
		//this.createCarousel();
		var parent = document.createElement('div');
				parent.className = 'answers';
				
				parent.innerHTML  = this.answerContainerTemplate;
				this.answerBox.appendChild(parent);
				//add inside container ....
				 var sliderParent = parent.querySelector('.slider-value-container');
				 	 /*sliderParent.innerHTML = this.editAnswerTemplate;*/
				 	 
				  this.answer = new AbacusSlider({sliders:this.scene.additionalScene.sliders,removeCallback:true,addValue:["ANY"]});
				 this.answerSliders.push(this.answer.abacusSliders);
				
				 //render Sliders
				 this.renderSliderValues(this.answer,sliderParent);
				 //disable sliders 
				 this.disableSliders(this.answer.abacusSliders);
				// update slider values 
				 this.updateAnswer(this.answer);
				 

	};
	createQuiz.prototype.updateAnswer = function updateAnswer(sliders){

		// update slider values  
			
		 var currentValues = [];
		 for(var i in this.abacusSlider.abacusSliders){
			 currentValues.push(this.abacusSlider.abacusSliders[i].sliderObj.currentPosition);
		 }
		 
		 this.updateSliderValues(sliders,currentValues);	
		
	
	};
	createQuiz.prototype.disableSliders = function disableSliders(sliders){

		// update slider values  
			
		 for(var i in sliders){
			 sliders[i].disable();
		 }	
			
			
	};
	createQuiz.prototype.deleteAnswer = function deleteAnswer(answer){

		// delete answer  
			
		var index = this.answerSliders.indexOf(answer);
					this.answerSliders.splice(index, 1);
			
			
	};
	createQuiz.prototype.editAnswer = function editAnswer(answer){

		// edit slider values  
			
	
			
			
	};
	createQuiz.prototype.editQuizQuestion = function editQuizQuestion(object){
		this.editQuestionMode = true;
    	this.currentQuestionData = object;
    	if(tinymce.editors.addQuestion){
    	 	tinymce.editors.addQuestion.setContent(this.currentQuestionData.questionData.questionText);
        	tinymce.editors.addQuestionDescription.setContent(this.currentQuestionData.questionData.questionDescription);
    	}else{
    		this.title.value = this.currentQuestionData.questionData.questionText;
        	this.description.value = this.currentQuestionData.questionData.questionDescription;
    	}
  
    	this.titleDone = true;
    	this.descriptionDone = true;
    	this.checkForDone();   	 
    	this.saveAnswer();
      	this.setPreviousAnswer();
    	this.next =  true;
    	 this.editorTopQuestion.classList.add('hide');
  	   	this.editorTopDescription.classList.add('hide');
    
	}
	createQuiz.prototype.setPreviousAnswer = function setPreviousAnswer(){
	
		var previousAnswer = []
		for(var i in this.answer.abacusSliders){
			previousAnswer.push(this.answer.abacusSliders[i].options.shifts.indexOf(this.currentQuestionData.questionData.answer[0][this.answer.abacusSliders[i].options.parameter])+1);
		}
		 this.updateSliderValues(this.answer,previousAnswer);
	}
	
    
    // This function creates an overlay and shows sending progess/animation
    function startSendAnim(type){
    	var progress = document.querySelector("#inProgressScreen2");
    	
    	switch (type){ 	
    	case "sending" : progress.classList.add('top');
	    				 progress.classList.remove('hide');
    				     break;
    	case "sent"   :  progress.classList.remove('top');
						 progress.classList.add('hide');
    					 break;
    	}

    }
    // This function creates an overlay and shows loading progess/animation
    function startLoadingAnim(type){
    	var progress = document.querySelector("#loaderScreen");
    	
    	switch (type){ 	
    	case "loading" :
	    				 progress.classList.remove('hide');
    				     break;
    	case "loaded"   :  
						 progress.classList.add('hide');
    					 break;
    	}

    }
    return createQuiz;
}) ;;define('LoginView',['CommonView','HostURLs'],function(CommonView,HostURLs){
    
    function LoginView(scene){
    	
    	this.scene = scene;
         
    	var template = '<div class="background"></div><div class="loginView-container"><div class="header">You need to be logged in to create questions.</div>'
    		+'<div class="login-button">Proceed to Sign in</div>'
        	+'<div class="loginClose"></div></div>';
        
        CommonView.apply(this , [{
            template:template, 
            name :'LoginView',
            el: 'div'
        }]);
        
        this.events = {
          'click .loginClose':'closeLogin',
           'click .login-button':'goToLogin'
        };
        /*'click .background':'closeConcept',*/
        
        this.stopPropagation = function(e){
            e.stopPropagation();
        };
        
        this.closeLogin = function(e){
        	e.stopPropagation();
        	this.scene.hideView('loginView');
            this.scene.showView('quizMainScreen');
        }.bind(this);
        
        this.goToLogin = function(e){
        	e.stopPropagation();
        	window.location = URL.AUTH_HOST_URL+"signin?returnTo="+encodeURIComponent(window.location.href);
        }.bind(this);
        
    }
    
    LoginView.prototype = Object.create(CommonView.prototype);
    LoginView.prototype.constructor = LoginView;
    
    return LoginView;
    
});;define('MessageModalView',['CommonView'],function(CommonView){
	
	function MessageModalView(){
		var template = '<div class="msg-modal-box">'
				 			+'<div class="msg-modal-infoContainer"></div>'
				 			+'<div class="msg-modal-close"></div>'
				 			+'<div class="msg-modal-button-container"></div>'
						+'</div>';
		this.fontColor = "#2196F3";
		this.backgroundColor= "transparent";
		
		CommonView.apply(this , [{
			template:template,
			name :'MessageModalView',
			el: 'div',
			classes:['msg-modal-overlay']
		}]);
	}
	
	MessageModalView.prototype = Object.create(CommonView.prototype);
	MessageModalView.prototype.constructor = MessageModalView;
	
	/**********     showMessageModal
	 * [
	 * 		{
	 * 			name:'name',
	 * 			color:'color',
	 * 			backgroundColor:'background-color',
	 * 			callback:'callback',
	 * 			cross:true
	 * 		}
	 * ]
	 ****************/
	MessageModalView.prototype.createMessageModal = function(options){
		this.el.querySelector('.msg-modal-infoContainer').innerHTML = options.message;
		this.msgModalClose = this.el.querySelector('.msg-modal-close');
		this.cross = options.cross ? options.cross:true;
		var buttonTemp = '';
		if(options.buttons){
			for(var i=0; i<options.buttons.length; i++){
				buttonTemp+= '<div  class="msg-modal-button-parent"><div  class="msg-modal-button">'+options.buttons[i].name+'</div></div>';
			}
			
			this.el.querySelector('.msg-modal-button-container').innerHTML = buttonTemp;
			var buttons = this.el.getElementsByClassName('msg-modal-button');
			for(var i=0; i<options.buttons.length; i++){
				buttons[i].style.backgroundColor = options.buttons[i].backgroundColor || this.backgroundColor;
				buttons[i].style.color = options.buttons[i].color || this.fontColor;
				if(options.buttons[i].callback){
					buttons[i].addEventListener('click',options.buttons[i].callback,false);
				}
				
			
			}
		}
		

		if(this.cross){
			this.msgModalClose.classList.remove('hide');
			this.msgModalClose.addEventListener('click',function(){
				this.eventHandler.emit('hideMessageModal');
			}.bind(this),false);
		}else{
			this.msgModalClose.classList.add('hide');
			this.msgModalClose.removeEventListener('click',function(){
				this.eventHandler.emit('hideMessageModal');
			}.bind(this));
		}
	};


	
	
	return MessageModalView;
});;define('MessageView',['CommonView'],function(CommonView){
	
	var timeout;
	function MessageView(){
		var template = '<div class="message-content"><div class="panda hide"></div><div class="rat hide"></div></div>'
		CommonView.apply(this , [{
			template:template,
			name :'MessageView',
			el: 'div',
			classes:['message-container']
		}]);
	}
	
	MessageView.prototype = Object.create(CommonView.prototype);
	MessageView.prototype.constructor = MessageView;
	

	MessageView.prototype.popMessage = function(message){
		this.el.querySelector('.message-content').innerHTML = message;
		this.el.classList.add('message-container-show');
		var that = this;
		timeout = window.setTimeout(function(){
			that.closeMessage();
		},4000);
	};
	
	MessageView.prototype.closeMessage = function(){
		window.clearTimeout(timeout);
		this.el.classList.remove('message-container-show');
	};
	
	return MessageView;
});;define('MoreView',['CommonView','ajax','utility','HostURLs'],function(CommonView,ajax,utility,HostURLs){
	
	
	/**
	 * Creates toolbar view
	 * @constructor ToolBarView
	 */
	var shareMedium ;
	var onceRendered = false;
	/*<div id="reportIssue" class="menu-options vertical-buttons icon report-issue"><span><div class="icon-container"></div>Report an issue</span></div>*/
	
	function MoreView(info){
		var hideAvatar = "";
		
		this.firstName = info.firstName || '';
        this.lastName = info.lastName || '';
        this.imageURL = info.imageURL;
        this.email = info.email || '';
		this.locAPP = utility.getUrlParameters("loc")
		if(!info.email || this.locAPP== "app"){
			 hideAvatar = 'hide';
//			 marginRight = 'margin-right-zero';
		}
		
		 /*horizontal-buttons icon share mail st_email*/
		var template = '<div id="" class="menu-options-parent ">'
					 		+'<div id="aboutSim" class="menu-options vertical-buttons icon about"><div class="icon-container"></div><span>About</span></div>'
					 		+'<div id="reportIssue" class="menu-options vertical-buttons icon report-issue"><div class="icon-container"></div><span>Report an issue</span></div>'
					 		+'<div class="seperator ' +hideAvatar+'"></div>'
					 		+'<div class="menu-options vertical-buttons image name '+hideAvatar+'"><div class="icon-container"><img src="'+this.imageURL+'" title="'+this.firstName+' '+this.lastName+'"/></div><div class=" user-info name">'+this.firstName+' '+this.lastName+'</div><div class="user-info email">'+this.email+'</div></div>'
					 		+'<div id="sign-out" class="menu-options vertical-buttons icon sign-out ' +hideAvatar+'"><div class="icon-container"></div><span>Sign Out</span></div></div>';
		/*+'<div id="" class="menu-options-parent share-menu">'
					 		+'<div class="menu-title">Share</div>'
					 		+'<div id="facebookShare" class="horizontal-buttons icon share facebook" displayText=""><span id="" class="st_facebook" displayText=""></span></div>'
					 		+'<div id="twitterShare" class="horizontal-buttons icon share twitter" displayText=""><span id="" class="st_twitter" displayText=""></span></div>'
					 		+'<div id="mailShare" class="horizontal-buttons icon share mail" displayText=""><span id="" class="st_email" displayText=""></span></div>'
					 		+'<div id="" class="menu-options horizontal-buttons icon share group hide" displayText="Group"></div></div>' ;*/
					 	/*+'<div id="" class="menu-options-parent likes-menu">'
					 		+'<div id="" class="menu-options horizontal-buttons icon like"></div>'
					 		+'<div id="" class="menu-options horizontal-buttons icon dislike"></div></div>';*/
		
/*		var scriptShareThisPre = document.createElement('script');
	      scriptShareThisPre.type = 'text/javascript';
	      scriptShareThisPre.innerContent = 'var switchTo5x=true;';
	      
	      var scriptShareThis = document.createElement('script');
	      scriptShareThis.type = 'text/javascript';
	      scriptShareThis.src = 'http://w.sharethis.com/button/buttons.js';
	      
	      var scriptShareThisPost = document.createElement('script');
	      scriptShareThisPost.type = 'text/javascript';
	      scriptShareThisPost.innerContent = 'stLight.options({publisher: "136f428e-4180-40f8-8a1e-f571da7f1dda", doNotHash: false, doNotCopy: false, hashAddressBar: false});';
	      
	      var templateShareScript = '<script type="text/javascript">var switchTo5x=true;</script>'
				+'<script type="text/javascript">stLight.options({publisher: "136f428e-4180-40f8-8a1e-f571da7f1dda", doNotHash: false, doNotCopy: false, hashAddressBar: false});</script>';


			var pseudoContainer = document.createElement("script");
			pseudoContainer.innerHTML = templateShareScript;*/
			
		
		CommonView.apply(this , [{
			template:template,
			name :'MoreView',
			el: 'div',
			classes:['menu-container'],
			initialize : this.initialize
		}]);
				
		this.events = {
				'click el':'stopEventPropagation',
				'click #aboutSim':'openAbout',
				'click #reportIssue':'openReportIssue',
				'click #sign-out': 'signOut'
		};
		
		this.liked = false;
		this.disliked = false;
		
		this.stopEventPropagation  = function stopEventPropagation(e){
			e.stopPropagation();
		};
		this.signOut = function(e){
       	 window.location = URL.USER_ACOUNT_HOST_URL+'signout';
       	 ajax.send(URL.AUTH_HOST_URL+'logout/member',{
       	  message: null,
       	  withCredentials: true,
       	  callback: function(){}
       	 });
        };
		this.openAbout = function openAbout(e){
			this.eventHandler.emit('showAbout');
			this.close(e);
		}.bind(this);
		
		this.openReportIssue = function openReportIssue(e){
			this.eventHandler.emit('showReportIssue',{'ID':'5'});
			this.close(e);
		}.bind(this);
				
	}
	function _dexterShareEvents() {
		
		/*
		dexterjs.logEvent("FBS_SHARE", {
			social_network :  shareMedium 
        });
	*/}
	
	
	MoreView.prototype = Object.create(CommonView.prototype);
	MoreView.prototype.constructor = MoreView;
	

	
	MoreView.prototype.initialize = function initialize(){
		this.eventHandler.on('showMore',function(){
			var more = document.querySelector('#toolBarMore');
		   this.el.style.left = more.offsetParent.offsetLeft+more.offsetLeft-this.el.clientWidth+more.clientWidth - 2 +"px";
		   this.el.style.top  = more.offsetTop+"px";
	}.bind(this)); 
		
		this.like    =  this.el.querySelector('.like');
		this.dislike =  this.el.querySelector('.dislike');
	};
	
	MoreView.prototype.sendFeedback = function sendFeedback(value){/*
		var artifactID = utility.getUrlParameters("artifactID");
		var params = {
				"artifactID":artifactID,
				"type":"vote",
				"vote":value,
				"comments":""				
		}
		
		ajax.send("/flx/create/feedback",params,function(reponse){
			console.log(response);
		});
	*/};

	
	MoreView.prototype.open = function open(){
		this.el.style['webkitTransform'] = 'scale(1)';
		this.el.style['transform'] = 'scale(1)';
		this.eventHandler.emit('closeFont');
		
		if(onceRendered === false){
			
		}
	};
	
	MoreView.prototype.close = function close(e){
		
		if(e.target == document.querySelector('.more'))
			return;
		this.el.style['webkitTransform'] = 'scale(0)';
		this.el.style['transform'] = 'scale(0)';
	};
	
	return MoreView;
	
});;define('NavView' ,['CommonView'],function(CommonView){
	
	
	function NavView(){
		
	var template = '<div class="navigation previous" id="navPrev">'
				  +'</div><div class="navigation next bounceActive " id="navNext"></div>';
	
	CommonView.apply(this,[{
		'template' :template,
		'name' :'NavigationView',
		'initialize' :this.init,
		'type' :'div'
	}]);
	
	if(/iPad|iPhone|iPod/.test(navigator.userAgent) && !window.MSStream){
		this.events = {
				'touchstart #navPrev':'prevScene',
				'touchstart #navNext' :'nextScene'
		};
	}else{
		this.events = {
				'click #navPrev':'prevScene',
				'click #navNext' :'nextScene'
		};
	};
			
		
	
	this.prevScene = function prevScene(e){
		this.eventHandler.emit('prev',e);
	}.bind(this);
	
	this.nextScene = function nextScene(e){
		this.eventHandler.emit('next',e);
	}.bind(this);
		
	}
	
	NavView.prototype = Object.create(CommonView.prototype);
	NavView.prototype.constructor = NavView;
	
	NavView.prototype.init = function(){
		this.prev = this.el.querySelector('.previous');
		this.next = this.el.querySelector('.next');
	};
	
	NavView.prototype.hide = function(arrow){
		this[arrow].style['display'] = 'none';
	};
	
	NavView.prototype.show = function(arrow){
		this[arrow].style['display'] = 'block';
	};
	

	
	
	return NavView;
	
	
	
});;define('QuizView',['CommonView','Carousel','utility','ajax','HostURLs'],function(CommonView,Carousel,utility,ajax,HostURLs){
	
	function quizView(data, scene) {
		var contentSource_CK12 = "CK12 Content" ,
		contentSource_community = "Community Contributed" ,
		contentSource_ALL = "Attempted" ,lastAnswerTemplate = ""; 
		
		/*this.currentData = this.data.quiz;*/
		this.offlineFlag = 0;
        this.scene = scene;
        this.firstTimeRendering = true;
        this.scene.additionalScene.rendered = true;
    	this.data = data ; 
    	this.flag_community = 0;
    	this.flag_attempted = 0;
    	this.flag_CreateQuizView = 0;
    	this.flag_TakeQuizView = 0;
    	this.flag_CK12 = 0;
        this.currentUserIsAdmin = (function(){
			for(var i in this.data.userData.roles){
				if(this.data.userData.roles[i].name=="admin" || this.data.userData.roles[i].name=="content-admin"|| this.data.userData.roles[i].name=="support-admin"||this.data.userData.roles[i].is_admin_role == true)
					return true;
			}
        }).call(this) || false;
    	this.noOfQuesPerPage = 5;
        /**Adding background**/
        
        var background = document.createElement('div');
            background.classList.add('background-rwe');
            background.classList.add('background-quiz');
            background.style.backgroundImage="url('"+data.background+"')";
        /**Adding Create Quiz**/
        
        this.createQuizTemplate = '<div class="quiz-content create hide">Create new question</div>' ;
        
        /**Adding default Questions Quiz**/
            
        this.questionsTemplate = "";
        this.editQuestionTemplate = '<div title="Edit" class="quiz example-edit"></div><div title="Delete" class="quiz example-delete hide"></div>';
        /**view Answer */
        this.viewAnswerTemplate = '<div class="quiz view-answer">Your answer<span class="quiz-dropdown"></span></div>';
        /**Adding into container*/
        /**Publish question*/
        this.publishQuestionTemplate = '<div class="publish-question">Publish</div>';
        var quizContainer = '<div class="quiz-container" id="quizContainer"></div>';
        
        var template = '<div id="contentHeader" class="content-header"><div class="level-filter hide">All Levels</div><div class="quiz-content-menus-list " id="contentMenusList"><div class="content-menu content-width" id="contentCK12" >'
        	            +contentSource_CK12+'<span class= "header-count ck12-count content-count">0</span>'+'</div><div class="content-menu content-width" id="contentCommunity" >'
        	            +contentSource_community+'<span class= "header-count community-count community-count">0</span>'+'</div><div class="content-menu content-width hide" id="contentAttempted">'
        	            +contentSource_ALL+'<span class= "header-count attempted-count">0</span>'+'</div></div></div>' 
        	            +'<div class="msg-overlay hide">'+
							'<div class="msg-box">'+
					 			'<div class="msg-Close"></div>'+
					 			'<div class="msg-infoContainer">Are you sure you want to remove this example permanently?</div>'+
					 			'<div class="button-container ">'+
						 			'<div  class="rwe-delete submit-button report-button">REMOVE</div>'+
						 			'<div  class="rwe-delete-cancel cancel-button report-button">CANCEL</div>'+
					 			'</div>'+
					 		'</div>'+
				 		'</div>';
        
            template = background.outerHTML+ template + quizContainer ;
     
       
        CommonView.apply(this , [{
			template:template,
			name :'quizContentView',
			el: 'div',
			initialize: this.init
		}]);
        
        
        this.events = {
            'click #contentCK12' : 'showContent_CK12',
            'click #contentCommunity' : 'showContent_community',
            'click #contentAttempted' : 'showContent_attempted'
        };
        
        this.showContent_CK12 = function showContent_CK12(event){
        	
        	if(this.flag_CK12 == 0){
        		this.bindEvent_CK12(event);
        		this.flag_CK12 = 1;
        		this.refreshView();
        	};
        	this.eventHandler.emit('showQuiz_CK12');
        	/*if(event){
        		dexterjs.logEvent("FBS_SIMULATION_QSOURCE_TOGGLE", {
            		"tab" : this.currentContent
                });	
        	}*/
        	
        }.bind(this);
        
        this.showContent_community = function showContent_community(event){
        	if(this.flag_community == 0){
        		this.bindEvent_community(event);
        		this.flag_community = 1;
        	};
        	this.eventHandler.emit('showQuiz_community');
        	/*if(event){
        		dexterjs.logEvent("FBS_SIMULATION_QSOURCE_TOGGLE", {
            		"tab" : this.currentContent
                });	
        	}*/
        }.bind(this);
        
        this.showContent_attempted = function showContent_attempted(e){
        	if(this.flag_attempted == 0){
        		this.bindEvent_attempted(e);
        		this.flag_attempted = 1;
        	};
        	this.eventHandler.emit('showQuiz_attempted');
        }.bind(this);
        
        
        
        this.showCreateQuizView = function showCreateQuizView(e){
        	if(this.flag_CreateQuizView == 0){
        		this.bindEventCreateQuiz(e);
        		this.flag_CreateQuizView = 1;
        	};
        	this.eventHandler.emit('showCreateQuizView');
        	//if(e.target.innerHTML == "Create new question")
        	/*dexterjs.logEvent("FBS_SIMULATION_QCREATE", {
            });*/
        }.bind(this);
        
        
      //................ for config mang...........
        this.bindEventCreateQuiz = function bindEventCreateQuiz(e){
        	this.eventHandler.on('showCreateQuizView', function(e) {
            	this.scene.hideView('quizMainScreen');
            	this.scene.showView('createQuizView');
            	this.scene.createQuizView.initializeSetting();
            }.bind(this));
        }.bind(this);
        
        this.bindEvent_attempted = function bindEvent_attempted(e){
        	this.eventHandler.on('showQuiz_attempted', function(e) {
        		this.activateContent(this.contentAttempted) ;
            	this.currentData = this.QuizData["attempted"];
            	this.currentContent = "attempted";
            	//this.click = false;
            	this.update();
            }.bind(this));
        }.bind(this);
        
        this.bindEvent_community = function bindEvent_community(event){
        	this.eventHandler.on('showQuiz_community', function(event) {
        		this.activateContent(this.contentCommunity) ;
            	this.currentData = this.QuizData["userOwnedData"];
            	for(var i in this.QuizData["usersData"]){
            		this.currentData[i] = this.QuizData["usersData"][i];
            	}
            	this.currentContent = "community";
            	this.update();
            }.bind(this));
        }.bind(this);
        
        this.bindEvent_CK12 = function bindEvent_CK12(event){
        	this.eventHandler.on('showQuiz_CK12', function(event) {
        		this.activateContent(this.contentCK12);
            	this.currentData = this.QuizData["ck12Data"] ;
            	this.currentContent = "ck12";
            	this.update();
            	if(window.retry==true){
            		this.refreshView();
            	}
            }.bind(this));
        }.bind(this);
        
        this.bindEvent_TakeQuizView = function bindEvent_TakeQuizView(e){
        	this.eventHandler.on('showQuiz_TakeQuizView', function(e) {
        		event.stopPropagation();
        		this.lastAnswerContainer = null;
        		var questionID = event.currentTarget.id;
       
        		if(this.currentContent == "attempted"){
        			
        		}else{
        			if(!this.responseQuiz.message){
        				this.scene.hideView('quizMainScreen');
                    	this.scene.showView('takeQuizView');
             
                    	this.scene.takeQuizView.setData(this.currentData[questionID],this.responseQuiz.test._id,questionID);
                    	this.renderSandboxScene();
                    	if(this.currentContent == "attempted"){
                			this.scene.takeQuizView.setAttemptedData();
                		}else{
                			this.scene.takeQuizView.updateSliderValues("initial");
                		}
        			}else{
        				this.messageType = "message";
        				this.displayMessage(this.responseQuiz.message);
        			}
        		}
            }.bind(this));
        }.bind(this);
        
    	//....................................
        
        this.showTakeQuizView = function showTakeQuizView(e){
        	if(this.flag_TakeQuizView == 0){
        		this.bindEvent_TakeQuizView(e);
        		this.flag_TakeQuizView = 1;
        	};
        	this.eventHandler.emit('showQuiz_TakeQuizView');        	
        }.bind(this);
        
        this.editQuestion = function editQuestion(e){
        	e.stopPropagation();
        	//call createQuiz function to edit details
        	this.showCreateQuizView(e);
        	this.scene.createQuizView.editQuizQuestion(this.currentData[e.target.parentElement.parentElement.id]);

        }.bind(this);
        this.deleteQuestion = function deleteQuestion(e){
        	e.stopPropagation();
        	//call api to delete question
        }.bind(this);

        this.publishQuestion = function publishQuestion(e){
        	e.stopPropagation();
        	//call api to publish question
        	var questionID = e.target.parentElement.parentElement.id;
        	var publishQuestionParams = {};
        		publishQuestionParams["publishComment"] = "Thanks for your contribution! Your question is public now.";
          	var formData = new FormData();
        	for(var i in publishQuestionParams){
       		 formData.append(i, publishQuestionParams[i]);
        	}
        	var publishedCallback = function(response){
          		var responsePublish = (response.status === 200) ? JSON.parse(response.response) : {response : {test :{ items:[]}}};
                	
                	if(responsePublish.response.message){
                		this.messageType = "message";
                		this.displayMessage(responsePublish.response.message);
                	}else{
                		this.messageType = "published";
                		this.refreshView();
                	}
                	
        	}.bind(this);
    		ajax.sendFormData(URL.PUBLISH_QUES_HOST_URL+questionID,{
				withCredentials : true,
				message:formData,
				callback :publishedCallback
			});
        	
  
        }.bind(this);
        this.showSubmittedAnswer = function showSubmittedAnswer(e){
        	e.stopPropagation();
        	//show last submitted Answer
        	var container = e.currentTarget.parentElement.parentElement;
        	var task =  container === this.lastAnswerContainer? "lastOneClicked" : "newOneClicked";
        		task = 	container.opened && container.querySelector('.view-answer-container').innerHTML? "closeClicked" : task ;
        	
        	

        	this.newOneClicked = function(container){
        		container.opened = true;
        		
        		var questionID  = container.id;
             	//call renderQuestion API to get lastSubmitted Answer
             	startLoadingAnim("loading");
     			
             	this.setPreviousAnswer = function(response){
     			var testSheet = (response.status === 200) ? JSON.parse(response.response) : {response : {test :{ items:[]}}};
     			this.currentTestSheetObject = testSheet.response ;
     			this.lastAnswer = JSON.parse(this.currentTestSheetObject.lastUserInput);
     			this.UILabelObj = {};
     			this.UIUnitObj = {};
     			for(var i in this.scene.additionalScene.sliders){
     				this.UILabelObj[this.scene.additionalScene.sliders[i].options.parameter]=this.scene.additionalScene.sliders[i].options.UILabel.replace(/=/g,"");
     				this.UIUnitObj[this.scene.additionalScene.sliders[i].options.parameter]=this.scene.additionalScene.sliders[i].options.UIUnit;
     			}
     			lastAnswerTemplate = "";
     			for(var i in this.UILabelObj){
     				lastAnswerTemplate = lastAnswerTemplate + '<div class="last-Answer-parameter"><div class="ui-label">'+this.UILabelObj[i]+'</div><div class="ui-value">= '+this.lastAnswer[i]+" "+this.UIUnitObj[i]+'</div></div>'
     			}
     			container.querySelector('.view-answer-container').classList.remove('hide');
     			container.querySelector('.view-answer-container').innerHTML = lastAnswerTemplate;
     			container.querySelector('.quiz-dropdown').classList.add('rotate');
     			
     			startLoadingAnim("loaded");
     	
     			}.bind(this);
     			ajax.loadURL(URL.RENDER_QUES_INSTANCE_HOST_URL+this.responseQuiz.test._id+"/"+questionID,{
     				withCredentials : true,
     				callback :this.setPreviousAnswer
     			});
        	}
        	this.lastOneClicked = function(container){
        		container.opened = true;
        		container.querySelector('.view-answer-container').classList.remove('hide');
        		container.querySelector('.view-answer-container').innerHTML = lastAnswerTemplate;
        		container.querySelector('.quiz-dropdown').classList.add('rotate');
        	}
        	this.closeClicked = function(container){
        		lastAnswerTemplate = container.querySelector('.view-answer-container').innerHTML;
        		container.querySelector('.view-answer-container').innerHTML = "";
        		container.querySelector('.view-answer-container').classList.add('hide');
        		container.querySelector('.quiz-dropdown').classList.remove('rotate');
        		container.opened = false;
        	}
        	
        	switch(task){
        	
        	case "newOneClicked" : //code
        							this.newOneClicked(container);
        							break;
        	case "lastOneClicked" : //code
        							this.lastOneClicked(container);
									break;
        	case "closeClicked" : //code
        							this.closeClicked(container);
									break;
        	
        	}
        	this.lastAnswerContainer = e.currentTarget.parentElement.parentElement;
   	
        }.bind(this);
    }

	
    quizView.prototype = Object.create(CommonView.prototype);
    quizView.prototype.constructor = quizView;

    quizView.prototype.showContent = function showContent(){
    	
    	switch (this.currentContent){ 	
    	case "ck12" 	 :	this.showContent_CK12();
    				     	break;
    	case "community" :	this.showContent_community();
    					   	break;
    	case "attempted" :	this.showContent_attempted();
		   					break;
    	}

    };
    
    quizView.prototype.init = function init(){
    	
    	this.contentMenuTabs = this.el.querySelector('.content-menu');
    	this.carouselExampleContainer = this.el.querySelector('.carousel-example-container');
		this.contentCK12 = this.el.querySelector('#contentCK12');
		this.contentCommunity = this.el.querySelector('#contentCommunity');
		this.contentAttempted = this.el.querySelector('#contentAttempted');
		this.contentCK12.classList.add('active'); // added temporarily 
		this.quizContainer = this.el.querySelector('.quiz-container');
		this.ck12Count = this.el.querySelector('.ck12-count');
		this.communityCount = this.el.querySelector('.community-count');
		this.attemptedCount = this.el.querySelector('.attempted-count');
		
		//get data 
		this.currentContent = "ck12";
		this.messageType = "";
		
		this.QuizData = {
				"ck12Data":{},
				"userOwnedData":{},
				"usersData":{},
				"attempted":{}
			}
		
		this.getQuizData();
	};
    
	quizView.prototype.activateContent =  function activateContent(currentTab){
		this.contentCommunity.classList.remove('active');
		this.contentCK12.classList.remove('active');
		this.contentAttempted.classList.remove('active');
 	   	currentTab.classList.add('active') ;
     };
 	quizView.prototype.setCount =  function setCount(){
		this.ck12Count.innerHTML = this.ck12DataCount;
		this.communityCount.innerHTML = this.ownedDataCount + this.usersDataCount;
		this.attemptedCount.innerHTML = this.attemptedDataCount;
     };
     var myTime ;
 	quizView.prototype.refreshView =  function refreshView(){
 		setTimeout(function(){this.getQuizData()}.bind(this),10);
     };
  	quizView.prototype.displayMessage =  function displayMessage(msg){
  		
  	  	switch (this.messageType){ 	
    	case "updated" :	this.eventHandler.emit('showMessage',{ message : "Question updated successfully."});
    						break;
    	case "created" :	this.eventHandler.emit('showMessageModal',{ message : "Thank you for your contribution. Our team will review this question and make it available to our users. Please contact us at support@ck12.org, if you have any questions.", buttons:[{name:"OK",callback:function(){this.eventHandler.emit('hideMessageModal')}.bind(this)}]});
    					 	break;
    	case "message" :	this.eventHandler.emit('showMessage',{ message : msg});
    						break;
    	case "published" :	this.eventHandler.emit('showMessage',{ message : "Published."});
							break;
    	}
  	  this.messageType = "";
     };
    quizView.prototype.update = function update(){
    	var questions = this.createQuizTemplate ,
    	 wrapper = "",
    	 adajcentWrapper = "",
    	 count = 1;
    	for(var i in this.currentData){
    		count++;
    		var viewAnswer="", viewAnswerContainer="",publish = "",
    			classList = (this.currentData[i].questionData.ownerID) === "ck12"?  "ck-12" : "community" ;
    	    var controles = (this.currentUserIsAdmin || (parseInt(this.currentData[i].questionData.ownerID) === this.data.userData.id))&&(this.currentContent !== "attempted")?  this.editQuestionTemplate : "" ;
    	    this.locAPP = decodeURIComponent((new RegExp('[?|&]' +'loc' + '=' + '([^&;]+?)(&|#|;|$)').exec(location.search) || [, ""])[1].replace(/\+/g, '%20')) || null;
    		if(this.locAPP== "app"){
    			controles = "";
    		}
    	    if(this.QuizData["attempted"][i]){
    			 viewAnswer = this.viewAnswerTemplate;
    			/* classList = classList+" attempted attempted-question" ;*/
    			 classList = classList+" attempted-question" ;
    			 viewAnswerContainer = '<div class="view-answer-container hide"></div>';
    		}else{
    			publish =  this.currentUserIsAdmin && (!this.currentData[i].isPublic)?  this.publishQuestionTemplate : "" ; 
    			if(this.locAPP== "app"){
    				publish = "";
        		};
        		//check in attempted question-list
        		/*if(this.QuizData["attempted"][i]){
        			 classList = classList+" attempted-question" ;
        		}*/
    		}

    		questions = questions + '<div class="quiz-content '+classList+' questions " id="'+i+'"><div class="question-text">'+this.currentData[i].questionData.questionText+'</div><div class="question-controls">'+viewAnswer+controles+publish+'</div>'+viewAnswerContainer+'</div>' ;  
    		if((count%this.noOfQuesPerPage)==0){
    			wrapper = wrapper + '<div class="wrapper">'+questions+'</div>';
    			questions = "";
    			adajcentWrapper = "";
    		}else{
    			adajcentWrapper = '<div class="wrapper">'+questions+'</div>';
    		}
    	}
    	if(count==1){
    		wrapper = wrapper + '<div class="wrapper">'+this.createQuizTemplate+'</div>';
    	}
    		
    	this.questionsTemplate = wrapper + adajcentWrapper;
    	var template = this.questionsTemplate;
    	this.quizContainer.innerHTML = "";
        var rweCarouselOptions = {
            	container : this.quizContainer,
            	children : template,
            	paginationDots : true,
            	navigationArrows : false,
            	noOfTilesPerPage : [1,1],
            	marginInPercentage : 0,
            	setStyles:true
            } ;
                
            this.quizCarousel = new Carousel(rweCarouselOptions);
            var events = {
                    'click .create' : this.showCreateQuizView,
                    'click .questions' :this.showTakeQuizView,
                    'click .example-edit' :this.editQuestion,
                    'click .example-delete' :this.deleteQuestion,
                    'click .view-answer' :this.showSubmittedAnswer,
                    'click .publish-question' :this.publishQuestion
        	} ;
        	
        	this.quizCarousel.bindEvents(events);
        	this.locAPP = decodeURIComponent((new RegExp('[?|&]' +'loc' + '=' + '([^&;]+?)(&|#|;|$)').exec(location.search) || [, ""])[1].replace(/\+/g, '%20')) || null;
    		if(this.locAPP== "app"){
    			var createEl = document.getElementsByClassName("quiz-content create")[0];
    			if(createEl){
    				createEl.hidden = true;
    			}
    		}
    };
    
    quizView.prototype.renderSandboxScene = function renderSandboxScene(){
		this.scene.additionalScene.render(this.scene.el.querySelector('#takeQuizView'));
		if(this.firstTimeRendering){
			this.scene.additionalScene.rendered = false;
			this.firstTimeRendering = false;
		}
		this.scene.eventHandler.emit('rendersandBoxScene');
	
	};
	quizView.prototype.getQuizData =  function getQuizData(){
	
		startLoadingAnim("loading");
		var paramsQuiz = {
    			artifactID : this.data.packageData.artifactID,
    			eids :  this.data.packageData.concepts		
    	};

    	
    	this._getDataQuiz = function _getDataQuiz(data){

    		ajax.loadURL(URL.TEST_HOST_URL+"sim%20interactive%20practice/simID/"+paramsQuiz.artifactID+"?includeItems=True",{
    			withCredentials : true,
    			callback : this.consumeDataQuiz
    		});
    		var getALL = this.currentUserIsAdmin? "&getAll=True":"";
    			
    		ajax.loadURL(URL.BROWSE_QUES_HOST_URL+"sim-interactive?filters=tags.simIDs,"+paramsQuiz.artifactID+"&pageNum=1&pageSize=100"+getALL,{
    			withCredentials : true,
    			callback : this.sortDataQuiz
    		});
  		
    	}
		this.consumeDataQuiz = function consumeDataQuiz(response){
    		var responseQuiz = (response.status === 200) ? JSON.parse(response.response) : {response : {test :{ items:[]}}};
    		if(response.status === 200){
    			this.offlineFlag = this.offlineFlag +1 ;
    		}
    			
    		this.responseQuiz = responseQuiz.response ;	
			if(this.responseQuiz.test){
				this.checkTest();
			}else{
				startLoadingAnim("loaded");
				this.showContent();
			}
			this.displayMessage();
			
    	}.bind(this)
		this.sortDataQuiz = function sortDataQuiz(response){
    		var responseQuizQuestions = (response.status === 200) ? JSON.parse(response.response) : {response : {test :{ items:[]}}};
    		if(response.status === 200){
    			this.offlineFlag = this.offlineFlag +1 ;
    		}
    		this.responseQuizQuestions = responseQuizQuestions.response ;
    		this.filterContentData();
    		this.showContent();	
			
    	}.bind(this)
 	    	/****
    	 * //call API for Attempted Question 
    	 *  
    	 * ****/	
    	this.checkTest = function checkTest(response){
    			ajax.loadURL(URL.TESTSCORE_DETAIL_HOST_URL+"concepts/my?scoreOffset=1&testID="+this.responseQuiz.test._id+"&submittedOnly=False",{
        			withCredentials : true,
        			callback :this.setTest
        		});
    			
    	}.bind(this);
    	this.setTest = function(response){
    		var responseTestScore = (response.status === 200) ? JSON.parse(response.response) : {response : {test :{ items:[]}}};
    		this.responseTestScore = responseTestScore.response.testScore ;
					startLoadingAnim("loaded");
					this.displayMessage();
					//this.setTestScore();
					if(responseTestScore.response.testScore){
						this.attemptedDataCount=responseTestScore.response.testScore.submissions.length;
						this.setAttemptedContent();	
						this.attemptedCount.innerHTML = this.attemptedDataCount;
						
					}
					this.showContent();	
		}.bind(this);
		
	
    	this._getDataQuiz();   	
     };
     quizView.prototype.setAttemptedContent = function setAttemptedContent(){
 		for(var i in this.responseTestScore.submissions){

				this.QuizData.attempted[this.responseTestScore.submissions[i].questionID] = this.responseTestScore.submissions[i].questionInstance;
				
		
		}
 	};
     quizView.prototype.setTestScore = function setTestScore(){
    	 this.testSheet = {};
    	 for(var i in this.responseTestScore.submissions){
    		 var testScore = {};
    		 testScore["sequence"] = this.responseTestScore.submissions[i].sequence;
    		 testScore["questionInstanceID"] = this.responseTestScore.submissions[i].questionInstanceID;
    		 this.testSheet[this.responseTestScore.submissions[i].questionID] = testScore;
    	 }
 	};
 	quizView.prototype.filterContentData = function filterContentData(){
 		this.ck12DataCount=0;
 		this.ownedDataCount=0;
 		this.usersDataCount=0;
 		this.attemptedDataCount=0;
		this.QuizData = {
	    					"ck12Data":{},
	    					"userOwnedData":{},
	    					"usersData":{},
	    					"attempted":{}
						}
	if(this.responseQuizQuestions.questions){
		for(var i in this.responseQuizQuestions.questions){
			if(this.responseQuizQuestions.questions[i].questionData.ownerID ==="ck12"){
				//check for ck12 data
				this.ck12DataCount++;
				this.QuizData.ck12Data[this.responseQuizQuestions.questions[i]._id] = this.responseQuizQuestions.questions[i];
			}else if(this.responseQuizQuestions.questions[i].questionData.ownerID ===this.data.userData.id){
				//check for user owned data
				this.ownedDataCount++;
				this.QuizData.userOwnedData[this.responseQuizQuestions.questions[i]._id] = this.responseQuizQuestions.questions[i];
			}else{
				//other users data
				this.usersDataCount++;
				this.QuizData.usersData[this.responseQuizQuestions.questions[i]._id] = this.responseQuizQuestions.questions[i];
			}
		}
	
			this.setCount();
		}
		
	}	
    
    // This function creates an overlay and shows sending progess/animation
    function startLoadingAnim(type){
    	var progress = document.querySelector("#loaderScreen");
    	
    	switch (type){ 	
    	case "loading" :
	    				 progress.classList.remove('hide');
    				     break;
    	case "loaded"   :  
						 progress.classList.add('hide');
    					 break;
    	}

    }
    return quizView;
}) ;;define('ReplayView',['CommonView'],function(CommonView){
	
	function ReplayView(){
		var template = '<div class="replay-container"><div class="replay-btn"></div><div class="next-btn"></div></div>';
		
		
	     CommonView.apply(this , [{
	            template:template,
	            name :'ReplayView',
	            el: 'div',
	            classes:['ReplayView-screen-overlay'],
	        }]);
	     
	     
	        this.events = {
	                'click .replay-btn':'replayVideo',
	                'click .next-btn':'nextScene',
	              };
		
	        this.replayVideo = function(e){
	        	this.eventHandler.emit("replay");
	        }.bind(this);
	        this.nextScene = function(e){
	        	this.eventHandler.emit("next");
	        	this.eventHandler.emit("showNextArrow");
	        }.bind(this);
	}
		
	return ReplayView;
});;define('ReportIssueView',['CommonView','ajax','HostURLs'],function(CommonView,ajax,HostURLs){
    
    function ReportIssueView(data){
    	
        this.questionNo = 0;
        this.data = data;
        this.isOpened = false;
        this.messages = {
        		"5" : "Issue reported. Thank you!",
        		"6" : "Feedback sent. Thank you for your valuable feedback!"
        };

        this.reportParams = {
        		"resourceID":data.resourceID,
        		"artifactID":data.artifactID
        };
        
        var infoNotAvailable = 'Information not available.' ;
        
        	 var template = '<div class="reportIssue-container" id="reportContainer"><div class="header">Report</div><div class="info-container">'
        		 +'<textarea id="reportIssueText" rows="4" cols="50" type="text" maxlength="300" class="comment-box" placeholder="Please type your report here."></textarea></div>'
        		 +'<div id="uploadError" class="hide">File format not supported, use jpg or png</div>'
        		 +'<div class="upload-img-list hide" id="imageList">'
		       	 +'<div class="upload-img">'
		         +'<span class="delete-icon"></span>'
		         +'<span class="img-name" id="imageUploaded">Image 01</span>'
		       	 +'</div>'
		       	 +'</div>'
        		 +'<div class="upload-images"><input class="input-image" id="inputImage" type="file">'
       		  	 +'<span class="upload-icon"></span>'
       		  	 +'<span class="upload-text">Upload Image</span>'
       		  	 +'</div>'
        		 +'<input type="file" name="pic" class="hide" accept="image/*">'
        		 +'<div class="button-container "><div id="sendReport" class="send-button report-button">SEND</div>'
        		 +'<div id="cancelReport" class="cancel-button report-button">CANCEL</div></div>'
        		 +'<div class="reportIssueClose"></div></div>' ;
        		 
        
        CommonView.apply(this , [{
            template:template,
            name :'ReportIssueView',
            el: 'div',
            classes:['ReportIssue-screen'],
            initialize: this.init
        }]);
        
        
        
        this.events = {
          'click .reportIssueClose':'closeReportIssue',
          'click #sendReport':'send',
          'click #cancelReport':'closeReportIssue',
          'blur #reportIssueText': 'scrollUp',
          'focus #reportIssueText':'scrollUp',
          'click el':'closeOnClick',
          'click #reportContainer':'stopPropagation',
          'change #inputImage':'imageUploader',
          'click .delete-icon':'deleteImage',
          'keyup #reportIssueText':'checkForComment'
        };
        
        this.closeOnClick = function closeOnClick(e){
/*        	 e.stopPropagation();
        	 this.eventHandler.emit('hideReportIssue');*/
        }.bind(this);

        this.stopPropagation = function stopPropagation(e){
        	e.stopPropagation();
        }	;
        this.checkForComment = function(e){
        	var comment = document.getElementById('reportIssueText');
        	var sendButton = document.getElementById('sendReport');
        	comment = comment.value;
        	comment = comment.replace(/^\s+|\s+$/g,'');
        	if(comment == ""){
        		sendButton.classList.remove('Active');
        	}else{
        		sendButton.classList.add('Active');
        	}
        }.bind(this);
        
        this.closeReportIssue = function(e){
        if(e)
         e.stopPropagation();
         this.imageUploaded.innerHTML = "";
         this.imageList.classList.add('hide');
         this.uploadError.classList.add('hide');
         document.querySelector("#reportIssueText").value = "";
         var sendButton = document.getElementById('sendReport');
         sendButton.classList.remove('Active');
         document.querySelector("#inProgressScreen2").classList.remove('top');
         document.querySelector("#inProgressScreen2").classList.add('hide');
         
         this.deleteImage();
         this.eventHandler.emit('hideReportIssue');
        }.bind(this);
        
        this.send = function(e){
        	var sendButton = document.getElementById('sendReport');
        	if(sendButton.classList.contains('Active')){
        		document.querySelector("#inProgressScreen2").classList.add('top');
        		document.querySelector("#inProgressScreen2").classList.remove('hide');
        		 
        		this.sendReport();
        	}else{
        		return false;
        	}
        }.bind(this);
        
        this.deleteImage = function deleteImage(){
        	  this.imageList.classList.add('hide');
        	  document.querySelector('#inputImage').value = "";
        }.bind(this);
        
        this.scrollUp = function scrollUp(e){
        	 if(navigator.userAgent.match(/(Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini)/g) ? true : false){
        		 window.scrollTo(0,0);
        	 }
        }.bind(this);
        
        
        this.imageUploader = function imageUploader(){
        	  var file    = document.querySelector('input[type=file]').files[0];
        	  this.uploadError.classList.add('hide');
        	  
        	  if(file){
 		    	 var  fileType = file.name.substring(file.name.lastIndexOf('.') + 1);
   		    	 if((fileType == "jpg")||(fileType == "png")||(fileType == "JPG")||(fileType == "PNG")||(fileType == "jpeg")||(fileType == "JPEG")){
   		    		this.imageUploaded.innerHTML = file.name;
   		    		this.imageList.classList.remove('hide');
   		    	}else{
   		    		this.deleteImage();
   		    		this.uploadError.classList.remove('hide');
   		    	}
        	  }
        }.bind(this);
        

        this.uploadImage = function(callback){
        	  var file    = document.querySelector('input[type=file]').files[0],
        	      reader  = new FileReader(),
        	      timeStamp = new Date().getTime(),
        	      formData ;
        	  var  that = this;
        	  
			    if (window.FormData !== undefined && file !== undefined) {
			     
			        formData = new FormData();
			        var postConfig = {
			        	resourceType: "image",
			            resourceName: file.name,
			            resourceDesc: "",
			            isAttachment: false,
			            isPublic: false
			        };
			        
			        formData.append("resourcePath", file, timeStamp + "_" + file.name);
			        for (var i in postConfig) {
			            if (postConfig.hasOwnProperty(i)) {
			                formData.append(i, postConfig[i]);
			            }
			        }
			        formData.contentType = false;
			        formData.processData = false;
			    }
			    
				ajax.sendFormData(URL.FLX_HOST_URL+"create/resource",{
					withCredentials : true,
					message : formData,
					callback : function(response){
						if(response.uri){
							callback.call(that,response.uri);
						}else{
							callback.call(that,undefined);
						}
					}
				});
				
				
        }.bind(this);
   
    }
    
    ReportIssueView.prototype = Object.create(CommonView.prototype);
    ReportIssueView.prototype.constructor = ReportIssueView;
    
    ReportIssueView.prototype.init = function init(){
        this.container  = this.el.querySelector('#reportContainer');
        this.imageList  = this.el.querySelector('#imageList');
        this.uploadError = this.el.querySelector('#uploadError');
        this.imageUploaded = this.el.querySelector('#imageUploaded');
    };
    
    ReportIssueView.prototype.updateHeader = function (id){
    	this.reasonId = id;
    	var headerText,placeholderText;
    	switch(this.reasonId){
    	case '5' :
    		headerText = "Report";
    		placeholderText = "Please type your report here.";
    		break;
    	case '6' :
    		headerText = "Give us your valuable feedback";
    		placeholderText = "Please type your feedback here.";
    		break;
    	}
    	this.el.querySelector('.header').innerHTML = headerText;
    	this.el.querySelector('#reportIssueText').placeholder = placeholderText;
    };
    
    ReportIssueView.prototype.sendReport = function sendReport(){
    	
    	var reason = document.querySelector("#reportIssueText").value;
    	var reportParams = {
    			"reason":reason,
    			"reasonID":this.reasonId		
    	};
    	
    	function _sendReport(data){
    		var that = this;
    		if(data !== undefined){
    			reportParams["imageUrl"] = data;
    		}
        	for(var i in this.reportParams){
        		reportParams[i] = this.reportParams[i];
        	}
        	
        	var formData = new FormData();
        	
        	for(var i in reportParams){
        		 formData.append(i, reportParams[i]);
        	}
    		
    		ajax.sendFormData(URL.FLX_HOST_URL+"create/abusereport",{
    			withCredentials : true,
    			message : formData,
    			callback : function(response){
        			that.closeReportIssue();
        			that.eventHandler.emit('showMessage',{'message' : that.messages[that.reasonId]});
        		}
    		});
    	}
    	if(document.querySelector('input[type=file]').files[0])
    	this.uploadImage(_sendReport);
    	else{
    		_sendReport.call(this,undefined);
    	}
	};
    
    
    return ReportIssueView;
    
});;define('RweEditView',['CommonView','ajax','Draggable','Resizable','FileDropUpload','utility','HostURLs'],function(CommonView,ajax,Draggable,Resizable,FileDropUpload,utility,HostURLs){
    
    function RweEditView(data,userData){
    	
    	
    	var editview = this;
        this.questionNo = 0;
        this.isOpened = false;
        var draggable,resizable,noOfWordsInDescription;
        this.draggable =null,this.resizable = null ;
        this.currentColor = "090e16";
        this.backgroundTranslate = {
        		X : 0,
        		Y : 0
        };
        this.rweData = {};
        var eids = [];
        
        for(var i=0,l=data.concepts.length; i<l; i+=1){
        	eids.push(data.concepts[i].encodedID);
        }
        this.titleMinLength = 1;
        this.descriptionMinLength = 10;
        this.imageUploaded = false;
        this.titleDone = false;
        this.descriptionDone = false;
        this.allDone = false;
        this.popUpTextContent = "",
        this.createRWEParams = {
        		"simID" : data.artifactID,
        		"ownerID" : userData&&userData.id ? userData.id :443556,  //default userId is added ...(remove if its not required)
        		"eids" : eids
        }
        this.warningMsg = {
        		1 : "Your page is incomplete. You must add Image, Title, Description.",
        		2 :	"You must add Image before Submitting.",
        		3 : "You must add Title with appropriate length before Submitting.",
        		4 : "You must add Description with appropriate length before Submitting.",
        		5 : "Image file not supported."
        }
        this.popUpMsg = {
        		1 : "This content will be contributed to this simulation as a new example.",
        		2 :	"The current changes will be updated to this example.",
        		3 : '<span style="color:red">We recommend minimum 10 words for description.</span><br><br>',
        }
        this.currentWarning =  this.warningMsg[1];
        this.currentPopUpMsg =  this.popUpMsg[1];
        var infoNotAvailable = 'Information not available.' ;
        
    	var template = 		'<div class="rwe-edit-main-container">'+
    							'<div class="rwe-edit-background"></div>'+
								'<div class="header-tools animated">'+
									'<div class="edit-tool-right backFromPreview hide"></div>'+
									'<div class="edit-tool-left center-tool previewMode hide">Preview Mode</div>'+
									'<div class="edit-tool-right close"></div>'+
									'<div class="edit-tool-right done inactive">Done</div>'+
									'<div class="edit-tool-right preview inactive">Preview</div>'+
									'<div class="edit-tool-right color">Background Color</div>'+
									'<div class="edit-tool-right changeImage hide">Change Image</div>'+
								'</div>'+
								'<div class="edit-content">'+
									'<div class="edit-image-box">'+
										'<div class="image-inst">Upload or Drag image here</div>'+
									'</div>'+
									'<div class="edit-info-box">'+
										'<textarea id="editTitle" rows="1" cols="50" type="text" maxlength="50" class="edit-text-box" placeholder="Title"></textarea>'+
										'<textarea id="editDescription" rows="7" cols="50" type="text" maxlength="300" class="edit-text-box" placeholder="Description"></textarea>'+
									'</div>'+
								'</div>'+
							'</div>'+
							/**Message before completing*/
							'<div class="warning-msg hide"></div>'+
							/**Message before submit*/
							'<div class="msg-overlay hide">'+
								'<div class="msg-box">'+
						 			'<div class="msg-Close"></div>'+
						 			'<div class="msg-infoContainer"></div>'+
						 			'<div class="button-container ">'+
							 			'<div  class="submit-button report-button">SUBMIT</div>'+
							 			'<div  class="cancel-button report-button">CANCEL</div>'+
						 			'</div>'+
						 		'</div>'+
							'</div>' + 
							/**color palette UI*/
							'<div class="color-palette-container hide">'+
								'<div class="preview-color">'+
								'</div>'+
								'<div class="cancel-color">Cancel</div>'+
								'<div class="done-color">Done</div>'+
							'</div>' +
							/**Preview UI*/
							'<div class="text-container hide">' + 
								'<div class="color-bg"></div>' +
								'<div class="text-bg"></div>' + 
								'<div class="text-content">' +
									'<div class="title">@@title@@</div>' + 
									'<div class="example-text">@@eleboratedText@@</div>' +
								'</div>' + 
							'</div>';

        		 
        
        CommonView.apply(this , [{
            template:template,
            name :'AddNewExampleView',
            el: 'div',
            classes:['rwe-editView'],
            initialize: this.init
        }]);
        
        
        var scenecontainer = document.querySelector('#scenesController'),
        	dims = {
        		padWidth : Math.ceil(scenecontainer.clientWidth*0.25),
            	padHeight : Math.ceil(scenecontainer.clientHeight*0.24),
            	sliderWidth : Math.ceil(scenecontainer.clientWidth*0.02297)	
        }
        
        jscolor.install(this.el.querySelector('.preview-color'),this.el.querySelector('.color-palette-container'),this.currentColor,dims,function (){
        		editview.palletteColor = this.currentColor;
        		editview.el.querySelector('.rwe-edit-background').style.backgroundColor = '#' + editview.palletteColor;
    		}
    	);
        
        
        if(/iPad|iPhone|iPod/.test(navigator.userAgent) && !window.MSStream){
			this.events = {
				'touchstart .color':'chooseColor',
				'touchstart .done-color':'setBackgroundColor',
				'touchstart .cancel-color':'cancelColor',
				'touchstart .done':'doneEditing',
				'touchstart .close':'closeaddNewExample',
				'touchstart .preview':'previewRWE',
				'touchstart .backFromPreview':'closePreview', 
				'keyup #editTitle':'checkForComment',
				'keyup #editDescription':'checkForComment',
				'touchstart .submit-button':'doneSave',
				'touchstart .cancel-button':'cancelSave',
				'touchstart .msg-Close':'cancelSave'
	        };
    	}else{
	        this.events = {
        		'click .color':'chooseColor',
				'click .done-color':'setBackgroundColor',
				'click .cancel-color':'cancelColor',
				'click .done':'doneEditing',
				'click .close':'closeaddNewExample',
				'click .preview':'previewRWE',
				'click .backFromPreview':'closePreview', 
				'keyup #editTitle':'checkForComment',
				'keyup #editDescription':'checkForComment',
				'click .submit-button':'doneSave',
				'click .cancel-button':'cancelSave',
				'click .msg-Close':'cancelSave'
	        };
    	};
        
        this.chooseColor = function(){
        	this.el.querySelector('.color-palette-container').classList.remove('hide');
        }.bind(this);
        
        this.cancelColor = function(){
        	this.el.querySelector('.rwe-edit-background').style.backgroundColor = '#' + this.currentColor;
        	this.closeColorPalette();
        }.bind(this);
        
        this.closeColorPalette = function(){
        	this.el.querySelector('.color-palette-container').classList.add('hide');
        }.bind(this);
        
        this.setBackgroundColor = function(){
        	this.currentColor = this.palletteColor;
        	this.el.querySelector('.rwe-edit-background').style.backgroundColor = '#' + this.currentColor;
        	this.closeColorPalette();
        }.bind(this);
        
        this.stopPropagation = function stopPropagation(e){
        	e.stopPropagation();
        };
        
        this.checkForComment = function(e){
        	var title = this.el.querySelector('#editTitle'),
        	description = this.el.querySelector('#editDescription');
        	title = title.value.replace(/^\s+|\s+$/g,'');
        	description = description.value.replace(/^\s+|\s+$/g,'');
        	
        	//Checking for minimum words require in Title and Description
        	var noOfWordsInTitle = utility.countWords(title);
        	 noOfWordsInDescription = utility.countWords(description);
        	
        	this.titleDone = noOfWordsInTitle>=this.titleMinLength?true:false;
        	this.descriptionDone = noOfWordsInDescription>=1?true:false;
        
        
        	
        	//setting current Warning message
        	this.checkForDone();
        }.bind(this);
        
        
        	//Warning message to be displayed  
        this.checkForDone = function(){

			        if(this.imageUploaded || this.titleDone || this.descriptionDone){
			        		this.allDone = false;
			            	if(this.imageUploaded){
			            		//Image has been uploaded
			            		this.el.querySelector('.preview').classList.remove('inactive');
			            		if(this.titleDone){
			            			//Image and Title have been added properly
			            			if(this.descriptionDone){
			            				//Image ,Title and Description have been added properly
			            				this.allDone = true;
			            				this.activatingHeaderTools();
			            			}else{
			            				//Description is not added properly
			            				this.currentWarning =  this.warningMsg[4];
			            		
			            			}
			            		}else{
			            			//Title is not added properly
			            			this.currentWarning =  this.warningMsg[3];
			            	
			            		}
			            	}else{
			            		//Image is not uploaded properly
			            		this.currentWarning =  this.warningMsg[2];
			            
			            	}
			        	}else{
			        		//Nothing(Image,Title,Description) is added 
			        		this.currentWarning =  this.warningMsg[1];
			
			        	}
			  	  	
			        
			    	if(noOfWordsInDescription<this.descriptionMinLength){
		        		this.popUpTextContent = this.popUpMsg[3] + this.currentPopUpMsg;
		        	}else{
		        		this.popUpTextContent =  this.currentPopUpMsg;
		        	}
			        
			        
					        if(this.allDone)
					        	this.activatingHeaderTools();
					        else
					        	 this.inactivatingHeaderTools();
        
        }
       
      //Uploading error warning
        this.uploadingError = function(){
        	this.currentWarning = this.warningMsg[5];
        	this.showWarning();
        }
        //inactive header tool
        this.inactivatingHeaderTools = function(){
        	this.el.querySelector('.done').classList.add('inactive');
    		
        }
        //active header tool
        this.activatingHeaderTools = function(){
        	this.el.querySelector('.done').classList.remove('inactive');
        }
        
        //creating Preview for RWE 
        this.previewRWE = function(){
        	if(this.imageUploaded){
        		_updateRweData.call(this);
        			this.previewSetting();
            	_renderRWEFull.call(this,{
            		imageUrl : this.imageSrc,
            		title : this.title.value.replace(/</g,"&lt;").replace(/>/g,"&gt;"),
            		content : this.description.value,
            		rweData : this.rweData
            	});
        	} else{
        		 this.showWarning();
        	}

        }.bind(this);
        
        
        function _renderRWEFull(options){
        	var backgroundEl = this.el.querySelector('.text-bg');
        	this.el.querySelector('.text-container').classList.remove('hide');
        	backgroundEl.style.backgroundImage = 'url(' + options.imageUrl + ')';
        	this.el.querySelector('.title').innerHTML = options.title;
        	this.el.querySelector('.example-text').innerHTML = options.content;
        	
        	if(options.rweData&&(!utility.isEmpty(options.rweData))){
        		backgroundEl.style.left = parseFloat(options.rweData.left) + (1/this.el.clientWidth) + '%';
            	backgroundEl.style.top = parseFloat(options.rweData.top) + (1/this.el.clientHeight) + '%';
            	backgroundEl.style.width = parseFloat(options.rweData.width) + '%';
            	backgroundEl.style.height = parseFloat(options.rweData.height) + '%';
            	this.el.querySelector('.color-bg').style.backgroundColor = options.rweData.color;
        	}
        }
      
        //closing Preview Mode
        this.closePreview = function(){
        	this.el.querySelector('.text-container').classList.add('hide');
        	 this.backFromPreviewSetting();
        }.bind(this);
      
        //closing Editor Screen 
        this.closeaddNewExample = function(e){
	        if(e)
	         e.stopPropagation();
	       
	        	this.initialSettingsOfVariablesAndScreen();
	        	this.eventHandler.emit('hideAddNewExample');
	         
        }.bind(this);
      
        //initial settings of Variables and Screen
        this.initialSettingsOfVariablesAndScreen = function(){
        	this.imageUploaded = false;
 	        this.titleDone = false;
 	        this.descriptionDone = false;
 	        this.allDone = false;
 	        this.currentWarning =  this.warningMsg[1];
 	        this.currentPopUpMsg =  this.popUpMsg[1];
 	        this.currentColor = "090e16";
 	        jscolor.updatePickerColor(this.currentColor);
 	        this.imageSrc = "";
	        this.file = undefined;
	        this.title.value = "";
	        this.description.value = "";
	        this.isImageChanged = false;
	        this.isUpdating = false;
	        this.el.querySelector('.edit-image-box img').src = "";
	        this.el.querySelector('.rwe-edit-background').style.backgroundColor = '#' + this.currentColor;
	        this.el.querySelector('.preview-color').style.backgroundColor = '#' + this.currentColor;
        	this.el.querySelector('.edit-image-box .upload-btn').classList.remove('hide');
        	this.el.querySelector('.edit-image-box .input-file').classList.remove('hide');
        	this.backgroundTranslate = {
            		X : 0,
            		Y : 0
            };
        	this.rweData = {};
     		this.imageinst.classList.remove('hide');
     		this.changeImage.classList.add('hide');
     		this.warning.classList.add('hide');
     		this.closeColorPalette();
     		this.inactivatingHeaderTools();
     		this.el.querySelector('.preview').classList.add('inactive');
     		if(this.draggable){
     			this.draggable.removeDraggable();
     			this.draggable = null;
     		}
     		if(this.resizable){
     			this.resizable.removeResizable();
     			this.resizable = null;
     		}
     		if(this.fileDropUpload){
     			this.fileDropUpload.resetFile();
     		}
        }
     
        //onClick of Done 
        this.doneEditing = function(e){
        	 e.stopPropagation();
        	 this.checkForDone();
        	if(this.allDone){
        		 this.showPopUp();
        	}else{
        		 this.showWarning();
        	}
        }.bind(this);
       
        
        //showing Current Pop-up Message 
        this.showPopUp = function(){
        	this.popUpText.innerHTML = this.popUpTextContent;
        	this.msgOverlay.classList.remove('hide');
        }
        
        
       //showing Current Warning Message 
      this.showWarning = function(){
    		this.warning.textContent = this.currentWarning;
    		if(this.warning.classList.contains('hide')){
    			
    			this.warning.classList.remove('hide');
        		setTimeout(function(){this.warning.classList.add('hide');}.bind(this),5000);
    		}
      }
        //onClick of Submit  
       this.doneSave = function(e){
    		 e.stopPropagation();
           	 this.msgOverlay.classList.add('hide');
           	 if(this.isUpdating){
           		this.updateRWE(); 
           	 }else{
           		this.createRWE();
           	 }
       }.bind(this);
    
       //onClick of Cancel  
       this.cancelSave = function(e){
      	 	e.stopPropagation();
      	 	this.msgOverlay.classList.add('hide');
      }.bind(this);
      
      
      
      //Uploading image to server location
      this.uploadImage = function(callback,options,task){
	    	  var file    = this.file,
	    	      reader  = new FileReader(),
	    	      timeStamp = new Date().getTime(),
	    	      formData ;
	    	  var  that = this;
	    	  
			    if (window.FormData !== undefined && file !== undefined) {
			     
			        formData = new FormData();
			        var postConfig = {
			        	resourceType: "image",
			            resourceName: file.name,
			            resourceDesc: "",
			            isAttachment: false,
			            isPublic: false
			        };
			        
			        formData.append("resourcePath", file, timeStamp + "_" + file.name);
			        for (var i in postConfig) {
			            if (postConfig.hasOwnProperty(i)) {
			                formData.append(i, postConfig[i]);
			            }
			        }
			        formData.contentType = false;
			        formData.processData = false;
			    }
			    
				ajax.sendFormData(URL.FLX_HOST_URL+"create/resource",{
					withCredentials : true,
					message : formData,
					callback : function(response){
						if(response.satelliteUrl){
							callback.call(that,response.satelliteUrl,options,task);
						}else{
							callback.call(that,undefined,options,task);
						}
					}
				});
				
				
	    }.bind(this);
	   
	    //Preview Mode Screen Setting
	    this.previewSetting = function(){
	        this.headerTools.classList.add('translateUp');
	        setTimeout(function(){ 
	        	this.colorTool.classList.add('hide');
	 	        this.changeImage.classList.add('hide');
	 	        this.backFromPreviewTool.classList.remove('hide');
	 	        this.previewTool.classList.add('hide');
	 	        this.doneTool.classList.add('hide');
	 	        this.closeTool.classList.add('hide');
	 	        this.previewModeTitle.classList.remove('hide');
	 	       
	        	this.headerTools.classList.remove('translateUp');}.bind(this),500);
	    }
	    
	    //Back to Editor Screen from Preview Mode
	    this.backFromPreviewSetting = function(){
	        this.headerTools.classList.add('translateUp');
	        setTimeout(function(){
	        	 this.colorTool.classList.remove('hide');
	  	        if(this.imageUploaded)
	  	        this.changeImage.classList.remove('hide');
	  	        this.backFromPreviewTool.classList.add('hide');
	  	        this.previewTool.classList.remove('hide');
	  	        this.doneTool.classList.remove('hide');
	  	        this.closeTool.classList.remove('hide');
	  	     	 this.previewModeTitle.classList.add('hide');
	        	this.headerTools.classList.remove('translateUp');}.bind(this),500);
	    }
    }
    
    RweEditView.prototype = Object.create(CommonView.prototype);
    RweEditView.prototype.constructor = RweEditView;
    
    RweEditView.prototype.init = function init(){
    	this.title = this.el.querySelector("#editTitle");
	    this.description = this.el.querySelector("#editDescription");
	    this.imageinst = this.el.querySelector('.image-inst');
	    
        this.draggableEl =  this.el.querySelector('.edit-image-box');
        this.resizableEl = this.draggableEl;
        this.warning = this.el.querySelector('.warning-msg');
        this.msgOverlay = this.el.querySelector('.msg-overlay');
        this.popUpText = this.el.querySelector('.msg-infoContainer');
        //tools
        this.headerTools = this.el.querySelector('.header-tools');
        this.colorTool = this.el.querySelector('.color');
        this.changeImage = this.el.querySelector('.changeImage');
        this.backFromPreviewTool = this.el.querySelector('.backFromPreview');
        this.previewModeTitle = this.el.querySelector('.previewMode');        
        this.previewTool = this.el.querySelector('.preview');
        this.doneTool = this.el.querySelector('.done');
        this.closeTool = this.el.querySelector('.close');
        this.imageSrc = "";
        var that = this;
        //FileDropUpload 
        this.fileDropUpload = new FileDropUpload(this.draggableEl,{fileDraggable:true,endCallback:function(file){
	        	that.imageUploaded = true;
	        	that.checkForDone();
	        	that.bindDraggablity();
	        	that.imageSrc = this.getFile();
	        	that.file = file;
        	},
        	acceptedTypes:{
        		'image/png' : true, 
    			'image/jpeg' : true,
    			'image/jpg' : true
        	},
            error:function(){
            	this.uploadingError();
            }.bind(this)});

        
        //Change Image 
        this.previewElement = this.el.querySelector('.edit-image-box img');
        
        this.changeImageUpload = new FileDropUpload(this.changeImage,{previewElement:this.previewElement ,fileDraggable:false,endCallback:function(file){
        	that.file = file;
        	that.imageSrc = this.getFile();
        	that.isImageChanged = true;
        },
        error:function(){
        	this.uploadingError();
        }.bind(this)});

    };
    
    RweEditView.prototype.createRWE = function createRWE(){
   		
    	var title = this.title.value;
    		content = this.description.value;
    		
    	_updateRweData.call(this);	
    		
    	var createRWEParams = {
    			"title": title,
    			"content": content,
    			"level": "at grade",
    			"rweData": JSON.stringify(this.rweData)
    	};
    	if(this.allDone){
    		startSendAnim("sending");
    		this.uploadImage(_createRWE,createRWEParams,"create");
    	}
    	else{
    		return;
    	}
	};
	
    RweEditView.prototype.updateRWE = function updateRWE(){
  		
    	var title = this.title.value;
    		content = this.description.value;
    		
    	_updateRweData.call(this);	
    		
    	var createRWEParams = {
    			"id":this.currentExampleData._id,
    			"title": title,
    			"content": content,
    			"level": "at grade",
    			"rweData": JSON.stringify(this.rweData)
    	};
    	if(this.isImageChanged){
    		startSendAnim("sending");
    		this.uploadImage(_createRWE,createRWEParams,"update");
    	}
    	else{
    		startSendAnim("sending");
    		_createRWE.call(this,this.imageSrc,createRWEParams,"update");
    	}
	};
    RweEditView.prototype.bindDraggablity= function(){
    	if(this.draggable==null){
    		var that = this;
    		this.el.querySelector('.edit-image-box .upload-btn').classList.add('hide');
    		this.el.querySelector('.edit-image-box .input-file').classList.add('hide');
    		this.el.querySelector('.image-inst').classList.add('hide');
    		document.querySelector('.changeImage').classList.remove('hide');
    	     //draggable 
            this.draggable = new Draggable({
           	el:this.draggableEl,
           	restrict:true,
           	moveCallBack:function(data){
           		this.backgroundTranslate.X = data.translateX;
           		this.backgroundTranslate.Y = data.translateY;
           	}.bind(this)
           });
           //Resizable 
            this.resizable = new Resizable({
           	container:this.resizableEl,
           	direction:{1:true,2:true,3:true,4:true,5:true,6:true,7:true,8:true},
           	resizeCallBack:function(data){

           	}
           });
    	}
    }
    RweEditView.prototype.update = function(currentExampleData){
    	//update Image
    	this.imageSrc = currentExampleData.imageUrl;
    	this.previewElement.src =this.imageSrc;
    	this.imageUploaded = true;
    	
    	//update Data
    	this.currentExampleData = currentExampleData;
    	this.isImageChanged = false;
    	this.isUpdating = true;
    	//update Title
    	this.title.value = currentExampleData.title;
    	this.titleDone= true;
    	
    	//update Description
    	this.description.value = currentExampleData.content;
    	this.descriptionDone= true;
    
    	jscolor.updatePickerColor(currentExampleData.rweData.color);
    	if(currentExampleData.rweData){
    		//update Color
    		this.currentColor = currentExampleData.rweData.color.split(/#/g)[1];
    		this.el.querySelector('.rwe-edit-background').style.backgroundColor = currentExampleData.rweData.color;
        	//update Height
    		this.draggableEl.style.height = (currentExampleData.rweData.height*this.el.clientHeight/100) +"px";
        	
        	//update Width
    		this.draggableEl.style.width =  (currentExampleData.rweData.width*this.el.clientWidth/100) +"px";
        	
        	//update Top
    		this.draggableEl.style.top =  (currentExampleData.rweData.top*this.el.clientHeight/100) +"px";
        	
        	//update Left
    		this.draggableEl.style.left = (currentExampleData.rweData.left*this.el.clientWidth/100) +"px";
    	}
    
    	//update PopUp msg
    	this.currentPopUpMsg =  this.popUpMsg[2];
    	
    	//update Warning Message
    	this.checkForDone();
    	
    	
    	
    	//Adding Draggability and Resizable
    	this.bindDraggablity();
   
    }
    
    var _postConfirmMessages = {
    		"create" : "New real world example created successfully.",
    		"update" : "Real world example updated successfully"
    };
    
	function _createRWE(data,createRWEParams,task){
		var that = this;
		if(data !== undefined){
			createRWEParams["imageUrl"] = data;
		}
    	for(var i in this.createRWEParams){
    		createRWEParams[i] = this.createRWEParams[i];
    	}
    	
    	var formData = new FormData();
    	
    	for(var i in createRWEParams){
    		 formData.append(i, createRWEParams[i]);
    	}
		
		ajax.sendFormData(URL.FLX_HOST_URL+task+"/rwe",{
			withCredentials : true,
			message : formData,
			callback : function(response){
				startSendAnim("sent");
    			that.closeaddNewExample();
    			that.eventHandler.emit('refreshCardsView',{response : response, task : task});
    			that.eventHandler.emit('showMessage',{ message : _postConfirmMessages[task]});
    		}
		});
	}
    function _updateRweData(){
    	var background = this.el.querySelector('.edit-image-box'),
    		editArea = this.el.querySelector('.edit-content'),
    		backgroundLeft = (background.offsetLeft +  this.backgroundTranslate.X)*100/this.el.clientWidth,
    		backgroundTop = (background.offsetTop +  this.backgroundTranslate.Y)*100/this.el.clientHeight,
    		backgroundWidth = background.clientWidth*100/this.el.clientWidth;
    		backgroundHeight = background.clientHeight*100/this.el.clientHeight;
    	this.rweData = {
    			"left" : backgroundLeft.toFixed(3),
        		"top" : backgroundTop.toFixed(3),
        		"width" : backgroundWidth.toFixed(3),
        		"height" : backgroundHeight.toFixed(3),
        		"color" : "#" + this.currentColor
    	};
    }
    
    // This function creates an overlay and shows sending progess/animation
    function startSendAnim(type){
    	var progress = document.querySelector("#inProgressScreen2");
    	
    	switch (type){ 	
    	case "sending" : progress.classList.add('top');
	    				 progress.classList.remove('hide');
    				     break;
    	case "sent"   :  progress.classList.remove('top');
						 progress.classList.add('hide');
    					 break;
    	}

    }
    
   
	/**
	 * jscolor, JavaScript Color Picker
	 *
	 * @version 1.4.3
	 * @license GNU Lesser General Public License, http://www.gnu.org/copyleft/lesser.html
	 * @author  Jan Odvarko, http://odvarko.cz
	 * @created 2008-06-15
	 * @updated 2014-07-16
	 * @link    http://jscolor.com
	 */

    //var jscolor={dir:"../assets/images/",bindClass:"color",binding:true,preloading:false,install:function(e,t,n,r){this.target=e;this.parent=t;this.dimensions=n;this.immediateCallBack=r;this.init()},init:function(){jscolor.setDimensions();if(jscolor.binding){jscolor.bind()}if(jscolor.preloading){jscolor.preload()}},setDimensions:function(){jscolor.images={pad:[jscolor.dimensions.padWidth,jscolor.dimensions.padHeight],sld:[jscolor.dimensions.sliderWidth,jscolor.dimensions.padHeight],cross:[15,15],arrow:[7,11]}},getDir:function(){if(!jscolor.dir){var e=jscolor.detectDir();jscolor.dir=e!==false?e:"jscolor/"}return jscolor.dir},detectDir:function(){var e=location.href;var t=document.getElementsByTagName("base");for(var n=0;n<t.length;n+=1){if(t[n].href){e=t[n].href}}var t=document.getElementsByTagName("script");for(var n=0;n<t.length;n+=1){if(t[n].src&&/(^|\/)jscolor\.js([?#].*)?$/i.test(t[n].src)){var r=new jscolor.URI(t[n].src);var i=r.toAbsolute(e);i.path=i.path.replace(/[^\/]+$/,"");i.query=null;i.fragment=null;return i.toString()}}return false},bind:function(){var e=new RegExp("(^|\\s)("+jscolor.bindClass+")(\\s*(\\{[^}]*\\})|\\s|$)","i");new jscolor.color(this.target,this.parent,{},this.immediateCallBack)},preload:function(){for(var e in jscolor.imgRequire){if(jscolor.imgRequire.hasOwnProperty(e)){jscolor.loadImage(e)}}},imgRequire:{},imgLoaded:{},requireImage:function(e){jscolor.imgRequire[e]=true},loadImage:function(e){if(!jscolor.imgLoaded[e]){jscolor.imgLoaded[e]=new Image;jscolor.imgLoaded[e].src=jscolor.getDir()+e}},fetchElement:function(e){return typeof e==="string"?document.getElementById(e):e},addEvent:function(e,t,n){if(e.addEventListener){e.addEventListener(t,n,false)}else if(e.attachEvent){e.attachEvent("on"+t,n)}},fireEvent:function(e,t){if(!e){return}if(document.createEvent){var n=document.createEvent("HTMLEvents");n.initEvent(t,true,true);e.dispatchEvent(n)}else if(document.createEventObject){var n=document.createEventObject();e.fireEvent("on"+t,n)}else if(e["on"+t]){e["on"+t]()}},getElementPos:function(e){var t=e,n=e;var r=0,i=0;if(t.offsetParent){do{r+=t.offsetLeft;i+=t.offsetTop}while(t=t.offsetParent)}while((n=n.parentNode)&&n.nodeName.toUpperCase()!=="BODY"){r-=n.scrollLeft;i-=n.scrollTop}return[r,i]},getElementSize:function(e){return[e.offsetWidth,e.offsetHeight]},getRelMousePos:function(e){var t=0,n=0;if(!e){e=window.event}if(typeof e.offsetX==="number"){t=e.offsetX;n=e.offsetY}else if(typeof e.layerX==="number"){t=e.layerX;n=e.layerY}return{x:t,y:n}},getViewPos:function(){if(typeof window.pageYOffset==="number"){return[window.pageXOffset,window.pageYOffset]}else if(document.body&&(document.body.scrollLeft||document.body.scrollTop)){return[document.body.scrollLeft,document.body.scrollTop]}else if(document.documentElement&&(document.documentElement.scrollLeft||document.documentElement.scrollTop)){return[document.documentElement.scrollLeft,document.documentElement.scrollTop]}else{return[0,0]}},getViewSize:function(){if(typeof window.innerWidth==="number"){return[window.innerWidth,window.innerHeight]}else if(document.body&&(document.body.clientWidth||document.body.clientHeight)){return[document.body.clientWidth,document.body.clientHeight]}else if(document.documentElement&&(document.documentElement.clientWidth||document.documentElement.clientHeight)){return[document.documentElement.clientWidth,document.documentElement.clientHeight]}else{return[0,0]}},URI:function(e){function t(e){var t="";while(e){if(e.substr(0,3)==="../"||e.substr(0,2)==="./"){e=e.replace(/^\.+/,"").substr(1)}else if(e.substr(0,3)==="/./"||e==="/."){e="/"+e.substr(3)}else if(e.substr(0,4)==="/../"||e==="/.."){e="/"+e.substr(4);t=t.replace(/\/?[^\/]*$/,"")}else if(e==="."||e===".."){e=""}else{var n=e.match(/^\/?[^\/]*/)[0];e=e.substr(n.length);t=t+n}}return t}this.scheme=null;this.authority=null;this.path="";this.query=null;this.fragment=null;this.parse=function(e){var t=e.match(/^(([A-Za-z][0-9A-Za-z+.-]*)(:))?((\/\/)([^\/?#]*))?([^?#]*)((\?)([^#]*))?((#)(.*))?/);this.scheme=t[3]?t[2]:null;this.authority=t[5]?t[6]:null;this.path=t[7];this.query=t[9]?t[10]:null;this.fragment=t[12]?t[13]:null;return this};this.toString=function(){var e="";if(this.scheme!==null){e=e+this.scheme+":"}if(this.authority!==null){e=e+"//"+this.authority}if(this.path!==null){e=e+this.path}if(this.query!==null){e=e+"?"+this.query}if(this.fragment!==null){e=e+"#"+this.fragment}return e};this.toAbsolute=function(e){var e=new jscolor.URI(e);var n=this;var r=new jscolor.URI;if(e.scheme===null){return false}if(n.scheme!==null&&n.scheme.toLowerCase()===e.scheme.toLowerCase()){n.scheme=null}if(n.scheme!==null){r.scheme=n.scheme;r.authority=n.authority;r.path=t(n.path);r.query=n.query}else{if(n.authority!==null){r.authority=n.authority;r.path=t(n.path);r.query=n.query}else{if(n.path===""){r.path=e.path;if(n.query!==null){r.query=n.query}else{r.query=e.query}}else{if(n.path.substr(0,1)==="/"){r.path=t(n.path)}else{if(e.authority!==null&&e.path===""){r.path="/"+n.path}else{r.path=e.path.replace(/[^\/]+$/,"")+n.path}r.path=t(r.path)}r.query=n.query}r.authority=e.authority}r.scheme=e.scheme}r.fragment=n.fragment;return r};if(e){this.parse(e)}},color:function(e,t,n,r){function s(e,t,n){var r=Math.min(Math.min(e,t),n);var i=Math.max(Math.max(e,t),n);var s=i-r;if(s===0){return[null,0,i]}var o=e===r?3+(n-t)/s:t===r?5+(e-n)/s:1+(t-e)/s;return[o===6?0:o,s/i,i]}function o(e,t,n){if(e===null){return[n,n,n]}var r=Math.floor(e);var i=r%2?e-r:1-(e-r);var s=n*(1-t);var o=n*(1-t*i);switch(r){case 6:case 0:return[n,o,s];case 1:return[o,n,s];case 2:return[s,n,o];case 3:return[s,o,n];case 4:return[o,s,n];case 5:return[n,s,o]}}function u(){delete jscolor.picker.owner;document.getElementsByTagName("body")[0].removeChild(jscolor.picker.boxB)}function a(t,n){function p(){var e=y.pickerInsetColor.split(/\s+/);var t=e.length<2?e[0]:e[1]+" "+e[0]+" "+e[0]+" "+e[1];o.btn.style.borderColor=t}if(!jscolor.picker){jscolor.picker={box:document.createElement("div"),boxB:document.createElement("div"),pad:document.createElement("div"),padB:document.createElement("div"),padM:document.createElement("div"),sld:document.createElement("div"),sldB:document.createElement("div"),sldM:document.createElement("div"),btn:document.createElement("div"),btnS:document.createElement("span"),btnT:document.createTextNode(y.pickerCloseText)};for(var r=0,i=4;r<jscolor.images.sld[1];r+=i){var s=document.createElement("div");s.style.height=i+"px";s.style.fontSize="1px";s.style.lineHeight="0";jscolor.picker.sld.appendChild(s)}jscolor.picker.sldB.appendChild(jscolor.picker.sld);jscolor.picker.box.appendChild(jscolor.picker.sldB);jscolor.picker.box.appendChild(jscolor.picker.sldM);jscolor.picker.padB.appendChild(jscolor.picker.pad);jscolor.picker.box.appendChild(jscolor.picker.padB);jscolor.picker.box.appendChild(jscolor.picker.padM);jscolor.picker.btnS.appendChild(jscolor.picker.btnT);jscolor.picker.btn.appendChild(jscolor.picker.btnS);jscolor.picker.box.appendChild(jscolor.picker.btn);jscolor.picker.boxB.appendChild(jscolor.picker.box)}var o=jscolor.picker;o.box.onmouseup=o.box.onmouseout=function(){e.focus()};o.box.onmousedown=function(){w=true};o.box.onmousemove=function(e){if(x||T){x&&v(e);T&&m(e);if(document.selection){document.selection.empty()}else if(window.getSelection){window.getSelection().removeAllRanges()}g()}};if("ontouchstart"in window){var u=function(e){var t={offsetX:e.touches[0].pageX-N.X,offsetY:e.touches[0].pageY-N.Y};if(x||T){x&&v(t);T&&m(t);g()}e.stopPropagation();e.preventDefault()};o.box.removeEventListener("touchmove",u,false);o.box.addEventListener("touchmove",u,false)}o.padM.onmouseup=o.padM.onmouseout=function(){if(x){x=false;jscolor.fireEvent(E,"change")}};o.padM.onmousedown=function(e){switch(b){case 0:if(y.hsv[2]===0){y.fromHSV(null,null,1)}break;case 1:if(y.hsv[1]===0){y.fromHSV(null,1,null)}break}T=false;x=true;v(e);g()};if("ontouchstart"in window){o.padM.addEventListener("touchstart",function(e){N={X:e.target.offsetParent.offsetLeft,Y:e.target.offsetParent.offsetTop};this.onmousedown({offsetX:e.touches[0].pageX-N.X,offsetY:e.touches[0].pageY-N.Y})})}o.sldM.onmouseup=o.sldM.onmouseout=function(){if(T){T=false;jscolor.fireEvent(E,"change")}};o.sldM.onmousedown=function(e){x=false;T=true;m(e);g()};if("ontouchstart"in window){o.sldM.addEventListener("touchstart",function(e){N={X:e.target.offsetParent.offsetLeft,Y:e.target.offsetParent.offsetTop};this.onmousedown({offsetX:e.touches[0].pageX-N.X,offsetY:e.touches[0].pageY-N.Y})})}var a=f(y);o.box.style.width=a[0]+"px";o.box.style.height=a[1]+"px";o.boxB.style.position="absolute";o.boxB.style.clear="both";o.boxB.style.left=t+"px";o.boxB.style.top=n+"px";o.boxB.style.zIndex=y.pickerZIndex;o.boxB.style.top="21%";o.boxB.style.left="6%";o.pad.style.width=jscolor.images.pad[0]+"px";o.pad.style.height=jscolor.images.pad[1]+"px";o.padB.style.position="absolute";o.padB.style.left=y.pickerFace+"px";o.padB.style.top=y.pickerFace+"px";o.padB.style.borderRadius="4px";o.padM.style.position="absolute";o.padM.style.left="0";o.padM.style.top="0";o.padM.style.width=y.pickerFace+2*y.pickerInset+jscolor.images.pad[0]+jscolor.images.arrow[0]+"px";o.padM.style.height=o.box.style.height;o.padB.style.borderRadius="4px";o.padM.style.cursor="pointer";o.sld.style.overflow="hidden";o.sld.style.width=jscolor.images.sld[0]+"px";o.sld.style.height=jscolor.images.sld[1]+"px";o.sldB.style.display=y.slider?"block":"none";o.sldB.style.position="absolute";o.sldB.style.right=y.pickerFace+"px";o.sldB.style.top=y.pickerFace+"px";o.padB.style.borderRadius="4px";o.sldM.style.display=y.slider?"block":"none";o.sldM.style.position="absolute";o.sldM.style.right="0";o.sldM.style.top="0";o.sldM.style.width=jscolor.images.sld[0]+jscolor.images.arrow[0]+y.pickerFace+2*y.pickerInset+"px";o.sldM.style.height=o.box.style.height;try{o.sldM.style.cursor="pointer"}catch(h){o.sldM.style.cursor="hand"}o.btn.style.display=y.pickerClosable?"block":"none";o.btn.style.position="absolute";o.btn.style.left=y.pickerFace+"px";o.btn.style.bottom=y.pickerFace+"px";o.btn.style.padding="0 15px";o.btn.style.height="18px";o.btn.style.border=y.pickerInset+"px solid";p();o.btn.style.color=y.pickerButtonColor;o.btn.style.font="12px sans-serif";o.btn.style.textAlign="center";try{o.btn.style.cursor="pointer"}catch(h){o.btn.style.cursor="hand"}o.btn.onmousedown=function(){y.hidePicker()};o.btnS.style.lineHeight=o.btn.style.height;switch(b){case 0:var d="hs.png";break;case 1:var d="hv.png";break}o.padM.classList.add("pick-hue");o.padM.style.backgroundRepeat="no-repeat";o.sldM.classList.add("pick-saturation");o.sldM.style.backgroundRepeat="no-repeat";o.pad.classList.add("hue-pad");o.pad.style.backgroundRepeat="no-repeat";o.pad.style.backgroundPosition="0 0";l();c();jscolor.picker.owner=y;y.parentElement.appendChild(o.boxB)}function f(e){var t=[2*e.pickerInset+2*e.pickerFace+jscolor.images.pad[0]+(e.slider?2*e.pickerInset+2*jscolor.images.arrow[0]+jscolor.images.sld[0]:0),e.pickerClosable?4*e.pickerInset+3*e.pickerFace+jscolor.images.pad[1]+e.pickerButtonHeight:2*e.pickerInset+2*e.pickerFace+jscolor.images.pad[1]];return t}function l(){switch(b){case 0:var e=1;break;case 1:var e=2;break}var t=Math.round(y.hsv[0]/6*(jscolor.images.pad[0]-1));var n=Math.round((1-y.hsv[e])*(jscolor.images.pad[1]-1));jscolor.picker.padM.style.backgroundPosition=y.pickerFace+y.pickerInset+t-Math.floor(jscolor.images.cross[0]/2)+"px "+(y.pickerFace+y.pickerInset+n-Math.floor(jscolor.images.cross[1]/2))+"px";var r=jscolor.picker.sld.childNodes;switch(b){case 0:var i=o(y.hsv[0],y.hsv[1],1);for(var s=0;s<r.length;s+=1){r[s].style.backgroundColor="rgb("+i[0]*(1-s/r.length)*100+"%,"+i[1]*(1-s/r.length)*100+"%,"+i[2]*(1-s/r.length)*100+"%)"}break;case 1:var i,u,a=[y.hsv[2],0,0];var s=Math.floor(y.hsv[0]);var f=s%2?y.hsv[0]-s:1-(y.hsv[0]-s);switch(s){case 6:case 0:i=[0,1,2];break;case 1:i=[1,0,2];break;case 2:i=[2,0,1];break;case 3:i=[2,1,0];break;case 4:i=[1,2,0];break;case 5:i=[0,2,1];break}for(var s=0;s<r.length;s+=1){u=1-1/(r.length-1)*s;a[1]=a[0]*(1-u*f);a[2]=a[0]*(1-u);r[s].style.backgroundColor="rgb("+a[i[0]]*100+"%,"+a[i[1]]*100+"%,"+a[i[2]]*100+"%)"}break}}function c(){switch(b){case 0:var e=2;break;case 1:var e=1;break}var t=Math.round((1-y.hsv[e])*(jscolor.images.sld[1]-1));jscolor.picker.sldM.style.backgroundPosition="0 "+( y.pickerFace+y.pickerInset+t-Math.floor(jscolor.images.arrow[1]/2))+"px"}function h(){return jscolor.picker&&jscolor.picker.owner===y}function p(){if(E===e){y.importColor()}if(y.pickerOnfocus){y.hidePicker()}}function d(){if(E!==e){y.importColor()}}function v(e){var t=jscolor.getRelMousePos(e);var n=t.x-y.pickerFace-y.pickerInset;var r=t.y-y.pickerFace-y.pickerInset;switch(b){case 0:y.fromHSV(n*(6/(jscolor.images.pad[0]-1)),1-r/(jscolor.images.pad[1]-1),null,A);break;case 1:y.fromHSV(n*(6/(jscolor.images.pad[0]-1)),null,1-r/(jscolor.images.pad[1]-1),A);break}}function m(e){var t=jscolor.getRelMousePos(e);var n=t.y-y.pickerFace-y.pickerInset;switch(b){case 0:y.fromHSV(null,null,1-n/(jscolor.images.sld[1]-1),L);break;case 1:y.fromHSV(null,1-n/(jscolor.images.sld[1]-1),null,L);break}}function g(){if(y.onImmediateChange){var e;if(typeof y.onImmediateChange==="string"){e=new Function(y.onImmediateChange)}else{e=y.onImmediateChange}e.call(y)}}this.required=true;this.adjust=true;this.hash=false;this.caps=true;this.slider=true;this.valueElement=e;this.styleElement=e;this.parentElement=t;this.onImmediateChange=null;this.hsv=[0,0,1];this.rgb=[1,1,1];this.minH=0;this.maxH=6;this.minS=0;this.maxS=1;this.minV=0;this.maxV=1;this.immediateCallBack=r;this.pickerOnfocus=true;this.pickerMode="HSV";this.pickerPosition="bottom";this.pickerSmartPosition=true;this.pickerButtonHeight=20;this.pickerClosable=false;this.pickerCloseText="Close";this.pickerButtonColor="ButtonText";this.pickerFace=10;this.pickerFaceColor="ThreeDFace";this.pickerBorder=1;this.pickerBorderColor="ThreeDHighlight ThreeDShadow ThreeDShadow ThreeDHighlight";this.pickerInset=1;this.pickerInsetColor="ThreeDShadow ThreeDHighlight ThreeDHighlight ThreeDShadow";this.pickerZIndex=1e4;for(var i in n){if(n.hasOwnProperty(i)){this[i]=n[i]}}this.hidePicker=function(){};this.showPicker=function(){if(!h()){var t=jscolor.getElementPos(e);var n=jscolor.getElementSize(e);var r=jscolor.getViewPos();var i=jscolor.getViewSize();var s=f(this);var o,u,l;switch(this.pickerPosition.toLowerCase()){case"left":o=1;u=0;l=-1;break;case"right":o=1;u=0;l=1;break;case"top":o=0;u=1;l=-1;break;default:o=0;u=1;l=1;break}var c=(n[u]+s[u])/2;if(!this.pickerSmartPosition){var p=[t[o],t[u]+n[u]-c+c*l]}else{var p=[-r[o]+t[o]+s[o]>i[o]?-r[o]+t[o]+n[o]/2>i[o]/2&&t[o]+n[o]-s[o]>=0?t[o]+n[o]-s[o]:t[o]:t[o],-r[u]+t[u]+n[u]+s[u]-c+c*l>i[u]?-r[u]+t[u]+n[u]/2>i[u]/2&&t[u]+n[u]-c-c*l>=0?t[u]+n[u]-c-c*l:t[u]+n[u]-c+c*l:t[u]+n[u]-c+c*l>=0?t[u]+n[u]-c+c*l:t[u]+n[u]-c-c*l]}a(p[o],p[u])}};this.importColor=function(){};this.exportColor=function(e){if(!(e&C)&&E){var t=this.toString();if(this.caps){t=t.toUpperCase()}if(this.hash){t="#"+t}E.value=t;this.currentColor=t;this.immediateCallBack.call(this)}if(!(e&k)&&S){S.style.backgroundImage="none";S.style.backgroundColor="#"+this.toString();S.style.color=.213*this.rgb[0]+.715*this.rgb[1]+.072*this.rgb[2]<.5?"#FFF":"#000"}if(!(e&L)&&h()){l()}if(!(e&A)&&h()){c()}};this.fromHSV=function(e,t,n,r){if(e!==null){e=Math.max(0,this.minH,Math.min(6,this.maxH,e))}if(t!==null){t=Math.max(0,this.minS,Math.min(1,this.maxS,t))}if(n!==null){n=Math.max(0,this.minV,Math.min(1,this.maxV,n))}this.rgb=o(e===null?this.hsv[0]:this.hsv[0]=e,t===null?this.hsv[1]:this.hsv[1]=t,n===null?this.hsv[2]:this.hsv[2]=n);this.exportColor(r)};this.fromRGB=function(e,t,n,r){if(e!==null){e=Math.max(0,Math.min(1,e))}if(t!==null){t=Math.max(0,Math.min(1,t))}if(n!==null){n=Math.max(0,Math.min(1,n))}var i=s(e===null?this.rgb[0]:e,t===null?this.rgb[1]:t,n===null?this.rgb[2]:n);if(i[0]!==null){this.hsv[0]=Math.max(0,this.minH,Math.min(6,this.maxH,i[0]))}if(i[2]!==0){this.hsv[1]=i[1]===null?null:Math.max(0,this.minS,Math.min(1,this.maxS,i[1]))}this.hsv[2]=i[2]===null?null:Math.max(0,this.minV,Math.min(1,this.maxV,i[2]));var u=o(this.hsv[0],this.hsv[1],this.hsv[2]);this.rgb[0]=u[0];this.rgb[1]=u[1];this.rgb[2]=u[2];this.exportColor(r)};this.fromString=function(e,t){var n=e.match(/^\W*([0-9A-F]{3}([0-9A-F]{3})?)\W*$/i);if(!n){return false}else{if(n[1].length===6){this.fromRGB(parseInt(n[1].substr(0,2),16)/255,parseInt(n[1].substr(2,2),16)/255,parseInt(n[1].substr(4,2),16)/255,t)}else{this.fromRGB(parseInt(n[1].charAt(0)+n[1].charAt(0),16)/255,parseInt(n[1].charAt(1)+n[1].charAt(1),16)/255,parseInt(n[1].charAt(2)+n[1].charAt(2),16)/255,t)}return true}};this.toString=function(){return(256|Math.round(255*this.rgb[0])).toString(16).substr(1)+(256|Math.round(255*this.rgb[1])).toString(16).substr(1)+(256|Math.round(255*this.rgb[2])).toString(16).substr(1)};var y=this;var b=this.pickerMode.toLowerCase()==="hvs"?1:0;var w=false;var E=jscolor.fetchElement(this.valueElement),S=jscolor.fetchElement(this.styleElement);var x=false,T=false,N={};var C=1<<0,k=1<<1,L=1<<2,A=1<<3;y.showPicker();jscolor.addEvent(e,"blur",function(){if(!w){window.setTimeout(function(){w||p();w=false},0)}else{w=false}});if(E){var O=function(){y.fromString(E.value,C);g()};jscolor.addEvent(E,"keyup",O);jscolor.addEvent(E,"input",O);jscolor.addEvent(E,"blur",d);E.setAttribute("autocomplete","off")}if(S){S.jscStyle={backgroundImage:S.style.backgroundImage,backgroundColor:S.style.backgroundColor,color:S.style.color}}switch(b){case 0:jscolor.requireImage("hs.png");break;case 1:jscolor.requireImage("hv.png");break}jscolor.requireImage("cross.gif");jscolor.requireImage("arrow.gif");this.importColor()}}
	var jscolor = {


			dir : '../assets/images/', // location of jscolor directory (leave empty to autodetect)
			bindClass : 'color', // class name
			binding : true, // automatic binding via <input class="...">
			preloading : false, // use image preloading?


			install : function(target,parent,color,dimensions,immediateCallBack) {
				this.target = target;
				this.parent = parent;
				this.initialColor = color;
				this.dimensions = dimensions;
				this.immediateCallBack = immediateCallBack;
				this.init();
				//jscolor.addEvent(window, 'load', jscolor.init);
			},


			init : function() {
				jscolor.setDimensions();
				if(jscolor.binding) {
					jscolor.bind();
				}
				if(jscolor.preloading) {
					jscolor.preload();
				}
			},

			setDimensions : function() {
				jscolor.images = {
						pad : [ jscolor.dimensions.padWidth, jscolor.dimensions.padHeight ],
						sld : [ jscolor.dimensions.sliderWidth, jscolor.dimensions.padHeight ],
						cross : [ 15, 15 ],
						arrow : [ 7, 11 ]
					};
			},
			
			getDir : function() {
				if(!jscolor.dir) {
					var detected = jscolor.detectDir();
					jscolor.dir = detected!==false ? detected : 'jscolor/';
				}
				return jscolor.dir;
			},


			detectDir : function() {
				var base = location.href;

				var e = document.getElementsByTagName('base');
				for(var i=0; i<e.length; i+=1) {
					if(e[i].href) { base = e[i].href; }
				}

				var e = document.getElementsByTagName('script');
				for(var i=0; i<e.length; i+=1) {
					if(e[i].src && /(^|\/)jscolor\.js([?#].*)?$/i.test(e[i].src)) {
						var src = new jscolor.URI(e[i].src);
						var srcAbs = src.toAbsolute(base);
						srcAbs.path = srcAbs.path.replace(/[^\/]+$/, ''); // remove filename
						srcAbs.query = null;
						srcAbs.fragment = null;
						return srcAbs.toString();
					}
				}
				return false;
			},


			bind : function() {
				var matchClass = new RegExp('(^|\\s)('+jscolor.bindClass+')(\\s*(\\{[^}]*\\})|\\s|$)', 'i');
				/*for(var i=0; i<e.length; i+=1) {
					var m;
					if(!e[i].color && e[i].className && (m = e[i].className.match(matchClass))) {
						var prop = {};
						if(m[4]) {
							try {
								prop = (new Function ('return (' + m[4] + ')'))();
							} catch(eInvalidProp) {}
						}
						e[i].color = new jscolor.color(e[i], prop);
					}
				}*/
				this.colorpicker = new jscolor.color(this.target,this.parent,this.initialColor,{},this.immediateCallBack);
			},
			
			updatePickerColor : function(hex){
				this.colorpicker.fromString(hex);
			},

			preload : function() {
				for(var fn in jscolor.imgRequire) {
					if(jscolor.imgRequire.hasOwnProperty(fn)) {
						jscolor.loadImage(fn);
					}
				}
			},


			/*images : {
				pad : [ jscolor.dimensions.padWidth, jscolor.dimensions.padHeight ],
				sld : [ jscolor.dimensions.sliderWidth, jscolor.dimensions.padHeight ],
				cross : [ 15, 15 ],
				arrow : [ 7, 11 ]
			},*/


			imgRequire : {},
			imgLoaded : {},


			requireImage : function(filename) {
				jscolor.imgRequire[filename] = true;
			},


			loadImage : function(filename) {
				if(!jscolor.imgLoaded[filename]) {
					jscolor.imgLoaded[filename] = new Image();
					jscolor.imgLoaded[filename].src = jscolor.getDir()+filename;
				}
			},


			fetchElement : function(mixed) {
				return typeof mixed === 'string' ? document.getElementById(mixed) : mixed;
			},


			addEvent : function(el, evnt, func) {
				if(el.addEventListener) {
					el.addEventListener(evnt, func, false);
				} else if(el.attachEvent) {
					el.attachEvent('on'+evnt, func);
				}
			},


			fireEvent : function(el, evnt) {
				if(!el) {
					return;
				}
				if(document.createEvent) {
					var ev = document.createEvent('HTMLEvents');
					ev.initEvent(evnt, true, true);
					el.dispatchEvent(ev);
				} else if(document.createEventObject) {
					var ev = document.createEventObject();
					el.fireEvent('on'+evnt, ev);
				} else if(el['on'+evnt]) { // alternatively use the traditional event model (IE5)
					el['on'+evnt]();
				}
			},


			getElementPos : function(e) {
				var e1=e, e2=e;
				var x=0, y=0;
				if(e1.offsetParent) {
					do {
						x += e1.offsetLeft;
						y += e1.offsetTop;
					} while(e1 = e1.offsetParent);
				}
				while((e2 = e2.parentNode) && e2.nodeName.toUpperCase() !== 'BODY') {
					x -= e2.scrollLeft;
					y -= e2.scrollTop;
				}
				return [x, y];
			},


			getElementSize : function(e) {
				return [e.offsetWidth, e.offsetHeight];
			},


			getRelMousePos : function(e) {
				var x = 0, y = 0;
				if (!e) { e = window.event; }
				if (typeof e.offsetX === 'number') {
					x = e.offsetX;
					y = e.offsetY;
				} else if (typeof e.layerX === 'number') {
					x = e.layerX;
					y = e.layerY;
				}
				return { x: x, y: y };
			},


			getViewPos : function() {
				if(typeof window.pageYOffset === 'number') {
					return [window.pageXOffset, window.pageYOffset];
				} else if(document.body && (document.body.scrollLeft || document.body.scrollTop)) {
					return [document.body.scrollLeft, document.body.scrollTop];
				} else if(document.documentElement && (document.documentElement.scrollLeft || document.documentElement.scrollTop)) {
					return [document.documentElement.scrollLeft, document.documentElement.scrollTop];
				} else {
					return [0, 0];
				}
			},


			getViewSize : function() {
				if(typeof window.innerWidth === 'number') {
					return [window.innerWidth, window.innerHeight];
				} else if(document.body && (document.body.clientWidth || document.body.clientHeight)) {
					return [document.body.clientWidth, document.body.clientHeight];
				} else if(document.documentElement && (document.documentElement.clientWidth || document.documentElement.clientHeight)) {
					return [document.documentElement.clientWidth, document.documentElement.clientHeight];
				} else {
					return [0, 0];
				}
			},


			URI : function(uri) { // See RFC3986

				this.scheme = null;
				this.authority = null;
				this.path = '';
				this.query = null;
				this.fragment = null;

				this.parse = function(uri) {
					var m = uri.match(/^(([A-Za-z][0-9A-Za-z+.-]*)(:))?((\/\/)([^\/?#]*))?([^?#]*)((\?)([^#]*))?((#)(.*))?/);
					this.scheme = m[3] ? m[2] : null;
					this.authority = m[5] ? m[6] : null;
					this.path = m[7];
					this.query = m[9] ? m[10] : null;
					this.fragment = m[12] ? m[13] : null;
					return this;
				};

				this.toString = function() {
					var result = '';
					if(this.scheme !== null) { result = result + this.scheme + ':'; }
					if(this.authority !== null) { result = result + '//' + this.authority; }
					if(this.path !== null) { result = result + this.path; }
					if(this.query !== null) { result = result + '?' + this.query; }
					if(this.fragment !== null) { result = result + '#' + this.fragment; }
					return result;
				};

				this.toAbsolute = function(base) {
					var base = new jscolor.URI(base);
					var r = this;
					var t = new jscolor.URI;

					if(base.scheme === null) { return false; }

					if(r.scheme !== null && r.scheme.toLowerCase() === base.scheme.toLowerCase()) {
						r.scheme = null;
					}

					if(r.scheme !== null) {
						t.scheme = r.scheme;
						t.authority = r.authority;
						t.path = removeDotSegments(r.path);
						t.query = r.query;
					} else {
						if(r.authority !== null) {
							t.authority = r.authority;
							t.path = removeDotSegments(r.path);
							t.query = r.query;
						} else {
							if(r.path === '') {
								t.path = base.path;
								if(r.query !== null) {
									t.query = r.query;
								} else {
									t.query = base.query;
								}
							} else {
								if(r.path.substr(0,1) === '/') {
									t.path = removeDotSegments(r.path);
								} else {
									if(base.authority !== null && base.path === '') {
										t.path = '/'+r.path;
									} else {
										t.path = base.path.replace(/[^\/]+$/,'')+r.path;
									}
									t.path = removeDotSegments(t.path);
								}
								t.query = r.query;
							}
							t.authority = base.authority;
						}
						t.scheme = base.scheme;
					}
					t.fragment = r.fragment;

					return t;
				};

				function removeDotSegments(path) {
					var out = '';
					while(path) {
						if(path.substr(0,3)==='../' || path.substr(0,2)==='./') {
							path = path.replace(/^\.+/,'').substr(1);
						} else if(path.substr(0,3)==='/./' || path==='/.') {
							path = '/'+path.substr(3);
						} else if(path.substr(0,4)==='/../' || path==='/..') {
							path = '/'+path.substr(4);
							out = out.replace(/\/?[^\/]*$/, '');
						} else if(path==='.' || path==='..') {
							path = '';
						} else {
							var rm = path.match(/^\/?[^\/]*/)[0];
							path = path.substr(rm.length);
							out = out + rm;
						}
					}
					return out;
				}

				if(uri) {
					this.parse(uri);
				}

			},


			//
			// Usage example:
			// var myColor = new jscolor.color(myInputElement)
			//

			color : function(target, parentElement, color, prop, callback) {


				this.required = true; // refuse empty values?
				this.adjust = true; // adjust value to uniform notation?
				this.hash = false; // prefix color with # symbol?
				this.caps = true; // uppercase?
				this.slider = true; // show the value/saturation slider?
				this.valueElement = target; // value holder
				this.styleElement = target; // where to reflect current color
				this.parentElement = parentElement;
				this.onImmediateChange = null; // onchange callback (can be either string or function)
				this.hsv = [0, 0, 1]; // read-only  0-6, 0-1, 0-1
				this.rgb = [1, 1, 1]; // read-only  0-1, 0-1, 0-1
				this.minH = 0; // read-only  0-6
				this.maxH = 6; // read-only  0-6
				this.minS = 0; // read-only  0-1
				this.maxS = 1; // read-only  0-1
				this.minV = 0; // read-only  0-1
				this.maxV = 1; // read-only  0-1
				this.immediateCallBack = callback;
				this.pickerOnfocus = true; // display picker on focus?
				this.pickerMode = 'HSV'; // HSV | HVS
				this.pickerPosition = 'bottom'; // left | right | top | bottom
				this.pickerSmartPosition = true; // automatically adjust picker position when necessary
				this.pickerButtonHeight = 20; // px
				this.pickerClosable = false;
				this.pickerCloseText = 'Close';
				this.pickerButtonColor = 'ButtonText'; // px
				this.pickerFace = 10; // px
				this.pickerFaceColor = 'ThreeDFace'; // CSS color
				this.pickerBorder = 1; // px
				this.pickerBorderColor = 'ThreeDHighlight ThreeDShadow ThreeDShadow ThreeDHighlight'; // CSS color
				this.pickerInset = 1; // px
				this.pickerInsetColor = 'ThreeDShadow ThreeDHighlight ThreeDHighlight ThreeDShadow'; // CSS color
				this.pickerZIndex = 10000;

				for(var p in prop) {
					if(prop.hasOwnProperty(p)) {
						this[p] = prop[p];
					}
				}


				this.hidePicker = function() {
					/*if(isPickerOwner()) {
						removePicker();
					}*/
				};


				this.showPicker = function() {
					if(!isPickerOwner()) {
						var tp = jscolor.getElementPos(target); // target pos
						var ts = jscolor.getElementSize(target); // target size
						var vp = jscolor.getViewPos(); // view pos
						var vs = jscolor.getViewSize(); // view size
						var ps = getPickerDims(this); // picker size
						var a, b, c;
						switch(this.pickerPosition.toLowerCase()) {
							case 'left': a=1; b=0; c=-1; break;
							case 'right':a=1; b=0; c=1; break;
							case 'top':  a=0; b=1; c=-1; break;
							default:     a=0; b=1; c=1; break;
						}
						var l = (ts[b]+ps[b])/2;

						// picker pos
						if (!this.pickerSmartPosition) {
							var pp = [
								tp[a],
								tp[b]+ts[b]-l+l*c
							];
						} else {
							var pp = [
								-vp[a]+tp[a]+ps[a] > vs[a] ?
									(-vp[a]+tp[a]+ts[a]/2 > vs[a]/2 && tp[a]+ts[a]-ps[a] >= 0 ? tp[a]+ts[a]-ps[a] : tp[a]) :
									tp[a],
								-vp[b]+tp[b]+ts[b]+ps[b]-l+l*c > vs[b] ?
									(-vp[b]+tp[b]+ts[b]/2 > vs[b]/2 && tp[b]+ts[b]-l-l*c >= 0 ? tp[b]+ts[b]-l-l*c : tp[b]+ts[b]-l+l*c) :
									(tp[b]+ts[b]-l+l*c >= 0 ? tp[b]+ts[b]-l+l*c : tp[b]+ts[b]-l-l*c)
							];
						}
						drawPicker(pp[a], pp[b]);
					}
				};


				this.importColor = function() {
					/*if(!valueElement) {
						this.exportColor();
					} else {
						if(!this.adjust) {
							if(!this.fromString(valueElement.value, leaveValue)) {
								styleElement.style.backgroundImage = styleElement.jscStyle.backgroundImage;
								styleElement.style.backgroundColor = styleElement.jscStyle.backgroundColor;
								styleElement.style.color = styleElement.jscStyle.color;
								this.exportColor(leaveValue | leaveStyle);
							}
						} else if(!this.required && /^\s*$/.test(valueElement.value)) {
							valueElement.value = '';
							styleElement.style.backgroundImage = styleElement.jscStyle.backgroundImage;
							styleElement.style.backgroundColor = styleElement.jscStyle.backgroundColor;
							styleElement.style.color = styleElement.jscStyle.color;
							this.exportColor(leaveValue | leaveStyle);

						} else if(this.fromString(valueElement.value)) {
							// OK
						} else {
							this.exportColor();
						}
					}*/
				};


				this.exportColor = function(flags) {
					if(!(flags & leaveValue) && valueElement) {
						var value = this.toString();
						if(this.caps) { value = value.toUpperCase(); }
						if(this.hash) { value = '#'+value; }
						valueElement.value = value;
						this.currentColor = value;
						this.immediateCallBack.call(this);
					}
					if(!(flags & leaveStyle) && styleElement) {
						styleElement.style.backgroundImage = "none";
						styleElement.style.backgroundColor =
							'#'+this.toString();
						styleElement.style.color =
							0.213 * this.rgb[0] +
							0.715 * this.rgb[1] +
							0.072 * this.rgb[2]
							< 0.5 ? '#FFF' : '#000';
					}
					if(!(flags & leavePad) && isPickerOwner()) {
						redrawPad();
					}
					if(!(flags & leaveSld) && isPickerOwner()) {
						redrawSld();
					}
				};


				this.fromHSV = function(h, s, v, flags) { // null = don't change
					if(h !== null) { h = Math.max(0.0, this.minH, Math.min(6.0, this.maxH, h)); }
					if(s !== null) { s = Math.max(0.0, this.minS, Math.min(1.0, this.maxS, s)); }
					if(v !== null) { v = Math.max(0.0, this.minV, Math.min(1.0, this.maxV, v)); }

					this.rgb = HSV_RGB(
						h===null ? this.hsv[0] : (this.hsv[0]=h),
						s===null ? this.hsv[1] : (this.hsv[1]=s),
						v===null ? this.hsv[2] : (this.hsv[2]=v)
					);

					this.exportColor(flags);
				};


				this.fromRGB = function(r, g, b, flags) { // null = don't change
					if(r !== null) { r = Math.max(0.0, Math.min(1.0, r)); }
					if(g !== null) { g = Math.max(0.0, Math.min(1.0, g)); }
					if(b !== null) { b = Math.max(0.0, Math.min(1.0, b)); }

					var hsv = RGB_HSV(
						r===null ? this.rgb[0] : r,
						g===null ? this.rgb[1] : g,
						b===null ? this.rgb[2] : b
					);
					if(hsv[0] !== null) {
						this.hsv[0] = Math.max(0.0, this.minH, Math.min(6.0, this.maxH, hsv[0]));
					}
					if(hsv[2] !== 0) {
						this.hsv[1] = hsv[1]===null ? null : Math.max(0.0, this.minS, Math.min(1.0, this.maxS, hsv[1]));
					}
					this.hsv[2] = hsv[2]===null ? null : Math.max(0.0, this.minV, Math.min(1.0, this.maxV, hsv[2]));

					// update RGB according to final HSV, as some values might be trimmed
					var rgb = HSV_RGB(this.hsv[0], this.hsv[1], this.hsv[2]);
					this.rgb[0] = rgb[0];
					this.rgb[1] = rgb[1];
					this.rgb[2] = rgb[2];

					this.exportColor(flags);
				};


				this.fromString = function(hex, flags) {
					var m = hex.match(/^\W*([0-9A-F]{3}([0-9A-F]{3})?)\W*$/i);
					if(!m) {
						return false;
					} else {
						if(m[1].length === 6) { // 6-char notation
							this.fromRGB(
								parseInt(m[1].substr(0,2),16) / 255,
								parseInt(m[1].substr(2,2),16) / 255,
								parseInt(m[1].substr(4,2),16) / 255,
								flags
							);
						} else { // 3-char notation
							this.fromRGB(
								parseInt(m[1].charAt(0)+m[1].charAt(0),16) / 255,
								parseInt(m[1].charAt(1)+m[1].charAt(1),16) / 255,
								parseInt(m[1].charAt(2)+m[1].charAt(2),16) / 255,
								flags
							);
						}
						return true;
					}
				};

				if(color){
					this.fromString(color);
				}
				
				this.toString = function() {
					return (
						(0x100 | Math.round(255*this.rgb[0])).toString(16).substr(1) +
						(0x100 | Math.round(255*this.rgb[1])).toString(16).substr(1) +
						(0x100 | Math.round(255*this.rgb[2])).toString(16).substr(1)
					);
				};


				function RGB_HSV(r, g, b) {
					var n = Math.min(Math.min(r,g),b);
					var v = Math.max(Math.max(r,g),b);
					var m = v - n;
					if(m === 0) { return [ null, 0, v ]; }
					var h = r===n ? 3+(b-g)/m : (g===n ? 5+(r-b)/m : 1+(g-r)/m);
					return [ h===6?0:h, m/v, v ];
				}


				function HSV_RGB(h, s, v) {
					if(h === null) { return [ v, v, v ]; }
					var i = Math.floor(h);
					var f = i%2 ? h-i : 1-(h-i);
					var m = v * (1 - s);
					var n = v * (1 - s*f);
					switch(i) {
						case 6:
						case 0: return [v,n,m];
						case 1: return [n,v,m];
						case 2: return [m,v,n];
						case 3: return [m,n,v];
						case 4: return [n,m,v];
						case 5: return [v,m,n];
					}
				}


				function removePicker() {
					delete jscolor.picker.owner;
					document.getElementsByTagName('body')[0].removeChild(jscolor.picker.boxB);
				}


				function drawPicker(x, y) {
					if(!jscolor.picker) {
						jscolor.picker = {
							box : document.createElement('div'),
							boxB : document.createElement('div'),
							pad : document.createElement('div'),
							padB : document.createElement('div'),
							padM : document.createElement('div'),
							sld : document.createElement('div'),
							sldB : document.createElement('div'),
							sldM : document.createElement('div'),
							btn : document.createElement('div'),
							btnS : document.createElement('span'),
							btnT : document.createTextNode(THIS.pickerCloseText)
						};
						for(var i=0,segSize=4; i<jscolor.images.sld[1]; i+=segSize) {
							var seg = document.createElement('div');
							seg.style.height = segSize+'px';
							seg.style.fontSize = '1px';
							seg.style.lineHeight = '0';
							jscolor.picker.sld.appendChild(seg);
						}
						jscolor.picker.sldB.appendChild(jscolor.picker.sld);
						jscolor.picker.box.appendChild(jscolor.picker.sldB);
						jscolor.picker.box.appendChild(jscolor.picker.sldM);
						jscolor.picker.padB.appendChild(jscolor.picker.pad);
						jscolor.picker.box.appendChild(jscolor.picker.padB);
						jscolor.picker.box.appendChild(jscolor.picker.padM);
						jscolor.picker.btnS.appendChild(jscolor.picker.btnT);
						jscolor.picker.btn.appendChild(jscolor.picker.btnS);
						jscolor.picker.box.appendChild(jscolor.picker.btn);
						jscolor.picker.boxB.appendChild(jscolor.picker.box);
					}

					var p = jscolor.picker;

					// controls interaction
					p.box.onmouseup =
					p.box.onmouseout = function() { target.focus(); };
					p.box.onmousedown = function() { abortBlur=true; };
					p.box.onmousemove = function(e) {
						if (holdPad || holdSld) {
							holdPad && setPad(e);
							holdSld && setSld(e);
							if (document.selection) {
								document.selection.empty();
							} else if (window.getSelection) {
								window.getSelection().removeAllRanges();
							}
							dispatchImmediateChange();
						}
					};
					if('ontouchstart' in window) { // if touch device
						var handle_touchmove = function(e) {
							var event={
								'offsetX': e.touches[0].pageX-touchOffset.X,
								'offsetY': e.touches[0].pageY-touchOffset.Y
							};
							if (holdPad || holdSld) {
								holdPad && setPad(event);
								holdSld && setSld(event);
								dispatchImmediateChange();
							}
							e.stopPropagation(); // prevent move "view" on broswer
							e.preventDefault(); // prevent Default - Android Fix (else android generated only 1-2 touchmove events)
						};
						p.box.removeEventListener('touchmove', handle_touchmove, false)
						p.box.addEventListener('touchmove', handle_touchmove, false)
					}
					p.padM.onmouseup =
					p.padM.onmouseout = function() { if(holdPad) { holdPad=false; jscolor.fireEvent(valueElement,'change'); } };
					p.padM.onmousedown = function(e) {
						// if the slider is at the bottom, move it up
						switch(modeID) {
							case 0: if (THIS.hsv[2] === 0) { THIS.fromHSV(null, null, 1.0); }; break;
							case 1: if (THIS.hsv[1] === 0) { THIS.fromHSV(null, 1.0, null); }; break;
						}
						holdSld=false;
						holdPad=true;
						setPad(e);
						dispatchImmediateChange();
					};
					if('ontouchstart' in window) {
						p.padM.addEventListener('touchstart', function(e) {
							touchOffset={
								'X': e.target.offsetParent.offsetLeft,
								'Y': e.target.offsetParent.offsetTop
							};
							this.onmousedown({
								'offsetX':e.touches[0].pageX-touchOffset.X,
								'offsetY':e.touches[0].pageY-touchOffset.Y
							});
						});
					}
					p.sldM.onmouseup =
					p.sldM.onmouseout = function() { if(holdSld) { holdSld=false; jscolor.fireEvent(valueElement,'change'); } };
					p.sldM.onmousedown = function(e) {
						holdPad=false;
						holdSld=true;
						setSld(e);
						dispatchImmediateChange();
					};
					if('ontouchstart' in window) {
						p.sldM.addEventListener('touchstart', function(e) {
							touchOffset={
								'X': e.target.offsetParent.offsetLeft,
								'Y': e.target.offsetParent.offsetTop
							};
							this.onmousedown({
								'offsetX':e.touches[0].pageX-touchOffset.X,
								'offsetY':e.touches[0].pageY-touchOffset.Y
							});
						});
					}

					// picker
					var dims = getPickerDims(THIS);
					p.box.style.width = dims[0] + 'px';
					p.box.style.height = dims[1] + 'px';

					// picker border
					p.boxB.style.position = 'absolute';
					p.boxB.style.clear = 'both';
					p.boxB.style.left = x+'px';
					p.boxB.style.top = y+'px';
					p.boxB.style.zIndex = THIS.pickerZIndex;
					p.boxB.style.top = '21%';
					p.boxB.style.left = '6%';

					// pad image
					p.pad.style.width = jscolor.images.pad[0]+'px';
					p.pad.style.height = jscolor.images.pad[1]+'px';

					// pad border
					p.padB.style.position = 'absolute';
					p.padB.style.left = THIS.pickerFace+'px';
					p.padB.style.top = THIS.pickerFace+'px';
					p.padB.style.borderRadius = '4px';
					/*p.padB.style.border = THIS.pickerInset+'px solid';
					p.padB.style.borderColor = THIS.pickerInsetColor;*/

					// pad mouse area
					p.padM.style.position = 'absolute';
					p.padM.style.left = '0';
					p.padM.style.top = '0';
					p.padM.style.width = THIS.pickerFace + 2*THIS.pickerInset + jscolor.images.pad[0] + jscolor.images.arrow[0] + 'px';
					p.padM.style.height = p.box.style.height;
					p.padB.style.borderRadius = '4px';
					p.padM.style.cursor = 'pointer';

					// slider image
					p.sld.style.overflow = 'hidden';
					p.sld.style.width = jscolor.images.sld[0]+'px';
					p.sld.style.height = jscolor.images.sld[1]+'px';

					// slider border
					p.sldB.style.display = THIS.slider ? 'block' : 'none';
					p.sldB.style.position = 'absolute';
					p.sldB.style.right = THIS.pickerFace+'px';
					p.sldB.style.top = THIS.pickerFace+'px';
					p.padB.style.borderRadius = '4px';
					/*p.sldB.style.border = THIS.pickerInset+'px solid';
					p.sldB.style.borderColor = THIS.pickerInsetColor;*/

					// slider mouse area
					p.sldM.style.display = THIS.slider ? 'block' : 'none';
					p.sldM.style.position = 'absolute';
					p.sldM.style.right = '0';
					p.sldM.style.top = '0';
					p.sldM.style.width = jscolor.images.sld[0] + jscolor.images.arrow[0] + THIS.pickerFace + 2*THIS.pickerInset + 'px';
					p.sldM.style.height = p.box.style.height;
					try {
						p.sldM.style.cursor = 'pointer';
					} catch(eOldIE) {
						p.sldM.style.cursor = 'hand';
					}

					// "close" button
					function setBtnBorder() {
						var insetColors = THIS.pickerInsetColor.split(/\s+/);
						var pickerOutsetColor = insetColors.length < 2 ? insetColors[0] : insetColors[1] + ' ' + insetColors[0] + ' ' + insetColors[0] + ' ' + insetColors[1];
						p.btn.style.borderColor = pickerOutsetColor;
					}
					p.btn.style.display = THIS.pickerClosable ? 'block' : 'none';
					p.btn.style.position = 'absolute';
					p.btn.style.left = THIS.pickerFace + 'px';
					p.btn.style.bottom = THIS.pickerFace + 'px';
					p.btn.style.padding = '0 15px';
					p.btn.style.height = '18px';
					p.btn.style.border = THIS.pickerInset + 'px solid';
					setBtnBorder();
					p.btn.style.color = THIS.pickerButtonColor;
					p.btn.style.font = '12px sans-serif';
					p.btn.style.textAlign = 'center';
					try {
						p.btn.style.cursor = 'pointer';
					} catch(eOldIE) {
						p.btn.style.cursor = 'hand';
					}
					p.btn.onmousedown = function () {
						THIS.hidePicker();
					};
					p.btnS.style.lineHeight = p.btn.style.height;

					// load images in optimal order
					switch(modeID) {
						case 0: var padImg = 'hs.png'; break;
						case 1: var padImg = 'hv.png'; break;
					}
					p.padM.classList.add('pick-hue');
					//p.padM.style.backgroundImage = "url('"+jscolor.getDir()+"cross.gif')";
					p.padM.style.backgroundRepeat = "no-repeat";
					p.sldM.classList.add('pick-saturation');
					//p.sldM.style.backgroundImage = "url('"+jscolor.getDir()+"arrow.gif')";
					p.sldM.style.backgroundRepeat = "no-repeat";
					p.pad.classList.add('hue-pad');
					//p.pad.style.backgroundImage = "url('"+jscolor.getDir()+padImg+"')";
					p.pad.style.backgroundRepeat = "no-repeat";
					p.pad.style.backgroundPosition = "0 0";

					// place pointers
					redrawPad();
					redrawSld();

					jscolor.picker.owner = THIS;
					THIS.parentElement.appendChild(p.boxB);
				}


				function getPickerDims(o) {
					var dims = [
						2*o.pickerInset + 2*o.pickerFace + jscolor.images.pad[0] +
							(o.slider ? 2*o.pickerInset + 2*jscolor.images.arrow[0] + jscolor.images.sld[0] : 0),
						o.pickerClosable ?
							4*o.pickerInset + 3*o.pickerFace + jscolor.images.pad[1] + o.pickerButtonHeight :
							2*o.pickerInset + 2*o.pickerFace + jscolor.images.pad[1]
					];
					return dims;
				}


				function redrawPad() {
					// redraw the pad pointer
					switch(modeID) {
						case 0: var yComponent = 1; break;
						case 1: var yComponent = 2; break;
					}
					var x = Math.round((THIS.hsv[0]/6) * (jscolor.images.pad[0]-1));
					var y = Math.round((1-THIS.hsv[yComponent]) * (jscolor.images.pad[1]-1));
					jscolor.picker.padM.style.backgroundPosition =
						(THIS.pickerFace+THIS.pickerInset+x - Math.floor(jscolor.images.cross[0]/2)) + 'px ' +
						(THIS.pickerFace+THIS.pickerInset+y - Math.floor(jscolor.images.cross[1]/2)) + 'px';

					// redraw the slider image
					var seg = jscolor.picker.sld.childNodes;

					switch(modeID) {
						case 0:
							var rgb = HSV_RGB(THIS.hsv[0], THIS.hsv[1], 1);
							for(var i=0; i<seg.length; i+=1) {
								seg[i].style.backgroundColor = 'rgb('+
									(rgb[0]*(1-i/seg.length)*100)+'%,'+
									(rgb[1]*(1-i/seg.length)*100)+'%,'+
									(rgb[2]*(1-i/seg.length)*100)+'%)';
							}
							break;
						case 1:
							var rgb, s, c = [ THIS.hsv[2], 0, 0 ];
							var i = Math.floor(THIS.hsv[0]);
							var f = i%2 ? THIS.hsv[0]-i : 1-(THIS.hsv[0]-i);
							switch(i) {
								case 6:
								case 0: rgb=[0,1,2]; break;
								case 1: rgb=[1,0,2]; break;
								case 2: rgb=[2,0,1]; break;
								case 3: rgb=[2,1,0]; break;
								case 4: rgb=[1,2,0]; break;
								case 5: rgb=[0,2,1]; break;
							}
							for(var i=0; i<seg.length; i+=1) {
								s = 1 - 1/(seg.length-1)*i;
								c[1] = c[0] * (1 - s*f);
								c[2] = c[0] * (1 - s);
								seg[i].style.backgroundColor = 'rgb('+
									(c[rgb[0]]*100)+'%,'+
									(c[rgb[1]]*100)+'%,'+
									(c[rgb[2]]*100)+'%)';
							}
							break;
					}
				}


				function redrawSld() {
					// redraw the slider pointer
					switch(modeID) {
						case 0: var yComponent = 2; break;
						case 1: var yComponent = 1; break;
					}
					var y = Math.round((1-THIS.hsv[yComponent]) * (jscolor.images.sld[1]-1));
					jscolor.picker.sldM.style.backgroundPosition =
						'0 ' + (THIS.pickerFace+THIS.pickerInset+y - Math.floor(jscolor.images.arrow[1]/2)) + 'px';
				}


				function isPickerOwner() {
					return jscolor.picker && jscolor.picker.owner === THIS;
				}


				function blurTarget() {
					if(valueElement === target) {
						THIS.importColor();
					}
					if(THIS.pickerOnfocus) {
						THIS.hidePicker();
					}
				}


				function blurValue() {
					if(valueElement !== target) {
						THIS.importColor();
					}
				}


				function setPad(e) {
					var mpos = jscolor.getRelMousePos(e);
					var x = mpos.x - THIS.pickerFace - THIS.pickerInset;
					var y = mpos.y - THIS.pickerFace - THIS.pickerInset;
					switch(modeID) {
						case 0: THIS.fromHSV(x*(6/(jscolor.images.pad[0]-1)), 1 - y/(jscolor.images.pad[1]-1), null, leaveSld); break;
						case 1: THIS.fromHSV(x*(6/(jscolor.images.pad[0]-1)), null, 1 - y/(jscolor.images.pad[1]-1), leaveSld); break;
					}
				}


				function setSld(e) {
					var mpos = jscolor.getRelMousePos(e);
					var y = mpos.y - THIS.pickerFace - THIS.pickerInset;
					switch(modeID) {
						case 0: THIS.fromHSV(null, null, 1 - y/(jscolor.images.sld[1]-1), leavePad); break;
						case 1: THIS.fromHSV(null, 1 - y/(jscolor.images.sld[1]-1), null, leavePad); break;
					}
				}


				function dispatchImmediateChange() {
					if (THIS.onImmediateChange) {
						var callback;
						if (typeof THIS.onImmediateChange === 'string') {
							callback = new Function (THIS.onImmediateChange);
						} else {
							callback = THIS.onImmediateChange;
						}
						callback.call(THIS);
					}
				}


				var THIS = this;
				var modeID = this.pickerMode.toLowerCase()==='hvs' ? 1 : 0;
				var abortBlur = false;
				var
					valueElement = jscolor.fetchElement(this.valueElement),
					styleElement = jscolor.fetchElement(this.styleElement);
				var
					holdPad = false,
					holdSld = false,
					touchOffset = {};
				var
					leaveValue = 1<<0,
					leaveStyle = 1<<1,
					leavePad = 1<<2,
					leaveSld = 1<<3;

				// target
				THIS.showPicker();
				/*jscolor.addEvent(target, 'focus', function() {
					if(THIS.pickerOnfocus) { THIS.showPicker(); }
				});*/
				jscolor.addEvent(target, 'blur', function() {
					if(!abortBlur) {
						window.setTimeout(function(){ abortBlur || blurTarget(); abortBlur=false; }, 0);
					} else {
						abortBlur = false;
					}
				});

				// valueElement
				if(valueElement) {
					var updateField = function() {
						THIS.fromString(valueElement.value, leaveValue);
						dispatchImmediateChange();
					};
					jscolor.addEvent(valueElement, 'keyup', updateField);
					jscolor.addEvent(valueElement, 'input', updateField);
					jscolor.addEvent(valueElement, 'blur', blurValue);
					valueElement.setAttribute('autocomplete', 'off');
				}

				// styleElement
				if(styleElement) {
					styleElement.jscStyle = {
						backgroundImage : styleElement.style.backgroundImage,
						backgroundColor : styleElement.style.backgroundColor,
						color : styleElement.style.color
					};
				}

				// require images
				switch(modeID) {
					case 0: jscolor.requireImage('hs.png'); break;
					case 1: jscolor.requireImage('hv.png'); break;
				}
				jscolor.requireImage('cross.gif');
				jscolor.requireImage('arrow.gif');

				this.importColor();
			}

		};


	
	
	
    return RweEditView;
    
});;define('TakeQuizView',['CommonView','Carousel','utility','ajax','HostURLs'],function(CommonView,Carousel,utility,ajax,HostURLs){
	
	function takeQuiz(data, scene) {
	
		
		/*this.currentData = this.data.quiz;*/

			this.scene = scene;
			this.open = false ;
			//define variables
			var message ={
					"0":'<div class="wrong-answer"></div><div class="info-text">Answer is incorrect. Try Again!</div>',
					"1":'<div class="right-answer"></div><div class="info-text">You got it right!</div>'
			}
			var header = '<div  class="header-tools animated ">'
								+'<div class="edit-tool-right close"></div>'
								+'<div class="separator quiz-separator"></div>'
								+'<div id="takeQuiz-Question" class="edit-tool-right header-question-nav">Show Question</div>'
								+'<div class="separator quiz-separator"></div>'
								+'<div id="takeQuiz-CheckAnswer" class="edit-tool-right header-submit-nav highlight-button">Submit</div>'
								
								+'<div  class="sim-logo take-quiz-mode"></div>'
						  +'</div>';
	        var template = '<div class="take-Quiz-Controller">'	
	        				
	        				
		        				
		        				
	        				+'</div>'
	        				//sideContainer start
	        				//overlay
	        				+'<div class="quiz-overlay takeQuizOverLay hide"></div>'
	        				+'<div class="top-container">'
	        					+'<div class="top-container-question question-logo"></div>'
	        					+'<div class="top-container-description"></div>'
	        					+'<div class="top-container-button-container">'
	        						+'<div  class="quiz-button-next report-button">TRY IT</div>'
	        						+'<div  class="quiz-button-cancel report-button top-cancel-button">CANCEL</div>'
	        					+'</div>'
	        				+'</div>'
	        				//sideContainer end
	        				// check Answer popUp UI start
	        				+'<div class="msg-overlay check-answer-box hide">'
		        				+'<div class="msg-box ">'
						 			+'<div class="msg-infoContainer"></div>'
						 			+'<div class="button-container ">'
							 			+'<div  class="try-button report-button">Try Again</div>'
							 			+'<div  class="exit-button report-button">Exit</div>'
						 			+'</div>'
					 			+'</div>'
				 			+'</div>'
	        				// check Answer popUp UI end;
				template = header + template;
	    	//end of variables 
	        
        CommonView.apply(this , [{
			template:template,
			name :'createQuizView',
			el: 'div',
			initialize: this.init
		}]);
        
        
        this.events = {
         'click .close':'closeCurrentView',
         'click .takeQuizOverLay':'closeOverlay',
         'click #takeQuiz-Question':'showQuestions',
         'click #takeQuiz-CheckAnswer':'submitValues',
         'click .quiz-button-cancel':'closeCurrentView',
         'click .quiz-button-next':'closeOverlay',
         'click .try-button':'closeCheckAnswerBox',
         'click .exit-button':'closeCurrentView',
        };
        this.submitValues = function(){
        	this.renderQuestion(this.checkAnswer);
        	/*dexterjs.logEvent("FBS_SIMULATION_Q_A", {
        		"button" : "submit" ,
        		"questionID" : this.questionID 
            });*/
        }.bind(this);
        this.closeCurrentView = function(e){

        	 this.initialSetting();
        	this.scene.hideView('takeQuizView');
        	this.scene.showView('quizMainScreen');
        	
        	//refresh Quiz View
        	if(this.answerSubmitted){
          	   this.scene.quizView.refreshView();
         	   this.answerSubmitted = false;
        	}
        	if(e.target.innerHTML == "CANCEL"){
        		/*dexterjs.logEvent("FBS_SIMULATION_Q", {
            		"button" : "cancel" ,
            		"questionID" : this.questionID 
                });	*/	
        	}else if(e.target.innerHTML=="Exit"){
        		
        	}
        	else if(e.target.innerHTML==""){
        	  	/*dexterjs.logEvent("FBS_SIMULATION_Q_A", {
					"button" : "cancel" ,
					"questionID" : this.questionID 
        	  	});*/
        	}
        
        }.bind(this);
        this.closeOverlay = function(e){
        	this.overLay.classList.add('hide');
        	this.sideContainer.classList.remove('expand-bottom');

        	if(e.target.innerHTML == "TRY IT")
            	/*dexterjs.logEvent("FBS_SIMULATION_Q", {
            		"button" : "tryit" ,
            		"questionID" : this.questionID 
                });*/

        	setTimeout(function(){
        		this.tryButton.innerHTML = "CLOSE";
            	this.cancelButton.classList.add('hide');
        	}.bind(this),500)

        }.bind(this);  
        this.openOverlay = function(){
        	this.overLay.classList.remove('hide');
        }.bind(this); 
        this.showQuestions = function(event){
        	this.openOverlay();
            this.openSideContainer();
            
            if(event){/*
            	dexterjs.logEvent("FBS_SIMULATION_Q_A", {
        						"button" : "showq" , 
        						"questionID" : this.questionID 
            	});
            */}
        
        
        }.bind(this);
     
        this.showNextQuestion = function(){
 
        }.bind(this);             
        this.initialSetting = function(){
        	this.closeCheckAnswerBox();
        	this.showQuestions();
    		this.slideNavigation.classList.remove('side-nav-transition');
    		this.open = false;
    		//attempted setting
    		this.submit.classList.remove('hide');
    		this.tryButton.innerHTML = "TRY IT";
    		this.cancelButton.classList.remove('hide');
        }
        this.checkAnswer = function(){
      
        	var submitAnswer = {};
        	var isAnswerCorrect = 0;
        	for(var i in this.scene.additionalScene.sliders ){
        		if(this.scene.additionalScene.sliders[i].options.shifts){
            		submitAnswer[this.scene.additionalScene.sliders[i].options.parameter] =  this.scene.additionalScene.sliders[i].data[""] || this.scene.additionalScene.sliders[i].data[this.scene.additionalScene.sliders[i].options.UIValue] || this.scene.additionalScene.sliders[i].options.UIValue;

        		}
        	} 
        	//write code to match answer
        	for(var i in submitAnswer ){
        		if((submitAnswer[i] == this.currentQuestionObject.questionData.answer[0][i])||(this.currentQuestionObject.questionData.answer[0][i]==="ANY") ){
        			isAnswerCorrect = 1;
        		}else{
        			isAnswerCorrect = 0;
        			break;
        		}
        	} 
        	this.currentMessage = message[isAnswerCorrect];
        	this.openCheckAnswerBox();
        	
        	/****
        	 * //call API for submit Answer 
        	 *  send object submitAnswer
        	 * 
        	 * ****/
        	var lastSubmitData = {}
        	var evalResult = {}
        		evalResult["correctAnswer"] = [this.currentQuestionObject.questionData.answer[0]];
        		evalResult["userAnswer"] = [submitAnswer];
        		if(isAnswerCorrect){
        			evalResult["isCorrect"] = true;
        		}else{
        			evalResult["isCorrect"] = false;
        		}

        		evalResult["questionInstanceID"] = this.currentTestSheetObject["_id"];
        		evalResult["userInput"] = JSON.stringify(submitAnswer);
        		evalResult["sequence"] = this.currentTestSheetObject["sequence"];
        		evalResult["evalAnswers"] = [evalResult["isCorrect"]];
        		evalResult["timeSpent"] = 0;
        		lastSubmitData["evalResult"] = JSON.stringify(evalResult); 
        		lastSubmitData["questionInstanceID"] = this.currentTestSheetObject["_id"];
        	var formData = new FormData();
        	for(var i in lastSubmitData){
       		 formData.append(i, lastSubmitData[i]);
        	}
    		ajax.sendFormData(URL.SUBMIT_ASSESSMENT_ANS_HOST_URL+this.currentTestSheetObject["testScoreID"]+"/"+this.currentTestSheetObject["sequence"],{
    			withCredentials : true,
    			message : formData,
    			callback : function(response){
    				//console.log(response);
        		}.bind(this)
    		});
        	this.answerSubmitted = true;
        }.bind(this);
        
        this.openCheckAnswerBox = function(){
        	this.messageInfo.innerHTML = this.currentMessage;
        	this.checkAnswerBox.classList.remove('hide');
        }.bind(this);
        this.closeCheckAnswerBox = function(){
        	this.checkAnswerBox.classList.add('hide');
        }.bind(this);
        this.openSideContainer = function(){
        	this.sideContainer.classList.add('expand-bottom');
        }.bind(this); 
   
    }

	
	takeQuiz.prototype = Object.create(CommonView.prototype);
	takeQuiz.prototype.constructor = takeQuiz;

   
    
	takeQuiz.prototype.init = function init(){
    	
		this.closeIcon = this.el.querySelector('.close');
		this.overLay = this.el.querySelector('.takeQuizOverLay');
		this.sideContainer = this.el.querySelector('.top-container');
		this.questionContainer = this.el.querySelector('.top-container-question');
		this.descriptionContainer = this.el.querySelector('.top-container-description');
		this.checkAnswerBox = this.el.querySelector('.check-answer-box');
		this.messageInfo = this.el.querySelector('.msg-infoContainer');
		this.slideNavigation = this.el.querySelector('.take-Quiz-Controller');
		this.slideLogo = this.el.querySelector('.side-nav-logo');
		this.submit = this.el.querySelector('#takeQuiz-CheckAnswer');
		this.tryButton = this.el.querySelector(".quiz-button-next");
		this.cancelButton = this.el.querySelector(".quiz-button-cancel");

		 this.initialSetting();
	};
    
	takeQuiz.prototype.setData = function setData(object,testID,questionID){
		this.currentQuestionObject = object;
		this.testID  = testID;
		this.questionID  = questionID;
		this.questionContainer.innerHTML = this.currentQuestionObject.questionData.questionText;
    	this.descriptionContainer.innerHTML = this.currentQuestionObject.questionData.questionDescription;

	};
	takeQuiz.prototype.setAttemptedData = function setAttemptedData(){
		this.settingSliders = function(){
			this.submit.classList.add('hide');
			this.tryButton.innerHTML = "CLOSE";
			var previousAnswer = [];
			var lastAnswer = JSON.parse(this.currentTestSheetObject.lastUserInput);
			for(var i in this.scene.additionalScene.sliders){
				if(this.scene.additionalScene.sliders[i].options.shifts){
					previousAnswer.push(this.scene.additionalScene.sliders[i].options.shifts.indexOf(lastAnswer[this.scene.additionalScene.sliders[i].options.parameter])+1);
				}
				
			}
			this.updateSliderValues(previousAnswer);
		}.bind(this);
		this.renderQuestion(this.settingSliders);
	};
	takeQuiz.prototype.renderQuestion = function renderQuestion(callback){
			startLoadingAnim("loading");
			this.setTestScoreID = function(response){
			var testSheet = (response.status === 200) ? JSON.parse(response.response) : {response : {test :{ items:[]}}};
			this.currentTestSheetObject = testSheet.response ;
			startLoadingAnim("loaded");
			if(callback){
				callback();
			}
		}.bind(this);
		ajax.loadURL(URL.RENDER_QUES_INSTANCE_HOST_URL+this.testID+"/"+this.questionID,{
			withCredentials : true,
			callback :this.setTestScoreID
		});
	};
	takeQuiz.prototype.updateSliderValues = function updateSliderValues(updatePostion){
 		if(updatePostion!=="initial"){
 	 		for(var i in this.scene.additionalScene.sliders){
 	 			if(this.scene.additionalScene.sliders[i].options.shifts){
 				this.scene.additionalScene.sliders[i].update(updatePostion[i]);
 				this.scene.additionalScene.sliders[i].disable();
 				}
 			}
 		}else{
 			/*for(var i in this.scene.additionalScene.sliders){
 				this.scene.additionalScene.sliders[i].update(1);
 				this.scene.additionalScene.sliders[i].enable();
 				
 			}*/
 		}
 	};
    // This function creates an overlay and shows loading progess/animation
    function startLoadingAnim(type){
    	var progress = document.querySelector("#loaderScreen");
    	
    	switch (type){ 	
    	case "loading" :
	    				 progress.classList.remove('hide');
    				     break;
    	case "loaded"   :  
						 progress.classList.add('hide');
    					 break;
    	}

    }

    
    return takeQuiz;
}) ;;define('ToolBarView',[
		 'CommonView',
         'utility',
         'SoModel'
         ],function(CommonView,utility,SoModel){
	
	
	/**
	 * Creates toolbar view
	 * @constructor ToolBarView
	 */
	function ToolBarView(options){
		var marginRight = '',hideShare='';
		var fontSize, action ;
		/*var simUrlString = window.location.href ;
		simUrlString = simUrlString.slice(0,simUrlString.indexOf('/app'));
		var simulationName = simUrlString.slice(simUrlString.lastIndexOf('/')+1 , simUrlString.length);
		var simSource = "?source=simulation&simulationName="+simulationName;
		var interactivesBrowse = " http://simdev.ck12.org/simulations/launcher/index.html"*/
		this.locAPP = utility.getUrlParameters("loc")
//		if(!options.userAvatar || this.locAPP== "app"){
//			 marginRight = 'margin-right-zero';
//		}
		
		if(!options.email){			//hide share-plane
			 hideShare = 'hide';
		}
		/*<sup class="logo-version">Beta</sup>*/
		var template = 
			'<a class="back-to-source home" id="backToSrc" href="http://interactives.ck12.org/simulations/index.html"></a>'+'<div class="sim-logo">Exploration Series</div>'+'<div class="tool-menus-list">'
			+'<div class="tool-menu more " id="toolBarMore"></div>'
			+'<div class="tool-menu share-plane '+hideShare+'"><div id="shareImage" class="plane-image"></div><div class="separator"></div></div>'
              +'<div class=" tool-menu font-size-button '+marginRight+' " id="toolBarFont" >Aa'
              +'<div class="font-size-menu expand ">'
              +'<div id="font1"  class="small-font font font-select">Aa</div>'
              +'<div id="font2"  class="medium-font font font-select">Aa</div>'
              +'<div id="font3"  class="large-font font font-select">Aa</div></div>'
              +'<div class="separator"></div></div>' 
              +'<div class="tool-menu challenge '+marginRight+' " id="toolBarChallenge" >Challenge Me<div class="separator"></div></div>'
              +'<div class="tool-menu feedback" id="toolBarChallenge" >Feedback<div class="separator"></div></div>'
             /* +'<div class="tool-menu concepts" id="toolBarConcepts" >Concepts<div class="separator"></div></div>'*/
              +'<div class="tool-menu walkthrough" id="toolBarWalkThrough">Tutorial<div class="separator"></div></div>'
              +'</div>';
		this.fonts ={
						1:'small',
						2:'medium',
						3:'large'
					};
		
		var data = {
				fontID :1,
		           };
		
		this.model = new SoModel();
	/*	this.backURL = ( utility.getUrlParameters("backUrl")  || interactivesBrowse )+ simSource ;*/
		this.walkThroughURL = false;
		this.data = this.model.data;
		this.model.eyesOn(this.updateFont);
		
		CommonView.apply(this , [{
			template:template,
			name :'ToolBarView',
			el: 'div',
			classes:['sim-tool-bar'],
			initialize: this.init
		}]);
		
		this.events = {

			'click .font-size-button':'selectFont',
			'click .more':'showMore',
			'click .concepts':'showConcepts',
			'click .challenge':'openChallenge',
			'click .feedback':'showFeedbackView',
			'click #toolBarWalkThrough' :'openWalkThrough',
			'click #font1' : 'changeFontSmall',
			'click #font2' : 'changeFontMedium',
			'click #font3' : 'changeFontLarge',
			'click #backToSrc': 'backToSrc',
			'touchstart #backToSrc': 'backToSrc',
			'click #shareImage': 'shareSim'
				
		};
		
		this.shareSim = function shareSim(e){
			this.eventHandler.emit('share');
		}.bind(this);
		
		this.menuClick = function menuClick(e){
			e.stopPropagation();
		};
		
		this.addSmallFont = function addSmallFont(e){
			this.data.fontID = 1;
			fontSize = this.fonts[this.data.fontID]
			//_dexterFontEvents(fontSize);
		};
		
		this.addMediumFont = function addMediumFont(e){
			this.data.fontID = 2;
			fontSize = this.fonts[this.data.fontID]
			//_dexterFontEvents(fontSize);
		};
		
		this.addLargeFont = function addLargeFont(e){
			this.data.fontID = 3;
			fontSize = this.fonts[this.data.fontID]
			//_dexterFontEvents(fontSize);
		};
		
		this.backToSrc = function backToSrc(e){
			e.stopPropagation();
			this.eventHandler.emit('goBackToSrc');
			
			
		}.bind(this);
		

		this.selectFont = function selectFont(e){

			e.stopPropagation();
		this.eventHandler.emit('hideMore');
		this.fontMenu.style.left = this.fontButton.offsetParent.offsetLeft + this.fontButton.offsetLeft+ 2 + "px";
		this.fontMenu.style.top  = this.fontButton.offsetTop+"px";
		this.fontMenu.classList.add('open');
		this.el.classList.add('activeElements');
		}.bind(this);
		
        this.changeFontSmall = function changeFontSmall(e){
			e.stopPropagation();
        	this.addSmallFont();
         	this.updateFont(this.fonts[this.data.fontID]);
        }.bind(this);
        
         this.changeFontMedium = function changeFontMedium(e){
 			e.stopPropagation();
        	this.addMediumFont();
         	this.updateFont(this.fonts[this.data.fontID]);
        }.bind(this);
        
         this.changeFontLarge = function changeFontLarge(e){
 			e.stopPropagation();
        	this.addLargeFont();
         	this.updateFont(this.fonts[this.data.fontID]);
        }.bind(this);
        
        
		this.showMore = function showMore(e){
			//e.stopPropagation();
			this.eventHandler.emit('showMore');
		}.bind(this);
		
		this.showConcepts = function showConcepts(e){
			//e.stopPropagation();
			//this.eventHandler.emit('showConcepts');
			
		}.bind(this);
		
		this.openChallenge = function openChallenge(e){
			//e.stopPropagation();
			this.eventHandler.emit('openChallenges');
		}.bind(this);
		
		this.openWalkThrough = function openWalkThrough(e){
			e.stopPropagation();	
			this.eventHandler.emit('showWalkThrough');
		}.bind(this);
		
		this.closeFont = function closeFont(){
			this.fontMenu.classList.remove('open');
			this.el.classList.remove('activeElements');
		}.bind(this);
		
		this.showProfile = function showProfile(e){
			//e.stopPropagation();
		
			 this.eventHandler.emit('showProfile');
		}.bind(this);
		
		this.showFeedbackView = function(e){
			this.eventHandler.emit('showFeedbackView');
			this.eventHandler.emit('showReportIssue',{'ID':'6'});
		}.bind(this);
		
	}
	
	function _dexterFontEvents(fontSize){/*
    	
  	  	dexterjs.logEvent("FBS_SIMULATION_FONT", {
            action :  fontSize 
        });
    */}

	ToolBarView.prototype = Object.create(CommonView.prototype);
	ToolBarView.prototype.constructor = ToolBarView;
	
	
	ToolBarView.prototype.init = function init(){
            	this.backArrow = this.el.querySelector('#backToSrc');
		if(window.location.href.indexOf('noReturn=true') > -1){
			this.backArrow.classList.add("hide");
        }
		//this.conceptButton = this.el.querySelector('#toolBarConcepts');
		this.walkThrough = this.el.querySelector('.walkthrough');
		this.fontButton = this.el.querySelector('#toolBarFont');
		this.fontMenu = this.el.querySelector('.font-size-menu');
		this.fontSmall = this.el.querySelector('#font1');
		this.fontMedium = this.el.querySelector('#font2');
		this.fontLarge = this.el.querySelector('#font3');
		this.challenge = this.el.querySelector('#toolBarChallenge');
//		this.userAvatar = this.el.querySelector('.user-avatar');
//		this.userAvatarImage = this.el.querySelector('.user-avatar-image');
		if (this.locAPP == "app") {
			this.backArrow.classList.add("home");
			if(/Android|Build/.test(navigator.userAgent)){
            	this.backArrow.classList.add("hide");
            }else if(/iOS|Build/.test(navigator.userAgent)){
            	/*this.el.style.top = "10px";*/
            };
            //this.conceptButton.classList.add('hide');
        }
	};
	
	/**
	 * Update the toolbar tabs according to the scene
	 * @method updateView
	 * @memberof ToolBarView
	 * @param {string} name of the scene
	 */
	ToolBarView.prototype.updateView = function(scene){
		this.eventHandler.emit('updateAboutPos');
		this.locAPP = utility.getUrlParameters("loc")
		/*if(this.locAPP==='app'){
			this.conceptButton.classList.add('hide');
		}*/
		
		if(scene==='sandBoxScene'){
			if(this.walkThroughURL==false){
				this.eventHandler.emit("loadWalkThrough");
			}
			this.fontButton.classList.add('hide'); 			
		    if(this.walkThroughURL){
		    	this.walkThrough.classList.remove('hide'); 
			 }
	    	this.challenge.classList.remove('hide'); 
		}else{
			this.walkThrough.classList.add('hide');
			this.challenge.classList.add('hide');
			this.fontButton.classList.remove('hide');  	
		}
	};
	ToolBarView.prototype.updateUser = function(toolbarOptions){
		if(toolbarOptions.userAvatar){
		this.challenge.classList.remove('margin-right-zero');
		this.fontButton.classList.remove('margin-right-zero');
		this.challenge.classList.remove('margin-right-zero');
		this.fontButton.classList.remove('margin-right-zero');
//			if(this.locAPP != "app"){
//				this.userAvatar.classList.remove('hide');
//			}
//			this.userAvatarImage.src = toolbarOptions.userAvatar;
		}
	};
	
	ToolBarView.prototype.updateFont = function(font,size){
		   var currentFont = this.el.querySelector("#toolBarFont");
		   ['smallFont','largeFont','mediumFont'].forEach(function(element){
			   currentFont.classList.remove(element);
			});
		 
			currentFont.classList.add(font+'Font');
			this.eventHandler.emit('fontUpdated');
	};
	
	
	return ToolBarView;
	
});
;define('UserProfileView',['CommonView','ajax','HostURLs'],function(CommonView,ajax,HostURLs){
    
    function UserProfileView(info){
    	
         this.firstName = info.firstName || '';
         this.lastName = info.lastName || '';
         this.imageURL = info.imageURL;
         this.email = info.email || '';
         
         
         var template = '<div class="user-profile-container"><img src="'+this.imageURL+'" title="'+this.firstName+' '+this.lastName+'"/>'
         +'<div class="name">'+this.firstName+' '+this.lastName+'</div><div class="email">'+this.email+'</div>'
         +'<div class="seperator"></div><div class="options"><div class="settings hide icons">Settings</div><div class="signout icons">Sign Out</div></div></div>';
         
         CommonView.apply(this , [{
             template:template,
             name :'userProfileView',
             el: 'div',
             classes:['user-profile-screen'],
             initialize : this.closeProfile
         }]);
         
         this.events = {
           'click .aboutClose':'closeAbout',
           'click el' : 'stopPropagation',
           'click .signout':'signout',
           'click .settings': 'settings'
         };
         
         this.stopPropagation = function(e){
             e.stopPropagation();
         };
         
         this.closeAbout = function(e){
          e.stopPropagation();
          this.eventHandler.emit('hideAbout');
         }.bind(this);
         
         this.signout = function(e){
        	 window.location = URL.USER_ACOUNT_HOST_URL+'signout';
        	 ajax.send(URL.AUTH_HOST_URL+'logout/member',{
        	  message: null,
        	  withCredentials: true,
        	  callback: logoutCallback
        	 });
         };
          
         function logoutCallback(){
        	 //console.log('well?');
         }
         
          this.settings = function(e){
           window.location = URL.USER_ACOUNT_HOST_URL+'settings';
         };
    }
    
    UserProfileView.prototype = Object.create(CommonView.prototype);
    UserProfileView.prototype.constructor = UserProfileView;
    
    
    UserProfileView.prototype.openProfile = function openProfile(){
    	this.el.style['display'] = 'block';
    };
    
    UserProfileView.prototype.closeProfile = function closeProfile(ev){
    	if(ev)
    	if(ev.target == document.querySelector('.user-avatar') || ev.target == document.querySelector('.user-avatar-image'))
    		return;
    	this.el.style['display'] = 'none';
    };
    
    return UserProfileView;
    
});;define('View',['EventHandler'],function(eventHandler){
	

	/**
	 * creates instance of view
	 * @constructor View
	 * @param {object} options
	 */
	function View(options){
		 this.eventHandler = new eventHandler();
		 this.options = options;
	}
	
	View.prototype.on = function(eventType,handler){
		this.eventHandler.on(eventType,handler);
	};
	
	View.prototype.off = function(eventType,handler){
		this.eventHandler.on(eventType,handler);
	};
	
	View.prototype.emit = function(eventType,event){
		this.eventHandler.emit(eventType,event);
	};
	
	View.prototype.set = function(){
		 this.el = document.createElement('div');
		 this.el.classList.add("" || this.options.name);
	};
	
	/**
	 * render the view
	 * @memberof View
	 * @method render
	 * @param {string} template html template
	 */
	View.prototype.render = function(template){
		this.el.innerHTML = template;
	};
	
	return View;
	
});;define('ViewController', [''], function() {


    /**
     * Creates an instance of ViewController
     * @constructor ViewController
     */
    function ViewController(sceneEl) {
        this.sceneEl = sceneEl;
        this.views = [];
        this.viewObjs = {};
        this.currentViews = [];
    }

    ViewController.prototype = {
        /**
         * Remove a view from the scene, it removes from the DOM so that particular view would not be visible.
         * Mutiple views can also be removed from the scene - provide as an array
         * @method remove
         * @param {string | name[]} name of the view or array of views
         * @memberof ViewController
         */
        removeView: function(view) {
            if (view instanceof Array)
                for (var v in view) {
                    delete this.viewObjs[view[v]];
                    var index = this.views.indexOf(view[v]);
                    this.views.splice(index, 1);
                } else {
                delete this.viewObjs[view];
                var index = this.views.indexOf(view);
                this.views.splice(index, 1);
            }
        },
        /**
         * Add a view to the scene,multiples view can also be added by giving the names in an array
         * @method add
         * @param {string | name[]} name of the view or array of views
         * @memberof ViewController
         */
        addView: function(view) {
            for (var v in view) {
                this.views.push(v);
                this.viewObjs[v] = view[v];
                view[v].eventHandler = this.eventHandler;
                view[v].initialize();
            }
        },

        /**
         * Display a view of the Scene
         * @method showView
         * @memberof ViewController
         * @param {string} name of the view
         */
        showView: function(viewName) {
            this.viewObjs[viewName].el.id = viewName;
            this.viewObjs[viewName].render(this.sceneEl);
        },

        /**
         * Hide a particular view from the scene
         * @method hideView
         * @param {string} name of the view
         * @memberof ViewController
         */
        hideView: function(viewName) {
            var view = this.sceneEl.querySelector('#' + viewName);
            if (view)
                this.sceneEl.removeChild(view);
        }
    };

    return ViewController;

});;define('WalkthroughVideo',['CommonView','ajax','HostURLs','utility'],function(CommonView,ajax,HostURLs,utility){
	
	function WalkthroughVideo(data){
		 this.regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|\&v=)([^#\&\?]*).*/;
		 this.embeded = false; 
		 this.packageData = data.packageData;
		 this.userData = data.userData;
		 this.disableShare = '';
		 this.locAPP = utility.getUrlParameters("loc")
		 if (this.locAPP == "app") {
		 	this.disableShare = 'disableShare';
			if(/Android|Build/.test(navigator.userAgent)){		//for android
				this.disableShare = '';
            }
		 }
		 
		 this.isAdmin	=(function(){
			 					// for(var i in this.userData.roles){
			 						// if(this.userData.roles[i].name=="admin" || this.userData.roles[i].name=="content-admin"|| this.userData.roles[i].name=="support-admin" /*|| this.userData.roles[i].name=="member"*/)
			 							// return true;
			 					// }
		 				}).call(this) || false;
		 this.videoTemplate = '<iframe class = "walk-throuh-video-frame hide" frameborder="0"></iframe>';	
			this.addUrlTemplate = '<div class = "video-avl-info">'
							+'<div class = "video-unavailabe hide">Video is not available. Please Input Embeded link</div>'
							+'<input class = "video-input-place" type="text" name="link" placeholder="Input Embeded Link">'
							+'<div class="save-button-container video-button"><div class = "create-quiz-buttons save video-submit-button">Submit</div><div id ="clear" class = "create-quiz-buttons ">Clear</div></div>'
						+'</div>';

			var template = '<div class="walkThrough-container" id="walkThroughContainer">'
	    					+'<div class="walkThrough-text header"><span class="walkThrough-title">Tutorial</span><span class="edit-url edit hide">Edit</span><span class="edit-url delete hide">Delete</span></div>'	
	    					+'<div class="walkThrough-close"></div>'
	    					+'<div class="iframe-parent '+this.disableShare+'">'
	    					+'<div class="full-screen-icon">Full screen</div>'
	    					+this.videoTemplate
	    					+'</div>'
	    					+this.addUrlTemplate
	    				+'</div>' ;
	
		
		
		CommonView.apply(this , [{
	       template:template,
            name :'WalkthroughVideo',
            el: 'div',
            classes:['WalkthroughVideo-screen'],
            initialize: this.init
        }]);
		
		this.events = {
				'click .walkThrough-close':'closeWalkThrough',
				'click .video-submit-button':'saveVideo',
				'click #clear':'removeLink',
				'click .full-screen-icon':'showFullScreenMode'	
		}
		
		this.showFullScreenMode = function showVideoMode(e){
			this.fullScreen = !this.fullScreen;
			if(this.fullScreen){
				this.iframeParent.classList.add('full-screen-view');
				e.currentTarget.innerHTML = "Exit full screen";
			}
			else{
				this.iframeParent.classList.remove('full-screen-view');
				e.currentTarget.innerHTML = "Full screen";
			}
		}.bind(this);
		
		this.closeWalkThrough = function closeOnClick(e){
			this.eventHandler.emit('hideWalkThrough');
			this.removeLink();
		}.bind(this);
		this.removeLink = function removeLink(e){
			this.inputField.value = '';
		}.bind(this);
		this.saveVideo = function saveVideo(e){
			e.stopPropagation();
			this.checkVideolink();
			if(this.embeded){
				this.sendWalkthroughURL();
				this.removeLink();
			}else{
				this.displayMessage("warning");
			}
			
		}.bind(this);
		this.checkVideolink = function checkVideoLink(){
	
			this.videoLink = this.inputField.value.match(this.regExp);
			if(this.videoLink && this.videoLink[2].length == 11){
				this.embeded = true;
				this.videoLink = "https://www.youtube.com/embed/"+this.videoLink[2]+"?wmode=opaque&amp;rel=0&amp;autohide=1&amp;wmode=transparent";
			}else{
				this.embeded = false;
			}
			
		}.bind(this);
		this.showEditMode = function showEditMode(){
			this.editURLContainer.classList.remove('hide');
			/*this.showVideoContainer.src = "";*/
			this.showVideoContainer.classList.add('hide');
			this.iframeParent.classList.add('hide');
		}.bind(this);
		this.showVideoMode = function showVideoMode(){
			if(this.videoLink && this.changeSrc){
				this.showVideoContainer.src = this.videoLink+"?wmode=opaque&amp;rel=0&amp;autohide=1&amp;wmode=transparent";
				this.changeSrc = false;
				this.editURLContainer.classList.add('hide');
				this.showVideoContainer.classList.remove('hide');
				this.iframeParent.classList.remove('hide');
			}else if(this.videoLink){
				this.editURLContainer.classList.add('hide');
				this.showVideoContainer.classList.remove('hide');
				this.iframeParent.classList.remove('hide');
			}
		
		}.bind(this);
		
	}
	
	WalkthroughVideo.prototype = Object.create(CommonView.prototype);
	WalkthroughVideo.prototype.constructor = WalkthroughVideo;
	
	WalkthroughVideo.prototype.init = function init(){
		this.inputField = this.el.querySelector('.video-input-place');
		this.clearLink = this.el.querySelector('#clear');
		this.editLink = this.el.querySelector('.edit-url.edit');
		this.deleteLink = this.el.querySelector('.edit-url.delete');
		this.editURLContainer = this.el.querySelector('.video-avl-info');
		this.showVideoContainer = this.el.querySelector('.walk-throuh-video-frame');
		this.walkThroughTitle = this.el.querySelector('.walkThrough-title');

		this.loadVideoLink();

		this.editURLContainer.classList.add('hide');
		this.showVideoContainer.classList.add('hide');
		this.createURL = true;
		this.changeSrc = true;
		this.fullScreen = false;
		this.fullScreenIcon = this.el.querySelector('.full-screen-icon');
		this.iframeParent = this.el.querySelector('.iframe-parent');
	};

	WalkthroughVideo.prototype.sendWalkthroughURL  = function sendWalkthroughURL(){
		startLoadingAnim("loading");
		var task = this.createURL?"create":"update";
		var id = this.createURL?this.packageData.resourceID:this.resource.id;
		 var formData = new FormData();
	        var postConfig = {
	        	id:id,
	        	resourceType: "video",
	            resourceName: "walkthroughurl",
	            resourceID: this.packageData.resourceID,
	            artifactID: this.packageData.artifactID,
	            resourceUri: this.videoLink,
	            isAttachment: false,
	            isPublic: true
	        };
	        
	        for (var i in postConfig) {
	            if (postConfig.hasOwnProperty(i)) {
	                formData.append(i, postConfig[i]);
	            }
	        }
    
		ajax.sendFormData(URL.FLX_HOST_URL+task+"/resource",{
			withCredentials : true,
			message : formData,
			callback : function(response){
			    if(this.createURL){
			    	 var postConfigForAssociation = {
					            resourceID:response.id,
					            artifactID: this.packageData.artifactID,
					        };
					this.createAssociation(postConfigForAssociation);
			    }else{
					this.videoLink = false;
					this.loadVideoLink();
					startLoadingAnim("loaded");
					this.displayMessage("updated");
			    }
			    

			}.bind(this)
		});
		
		this.createAssociation = function(options){
			var formData = new FormData();
		     for (var i in options) {
		            if (options.hasOwnProperty(i)) {
		                formData.append(i, options[i]);
		            }
		        }
			ajax.sendFormData(URL.FLX_HOST_URL+"create/resource/association",{
				withCredentials : true,
				message : formData,
				callback : function(response){
					this.videoLink = false;
					this.loadVideoLink();
					startLoadingAnim("loaded");
					this.displayMessage("created");
				}.bind(this)
			});
		}
		
	};
	WalkthroughVideo.prototype.loadVideoLink = function loadVideoLink(){
		
		if(!this.videoLink){
			ajax.loadURL(URL.FLX_HOST_URL+"get/info/artifact/resources/"+ this.packageData.artifactID+"/video",{
				withCredentials : true,
				callback : function(response){
					var resource = (response.status === 200) ? JSON.parse(response.response) : {response : {resources:[]}};
						if(!resource.response.message){
							this.resource = resource.response.resources[0];
						}else{
							this.resource = resource.response ;
						}
				
					if(this.resource && this.resource.uri){
						this.videoLink = this.resource.uri;
						this.changeSrc = true;
						this.showVideoMode();
						/*if(this.isAdmin){
							this.editAddedURL();
						}*/
						this.eventHandler.emit('addWalkThroughInToolBar');
					}else{
						this.videoLink = "";
						//this.showEditMode();
						//if(!this.isAdmin){
							this.eventHandler.emit('removeWalkThroughFromToolBar');
						//}else{
						//	this.eventHandler.emit('addWalkThroughInToolBar');
						//}
					}
				}.bind(this)
			});
		}else{
			this.showVideoMode();
		}
		//this.showVideoMode();
		
	}
	
	WalkthroughVideo.prototype.editAddedURL = function editAddedURL(){
		this.editLink.classList.remove('hide');
		this.deleteLink.classList.remove('hide');
		var deleted = function(){
			startLoadingAnim("loading");
			var postConfig = {
						      id:this.resource.id,
						      force:true
							}
			var formData = new FormData();
			for (var i in postConfig) {
		      if (postConfig.hasOwnProperty(i)) {
		          formData.append(i, postConfig[i]);
		      }
			}
		
			ajax.sendFormData(URL.FLX_HOST_URL+"delete/resource",{
			withCredentials : true,
			message : formData,
			callback : function(response){
				this.videoLink = "";
				this.createURL = true;
				this.editLink.classList.add('hide');
				this.deleteLink.classList.add('hide');
				this.showEditMode();
				startLoadingAnim("loaded");
				this.displayMessage("deleted");
			}.bind(this)
			});
		}.bind(this);
		
		
		var editURL =  function(e){
			e.stopPropagation();
			this.createURL = false;
			this.inputField.value = this.videoLink;
			this.showEditMode();
		}.bind(this);
		
		var  deleteURL = function(e){
			e.stopPropagation();
			this.eventHandler.emit('showMessageModal',{ message : "Are you sure want to delete current tutorial url?", 
														buttons:[
														         {
														        	 name:"OK",
														        	 callback:function(){
														        		 					this.eventHandler.emit('hideMessageModal');
														        		 					deleted();
																						}.bind(this)
														         },
														         {
														        	 name:"CANCEL",
														        	 callback:function(){
														        		 					this.eventHandler.emit('hideMessageModal')
														        		 				}.bind(this)
														         }
														        ]
														}
									);
			
		}.bind(this);
		

		
		this.editLink.addEventListener('click',editURL,false);
		this.deleteLink.addEventListener('click',deleteURL,false);
		this.walkThroughTitle.addEventListener('click',this.showVideoMode,false);
	}
	WalkthroughVideo.prototype.displayMessage = function displayMessage(messageType){
		
  	  	switch (messageType){ 	
    	case "updated" :	this.eventHandler.emit('showMessage',{ message : "Tutorial url updated successfully."});
    						break;
    	case "deleted" :	this.eventHandler.emit('showMessage',{  message : "Tutorial url deleted successfully."});
    						break;
    	case "created" :	this.eventHandler.emit('showMessage',{  message : "Tutorial url created successfully."});
							break;
    	case "warning" :	this.eventHandler.emit('showMessage',{  message : "Tutorial url is not a valid youtube url!"});
							break;
    	}
	}
    // This function creates an overlay and shows sending progess/animation
    function startLoadingAnim(type){
    	var progress = document.querySelector("#loaderScreen");
    	
    	switch (type){ 	
    	case "loading" :
	    				 progress.classList.remove('hide');
    				     break;
    	case "loaded"   :  
						 progress.classList.add('hide');
    					 break;
    	}

    }
	return WalkthroughVideo;
});;define('AbacusSlider',['Slider'],function(Slider){
	
	function AbacusSlider(options){
		this.options = options;
		this.removeCallback = options.removeCallback || false;
		this.abacusSliders = [];
		_init.call(this);
	}
	function _init(){
		for(var i in this.options.sliders){
			this.createSlider(this.options.sliders[i].options);
		}
	}
	AbacusSlider.prototype.createSlider = function(sliderOptions){
		var defaultOpt = {};
		for(var i in sliderOptions){
			defaultOpt[i] = sliderOptions[i];
		}
		if(this.removeCallback){
			defaultOpt.move = function(){
				//empty
			};
			defaultOpt.end = function(){
				//empty
			};
		}
		//add additional value to the sliders shifts 
		if(this.options.addValue){
			for(var i in this.options.addValue){
				defaultOpt.max = (defaultOpt.max || 0) + 1;
				defaultOpt.shifts.push(this.options.addValue[i]);
			}
		}
		//add additional value to the sliders shifts 
		var slider = new Slider(defaultOpt);
			slider.renderAbacusSlider = _renderAbacusSlider;
			if(slider.options.shifts){
				this.abacusSliders.push(slider);	
			}
			
	}
		function _renderAbacusSlider(parent){
	     var sliderElement = document.createElement('div');
	        var length = this.options.classes.length;
	            sliderElement.classList.add("abacusSlider");

	        sliderElement.innerHTML = '<input class="js-customized" id="inputBox"></input><div class="slider-UI-label"><span class="label-slider abacus"></span></div><span class="slider-value abacus"></span>' + '<div class="slider-info hide"><div class="slider-info-close"></div><div class="slider-info-text">' + this.options.sliderInfo + '</div></div>';


	        this.el = sliderElement;
	       /* this.el.appendChild(this.sliderObj.infoIcon);*/
	        this.sliderObj.element = this.el;
	        this.sliderObj.element = this.el.querySelector('.js-customized');
	        this.sliderObj.labelName = this.el.querySelector('.label-slider');
	        this.sliderObj.labelValue = this.el.querySelector('.slider-value');
	        this.sliderObj.info = this.el.querySelector('.slider-info');
	        this.sliderObj.element.style.display = 'none';
	        if (this.options.label === false) {
	            this.sliderObj.labelName.style.display = 'none';
	        }
	        this.sliderObj.labelName.innerHTML = this.options.UILabel.replace(/=/g,"");
	        this.sliderObj.labelValue.innerHTML = this.options.UIValue + "" + this.options.UIUnit;
/*	        //add shift UI      
	        var shiftContainer = document.createElement('div');
	            shiftContainer.className = "slider-shifts";
	        var shifts = "";
	        for(var i in this.options.shifts){
	        	shifts = shifts + '<div class="slider-shift-value" style="left:'+((i+1)*10/(this.options.shifts.length))+'%"></div>';
	        }
	        shiftContainer.innerHTML =shifts ;
	        this.el.appendChild(shiftContainer);*/
	        this.el.appendChild(this.slider);
	        parent.appendChild(this.el);
	}
	return AbacusSlider;
});;define('Carousel', [], function() {
	
	/**
     * Creates an instance of Circle.
     *
     * @constructor Carousel
     * @this {Carousel}
     * @param {object} desired options to the carousel
     * @example
     * var myCarousel = new Carousel({
     * 		container : document.querySelector('.my-carousel'),
     *   	children : '<div class="example-tile"></div><div class="example-tile"></div><div class="example-tile"></div>',
     *   	paginationDots : false,
     *   	navigationArrows : true,
     *   	noOfTilesPerPage : [3,1],
     *   	marginInPercentage : 2	
     * })
     * 
     *
     */
	
	function Carousel(options){
		_init.call(this,options);
	}
	
	var _defaults = {
    		children : '',
    		paginationDots : true,
    		navigationArrows : false,
    		setStyles:true,
    		noOfTilesPerPage : [3,1],
    		marginInPercentage : 2
	}

	function _init(options){
		if(options&&options.container){
			
			/**
			 * Contains the DOM Object of the carousel container
			 * 
			 * @type object
			 */
			this.container = options.container;
			
			/**
			 * Contains the DOM Object of the sliding carousel
			 * 
			 * @type object
			 */
			this.carousel = document.createElement('div');
			
			/**
			 * Whether touch has started
			 * 
			 * @type boolean
			 */
			this.touchStarted = false;
			
			
			/**
			 * X coordinate of start point of touch
			 * 
			 * @type number
			 */
			this.touchStartPoint = 0;
			
			/**
			 * X coordinate of end point of touch
			 * 
			 * @type number
			 */
			this.touchEndPoint = 0;
			
			/**
			 * Total number of pages in the carousel
			 * 
			 * @type number
			 */
			this.noOfPages = 0;
			
			/**
			 * Index of the page currently displayed
			 * 
			 * @type number
			 */
			this.currentPageId = 0;
			
			/**
			 * Total width of Carousel in pixels
			 * 
			 * @type number
			 */
			this.carouselWidth = 0;
			
			/**
			 * Total number of tiles in one page of the carousel
			 * 
			 * @type number
			 */
			this.totalNoOfTiles = 0;
			
			/**
			 * Number of files per width of one page
			 * 
			 * @type number
			 */
			this.noOfTilesPerWidth = 0;
			
			/**
			 * Number of files per height of one page
			 * 
			 * @type number
			 */
			this.noOfTilesPerHeight = 0;
			
			/**
			 * Width of single tile
			 * 
			 * @type number
			 */
			this.tileWidth = 0;
			
			/**
			 * Height of single tile
			 * 
			 * @type number
			 */
			this.tileHeight = 0;
			
			/**
			 * Margin of each tile
			 * 
			 * @type number
			 */
			this.margin = ((options.marginInPercentage === undefined) ? _defaults.marginInPercentage : options.marginInPercentage)*this.container.clientWidth/100;
			
			/**
			 * Whether pagination dots are needed to be displayed or not
			 * 
			 * @type boolean
			 */
			this.paginationDots = ( options.paginationDots === undefined ) ? _defaults.paginationDots : options.paginationDots;
			
			/**
			 * Whether navigation arrows are needed to be displayed or not
			 * 
			 * @type boolean
			 */
			this.navigationArrows = ( options.navigationArrows === undefined ) ? _defaults.navigationArrows : options.navigationArrows;
			/**
			 * Whether set style properties or not
			 * 
			 * @type boolean
			 */
			this.setStyles = ( options.setStyles === undefined ) ? _defaults.setStyles : options.setStyles;
			/**
			 * Holds references of all the tile elements
			 * 
			 * @type Array
			 */
			this.tiles = [];
			
			var childHTML = options.children,
				paginationHeight = 0.1*this.container.clientHeight;
			
			if(options.noOfTilesPerPage){
				if(options.noOfTilesPerPage instanceof Array && options.noOfTilesPerPage.length === 2){
					this.noOfTilesPerWidth = options.noOfTilesPerPage[0];
					this.noOfTilesPerHeight = options.noOfTilesPerPage[1];
					this.totalTilesPerPage = this.noOfTilesPerWidth*this.noOfTilesPerHeight;
					this.tileWidth = this.container.clientWidth/this.noOfTilesPerWidth;
					this.tileHeight = (this.container.clientHeight - paginationHeight)/this.noOfTilesPerHeight;
					this.carousel.innerHTML = childHTML;
					this.totalNoOfTiles = this.carousel.children.length;
					this.noOfPages = Math.ceil(this.totalNoOfTiles/this.totalTilesPerPage);
					this.container.style.overflow = "hidden";
					this.container.appendChild(this.carousel);
					this.carousel.style.height = this.paginationDots ? "88%" : "100%";
					this.carousel.classList.add('sliding-carousel');

					for(var i=0,l=this.carousel.children.length; i<l ; i+=1){
						var pageIndex = Math.floor(i/this.totalTilesPerPage),
							relativeTileIndex = i%this.totalTilesPerPage,
							rowIndex = Math.floor(relativeTileIndex/this.noOfTilesPerWidth),
							colIndex = relativeTileIndex%this.noOfTilesPerWidth + pageIndex*this.noOfTilesPerWidth;
						this.tiles.push(this.carousel.children[i]);
						
						if(this.setStyles){
							this.carousel.children[i].style.width = this.tileWidth - 2*this.margin + "px";
							this.carousel.children[i].style.minHeight = this.tileHeight - 2*this.margin + "px";
							this.carousel.children[i].style.margin = this.margin + "px";
							this.carousel.children[i].style.top = rowIndex*this.tileHeight + "px";
							this.carousel.children[i].style.left = colIndex*this.tileWidth + "px";
						}
						this.carousel.children[i].style.left = colIndex*this.tileWidth + "px";
						this.carouselWidth += getOuterWidth(this.carousel.children[i]);
					}
					
					this.carousel.style.width = this.carouselWidth + "px";
					
					
					if(this.paginationDots && (this.noOfPages>1)){
						_createPaginationDots.call(this);
					}
					
					this.startOfTouch = function(event) {
			            if (event.touches) event = event.touches[0];
			            this.touchStarted = true;
			            this.touchStartPoint = event.clientX;
			            this.touchEndPoint = event.clientX;
			        }.bind(this);
			        
			        this.moveOfTouch = function(event) {
			        	var offset = this.currentPageId*this.container.clientWidth;
			            if (event.touches) event = event.touches[0];
			            this.touchEndPoint = event.clientX;
			            if(this.touchStarted){
			            	this.carousel.style.webkitTransitionDuration = '0s';
			            	this.carousel.style.transitionDuration = '0s';
			            	this.carousel.style.webkitTransform = 'translateX(' + (this.touchEndPoint - this.touchStartPoint - offset) + 'px)';
			            	this.carousel.style.transform = 'translateX(' + (this.touchEndPoint - this.touchStartPoint - offset) + 'px)';
			            }
			        }.bind(this);
					
			        this.endOfTouch = function(event) {
			            if (event.touches) event = event.touches[0];
			            this.touchStarted = false;
			            var totalMovement = this.touchEndPoint - this.touchStartPoint,
			            	threshold = 60;//this.container.clientWidth/6;
			            if((totalMovement < -threshold)&&(this.currentPageId < (this.noOfPages-1))){
			            	this.moveToPageId(this.currentPageId + 1);
			            } else if((totalMovement > threshold)&&(this.currentPageId > 0)){
			            	this.moveToPageId(this.currentPageId - 1);
			            } else {
			            	this.moveToPageId(this.currentPageId);
			            }
			        }.bind(this);
			        
				_bindTouchEvents.call(this);
					
				}
			} 
		}
	}

	/**
     * 
     * @method moveToPageId
     * @memberof Carousel
     * @param {number} pageId
     * @param {object} options
     * @example
     * Carousel.moveToPageId(2,{duration:100});
     * @this {Carousel}
     */
	Carousel.prototype.moveToPageId = function(pageId,options){
		var duration = '0.5s';
		if(options&&(options.duration != undefined)){
			duration = options.duration/1000 + 's';
		}
		if(this.paginationDots&&this.paginDotArray){
			for(var i=0, l = this.paginDotArray.length ; i < l; i += 1){
				this.paginDotArray[i].childNodes[0].classList.remove('pagination-dot-active');
			}
			this.paginDotArray[pageId].childNodes[0].classList.add('pagination-dot-active');
		}
		this.carousel.style.webkitTransitionDuration = duration;
		this.carousel.style.transitionDuration = duration;
		this.carousel.style.transform = 'translateX(-' + pageId*this.container.clientWidth + 'px)';
		this.carousel.style.webkitTransform = 'translateX(-' + pageId*this.container.clientWidth + 'px)';
		this.currentPageId = pageId;
	};
	
	/**
     * 
     * @method addNewTiles
     * @memberof Carousel
     * @param {object/array} tiles
     * @example
     * Carousel.addNewTiles(newTile);
     * @this {Carousel}
     */
	Carousel.prototype.addNewTiles = function(tiles){
		if(tiles){
			if(tiles instanceof Array){
				for( var i in tiles){
					if(tiles[i].hasOwnProperty()){
						_adjustNewChild.call(this,tiles[i]);
					}
				}
			} else if(tiles instanceof Object){
				_adjustNewChild.call(this,tiles);
				
			}
		}
	};
	
	/**
     * 
     * @method bindEvents
     * @memberof Carousel
     * @param {object} events
     * @example
     * Carousel.bindEvents({"click .carousel-example-container" : this.openClickedTile});
     * @this {Carousel}
     */
	Carousel.prototype.bindEvents = function(events) {
        for (var x in events) {
            var self = this;
            var targetInfo = x.split(/\s/g);
            var event = targetInfo[0];
            var target = targetInfo[1];
            if (target === 'el') {
                this.el.addEventListener(event, events[x]);
            }
            var elements = [].slice.call(this.container.querySelectorAll(target));
            elements.forEach(function(element) {
                element.addEventListener(event, events[x]);
            });
        }
    };
    
    /**
     * 
     * @method getTileElById
     * @memberof Carousel
     * @param {number} index
     * @example
     * Carousel.getTileElById(5);
     * @this {Carousel}
     * @returns {object} DOM Object of the tile having the given index
     */
	Carousel.prototype.getTileElById = function(index){
		return this.tiles[index];
	}
	
	function _createPaginationDots(){
		this.paginDotsContainer = document.createElement('div');
		this.paginDotArray = [];
		this.paginDotsContainer.classList.add('pagination-container');
		for(var i = 0; i < this.noOfPages ; i += 1){
			_addPaginationDot.call(this,i);
		}
		this.paginDotArray[0].childNodes[0].classList.add('pagination-dot-active');
		this.container.appendChild(this.paginDotsContainer);
	}
	
	function _bindTouchEvents(){
		this.container.addEventListener('touchstart',this.startOfTouch);
		this.container.addEventListener('touchmove',this.moveOfTouch);
		this.container.addEventListener('touchend',this.endOfTouch);
	}

	function _adjustNewChild(child){
		this.carousel.appendChild(child);
		this.tiles.push(child);
		var pageIndex = Math.floor(this.totalNoOfTiles/this.totalTilesPerPage),
			relativeTileIndex = this.totalNoOfTiles%this.totalTilesPerPage,
			rowIndex = Math.floor(relativeTileIndex/this.noOfTilesPerWidth),
			colIndex = relativeTileIndex%this.noOfTilesPerWidth + pageIndex*this.noOfTilesPerWidth,
			updatedNoOfPages;
		child.style.position = "absolute";
		child.style.width = this.tileWidth - 2*this.margin + "px";
		child.style.height = this.tileHeight - 2*this.margin + "px";
		child.style.margin = this.margin + "px";
		child.style.top = rowIndex*this.tileHeight + "px";
		child.style.left = colIndex*this.tileWidth + "px";
		this.carouselWidth += getOuterWidth(child);
		this.carousel.style.width = this.carouselWidth + "px";
		this.totalNoOfTiles += 1;
		updatedNoOfPages = Math.ceil(this.totalNoOfTiles/this.totalTilesPerPage);
		if(updatedNoOfPages != this.noOfPages){
			this.paginationDots && this.paginDotArray && _addPaginationDot.call(this,this.noOfPages);
			this.noOfPages = updatedNoOfPages;
		}
		if((this.noOfPages>1)&&this.paginationDots && !this.paginDotArray){
			_createPaginationDots.call(this);
		}
		this.moveToPageId(this.noOfPages-1);
	}

	function _addPaginationDot(index){
		var newDot = document.createElement('div');
		newDot.classList.add('pagination-dot-wrapper');
		newDot.innerHTML = '<div class="pagination-dot"></div>';
		newDot.id = "paginDot"+index;
		newDot.style.height = this.noOfTilesPerHeight*this.tileHeight*0.07 + 'px';
		newDot.style.width = newDot.style.height;
		newDot.childNodes[0].style.height = Math.floor(parseFloat(newDot.style.height)*0.175) + 'px';
		newDot.childNodes[0].style.width = newDot.childNodes[0].style.height;
		newDot.childNodes[0].style.minHeight = '7px';
		newDot.childNodes[0].style.minWidth = '7px';
		this.paginDotArray.push(newDot);
		this.paginDotsContainer.appendChild(newDot);
		newDot.addEventListener('click',function(e){
			e.stopPropagation();
			var targetId = parseInt(e.currentTarget.id.match(/\d+/g));
			/*for(var i=0, l = this.paginDotArray.length ; i < l; i += 1){
				this.paginDotArray[i].childNodes[0].classList.remove('pagination-dot-active');
			}
			this.paginDotArray[targetId].childNodes[0].classList.add('pagination-dot-active');*/
			this.moveToPageId(targetId);
		}.bind(this));
	}

	function getOuterWidth(el){
		  var width = el.offsetWidth;
		  var style = getComputedStyle(el);

		  width += parseInt(style.marginLeft) + parseInt(style.marginRight);
		  return width;
	}
	
	return Carousel;
});;define('CirclePointer', ['SoModel', 'EventHandler'], function(SoModel, eventHandler) {

    /**
     * Creates an instance of CirclePointer.
     * Passing parent and name of the circle is mandatory to create a CirclePointer
     * A key named classes can be passes inside options object, accordingly classes would be applied on the CirclePointer
     * Initial Data of the CirclePointer can be passed as the key named data
     * if circle has to be snapped to grid intersections pass snapToGrid as true
     * You can choose whether to show the pointer on the screen or not Pass pointer is true if you need a circle Pointer
     * @constructor CirclePointer
     * @param {object} options for CirclePointer
     * @this {CirclePointer}
     *
     * @example
     *  var circle = Graph.CreateCirclePointer({name:'CirclePointer',parent:graph2,pointer:true,snapToGrid:false,classes:['myclass1','myclass2'],isDraggable:true})
     */
	
	// the following is a Polyfill used to support older SVG methods in latest browsers.
	
	// SVGPathSeg API polyfill
	// https://github.com/progers/pathseg
	//
	// This is a drop-in replacement for the SVGPathSeg and SVGPathSegList APIs that were removed from
	// SVG2 (https://lists.w3.org/Archives/Public/www-svg/2015Jun/0044.html), including the latest spec
	// changes which were implemented in Firefox 43 and Chrome 46.

	(function() { "use strict";
	    if (!("SVGPathSeg" in window)) {
	        // Spec: http://www.w3.org/TR/SVG11/single-page.html#paths-InterfaceSVGPathSeg
	        window.SVGPathSeg = function(type, typeAsLetter, owningPathSegList) {
	            this.pathSegType = type;
	            this.pathSegTypeAsLetter = typeAsLetter;
	            this._owningPathSegList = owningPathSegList;
	        }

	        SVGPathSeg.PATHSEG_UNKNOWN = 0;
	        SVGPathSeg.PATHSEG_CLOSEPATH = 1;
	        SVGPathSeg.PATHSEG_MOVETO_ABS = 2;
	        SVGPathSeg.PATHSEG_MOVETO_REL = 3;
	        SVGPathSeg.PATHSEG_LINETO_ABS = 4;
	        SVGPathSeg.PATHSEG_LINETO_REL = 5;
	        SVGPathSeg.PATHSEG_CURVETO_CUBIC_ABS = 6;
	        SVGPathSeg.PATHSEG_CURVETO_CUBIC_REL = 7;
	        SVGPathSeg.PATHSEG_CURVETO_QUADRATIC_ABS = 8;
	        SVGPathSeg.PATHSEG_CURVETO_QUADRATIC_REL = 9;
	        SVGPathSeg.PATHSEG_ARC_ABS = 10;
	        SVGPathSeg.PATHSEG_ARC_REL = 11;
	        SVGPathSeg.PATHSEG_LINETO_HORIZONTAL_ABS = 12;
	        SVGPathSeg.PATHSEG_LINETO_HORIZONTAL_REL = 13;
	        SVGPathSeg.PATHSEG_LINETO_VERTICAL_ABS = 14;
	        SVGPathSeg.PATHSEG_LINETO_VERTICAL_REL = 15;
	        SVGPathSeg.PATHSEG_CURVETO_CUBIC_SMOOTH_ABS = 16;
	        SVGPathSeg.PATHSEG_CURVETO_CUBIC_SMOOTH_REL = 17;
	        SVGPathSeg.PATHSEG_CURVETO_QUADRATIC_SMOOTH_ABS = 18;
	        SVGPathSeg.PATHSEG_CURVETO_QUADRATIC_SMOOTH_REL = 19;

	        // Notify owning PathSegList on any changes so they can be synchronized back to the path element.
	        SVGPathSeg.prototype._segmentChanged = function() {
	            if (this._owningPathSegList)
	                this._owningPathSegList.segmentChanged(this);
	        }

	        window.SVGPathSegClosePath = function(owningPathSegList) {
	            SVGPathSeg.call(this, SVGPathSeg.PATHSEG_CLOSEPATH, "z", owningPathSegList);
	        }
	        SVGPathSegClosePath.prototype = Object.create(SVGPathSeg.prototype);
	        SVGPathSegClosePath.prototype.toString = function() { return "[object SVGPathSegClosePath]"; }
	        SVGPathSegClosePath.prototype._asPathString = function() { return this.pathSegTypeAsLetter; }
	        SVGPathSegClosePath.prototype.clone = function() { return new SVGPathSegClosePath(undefined); }

	        window.SVGPathSegMovetoAbs = function(owningPathSegList, x, y) {
	            SVGPathSeg.call(this, SVGPathSeg.PATHSEG_MOVETO_ABS, "M", owningPathSegList);
	            this._x = x;
	            this._y = y;
	        }
	        SVGPathSegMovetoAbs.prototype = Object.create(SVGPathSeg.prototype);
	        SVGPathSegMovetoAbs.prototype.toString = function() { return "[object SVGPathSegMovetoAbs]"; }
	        SVGPathSegMovetoAbs.prototype._asPathString = function() { return this.pathSegTypeAsLetter + " " + this._x + " " + this._y; }
	        SVGPathSegMovetoAbs.prototype.clone = function() { return new SVGPathSegMovetoAbs(undefined, this._x, this._y); }
	        Object.defineProperty(SVGPathSegMovetoAbs.prototype, "x", { get: function() { return this._x; }, set: function(x) { this._x = x; this._segmentChanged(); }, enumerable: true });
	        Object.defineProperty(SVGPathSegMovetoAbs.prototype, "y", { get: function() { return this._y; }, set: function(y) { this._y = y; this._segmentChanged(); }, enumerable: true });

	        window.SVGPathSegMovetoRel = function(owningPathSegList, x, y) {
	            SVGPathSeg.call(this, SVGPathSeg.PATHSEG_MOVETO_REL, "m", owningPathSegList);
	            this._x = x;
	            this._y = y;
	        }
	        SVGPathSegMovetoRel.prototype = Object.create(SVGPathSeg.prototype);
	        SVGPathSegMovetoRel.prototype.toString = function() { return "[object SVGPathSegMovetoRel]"; }
	        SVGPathSegMovetoRel.prototype._asPathString = function() { return this.pathSegTypeAsLetter + " " + this._x + " " + this._y; }
	        SVGPathSegMovetoRel.prototype.clone = function() { return new SVGPathSegMovetoRel(undefined, this._x, this._y); }
	        Object.defineProperty(SVGPathSegMovetoRel.prototype, "x", { get: function() { return this._x; }, set: function(x) { this._x = x; this._segmentChanged(); }, enumerable: true });
	        Object.defineProperty(SVGPathSegMovetoRel.prototype, "y", { get: function() { return this._y; }, set: function(y) { this._y = y; this._segmentChanged(); }, enumerable: true });

	        window.SVGPathSegLinetoAbs = function(owningPathSegList, x, y) {
	            SVGPathSeg.call(this, SVGPathSeg.PATHSEG_LINETO_ABS, "L", owningPathSegList);
	            this._x = x;
	            this._y = y;
	        }
	        SVGPathSegLinetoAbs.prototype = Object.create(SVGPathSeg.prototype);
	        SVGPathSegLinetoAbs.prototype.toString = function() { return "[object SVGPathSegLinetoAbs]"; }
	        SVGPathSegLinetoAbs.prototype._asPathString = function() { return this.pathSegTypeAsLetter + " " + this._x + " " + this._y; }
	        SVGPathSegLinetoAbs.prototype.clone = function() { return new SVGPathSegLinetoAbs(undefined, this._x, this._y); }
	        Object.defineProperty(SVGPathSegLinetoAbs.prototype, "x", { get: function() { return this._x; }, set: function(x) { this._x = x; this._segmentChanged(); }, enumerable: true });
	        Object.defineProperty(SVGPathSegLinetoAbs.prototype, "y", { get: function() { return this._y; }, set: function(y) { this._y = y; this._segmentChanged(); }, enumerable: true });

	        window.SVGPathSegLinetoRel = function(owningPathSegList, x, y) {
	            SVGPathSeg.call(this, SVGPathSeg.PATHSEG_LINETO_REL, "l", owningPathSegList);
	            this._x = x;
	            this._y = y;
	        }
	        SVGPathSegLinetoRel.prototype = Object.create(SVGPathSeg.prototype);
	        SVGPathSegLinetoRel.prototype.toString = function() { return "[object SVGPathSegLinetoRel]"; }
	        SVGPathSegLinetoRel.prototype._asPathString = function() { return this.pathSegTypeAsLetter + " " + this._x + " " + this._y; }
	        SVGPathSegLinetoRel.prototype.clone = function() { return new SVGPathSegLinetoRel(undefined, this._x, this._y); }
	        Object.defineProperty(SVGPathSegLinetoRel.prototype, "x", { get: function() { return this._x; }, set: function(x) { this._x = x; this._segmentChanged(); }, enumerable: true });
	        Object.defineProperty(SVGPathSegLinetoRel.prototype, "y", { get: function() { return this._y; }, set: function(y) { this._y = y; this._segmentChanged(); }, enumerable: true });

	        window.SVGPathSegCurvetoCubicAbs = function(owningPathSegList, x, y, x1, y1, x2, y2) {
	            SVGPathSeg.call(this, SVGPathSeg.PATHSEG_CURVETO_CUBIC_ABS, "C", owningPathSegList);
	            this._x = x;
	            this._y = y;
	            this._x1 = x1;
	            this._y1 = y1;
	            this._x2 = x2;
	            this._y2 = y2;
	        }
	        SVGPathSegCurvetoCubicAbs.prototype = Object.create(SVGPathSeg.prototype);
	        SVGPathSegCurvetoCubicAbs.prototype.toString = function() { return "[object SVGPathSegCurvetoCubicAbs]"; }
	        SVGPathSegCurvetoCubicAbs.prototype._asPathString = function() { return this.pathSegTypeAsLetter + " " + this._x1 + " " + this._y1 + " " + this._x2 + " " + this._y2 + " " + this._x + " " + this._y; }
	        SVGPathSegCurvetoCubicAbs.prototype.clone = function() { return new SVGPathSegCurvetoCubicAbs(undefined, this._x, this._y, this._x1, this._y1, this._x2, this._y2); }
	        Object.defineProperty(SVGPathSegCurvetoCubicAbs.prototype, "x", { get: function() { return this._x; }, set: function(x) { this._x = x; this._segmentChanged(); }, enumerable: true });
	        Object.defineProperty(SVGPathSegCurvetoCubicAbs.prototype, "y", { get: function() { return this._y; }, set: function(y) { this._y = y; this._segmentChanged(); }, enumerable: true });
	        Object.defineProperty(SVGPathSegCurvetoCubicAbs.prototype, "x1", { get: function() { return this._x1; }, set: function(x1) { this._x1 = x1; this._segmentChanged(); }, enumerable: true });
	        Object.defineProperty(SVGPathSegCurvetoCubicAbs.prototype, "y1", { get: function() { return this._y1; }, set: function(y1) { this._y1 = y1; this._segmentChanged(); }, enumerable: true });
	        Object.defineProperty(SVGPathSegCurvetoCubicAbs.prototype, "x2", { get: function() { return this._x2; }, set: function(x2) { this._x2 = x2; this._segmentChanged(); }, enumerable: true });
	        Object.defineProperty(SVGPathSegCurvetoCubicAbs.prototype, "y2", { get: function() { return this._y2; }, set: function(y2) { this._y2 = y2; this._segmentChanged(); }, enumerable: true });

	        window.SVGPathSegCurvetoCubicRel = function(owningPathSegList, x, y, x1, y1, x2, y2) {
	            SVGPathSeg.call(this, SVGPathSeg.PATHSEG_CURVETO_CUBIC_REL, "c", owningPathSegList);
	            this._x = x;
	            this._y = y;
	            this._x1 = x1;
	            this._y1 = y1;
	            this._x2 = x2;
	            this._y2 = y2;
	        }
	        SVGPathSegCurvetoCubicRel.prototype = Object.create(SVGPathSeg.prototype);
	        SVGPathSegCurvetoCubicRel.prototype.toString = function() { return "[object SVGPathSegCurvetoCubicRel]"; }
	        SVGPathSegCurvetoCubicRel.prototype._asPathString = function() { return this.pathSegTypeAsLetter + " " + this._x1 + " " + this._y1 + " " + this._x2 + " " + this._y2 + " " + this._x + " " + this._y; }
	        SVGPathSegCurvetoCubicRel.prototype.clone = function() { return new SVGPathSegCurvetoCubicRel(undefined, this._x, this._y, this._x1, this._y1, this._x2, this._y2); }
	        Object.defineProperty(SVGPathSegCurvetoCubicRel.prototype, "x", { get: function() { return this._x; }, set: function(x) { this._x = x; this._segmentChanged(); }, enumerable: true });
	        Object.defineProperty(SVGPathSegCurvetoCubicRel.prototype, "y", { get: function() { return this._y; }, set: function(y) { this._y = y; this._segmentChanged(); }, enumerable: true });
	        Object.defineProperty(SVGPathSegCurvetoCubicRel.prototype, "x1", { get: function() { return this._x1; }, set: function(x1) { this._x1 = x1; this._segmentChanged(); }, enumerable: true });
	        Object.defineProperty(SVGPathSegCurvetoCubicRel.prototype, "y1", { get: function() { return this._y1; }, set: function(y1) { this._y1 = y1; this._segmentChanged(); }, enumerable: true });
	        Object.defineProperty(SVGPathSegCurvetoCubicRel.prototype, "x2", { get: function() { return this._x2; }, set: function(x2) { this._x2 = x2; this._segmentChanged(); }, enumerable: true });
	        Object.defineProperty(SVGPathSegCurvetoCubicRel.prototype, "y2", { get: function() { return this._y2; }, set: function(y2) { this._y2 = y2; this._segmentChanged(); }, enumerable: true });

	        window.SVGPathSegCurvetoQuadraticAbs = function(owningPathSegList, x, y, x1, y1) {
	            SVGPathSeg.call(this, SVGPathSeg.PATHSEG_CURVETO_QUADRATIC_ABS, "Q", owningPathSegList);
	            this._x = x;
	            this._y = y;
	            this._x1 = x1;
	            this._y1 = y1;
	        }
	        SVGPathSegCurvetoQuadraticAbs.prototype = Object.create(SVGPathSeg.prototype);
	        SVGPathSegCurvetoQuadraticAbs.prototype.toString = function() { return "[object SVGPathSegCurvetoQuadraticAbs]"; }
	        SVGPathSegCurvetoQuadraticAbs.prototype._asPathString = function() { return this.pathSegTypeAsLetter + " " + this._x1 + " " + this._y1 + " " + this._x + " " + this._y; }
	        SVGPathSegCurvetoQuadraticAbs.prototype.clone = function() { return new SVGPathSegCurvetoQuadraticAbs(undefined, this._x, this._y, this._x1, this._y1); }
	        Object.defineProperty(SVGPathSegCurvetoQuadraticAbs.prototype, "x", { get: function() { return this._x; }, set: function(x) { this._x = x; this._segmentChanged(); }, enumerable: true });
	        Object.defineProperty(SVGPathSegCurvetoQuadraticAbs.prototype, "y", { get: function() { return this._y; }, set: function(y) { this._y = y; this._segmentChanged(); }, enumerable: true });
	        Object.defineProperty(SVGPathSegCurvetoQuadraticAbs.prototype, "x1", { get: function() { return this._x1; }, set: function(x1) { this._x1 = x1; this._segmentChanged(); }, enumerable: true });
	        Object.defineProperty(SVGPathSegCurvetoQuadraticAbs.prototype, "y1", { get: function() { return this._y1; }, set: function(y1) { this._y1 = y1; this._segmentChanged(); }, enumerable: true });

	        window.SVGPathSegCurvetoQuadraticRel = function(owningPathSegList, x, y, x1, y1) {
	            SVGPathSeg.call(this, SVGPathSeg.PATHSEG_CURVETO_QUADRATIC_REL, "q", owningPathSegList);
	            this._x = x;
	            this._y = y;
	            this._x1 = x1;
	            this._y1 = y1;
	        }
	        SVGPathSegCurvetoQuadraticRel.prototype = Object.create(SVGPathSeg.prototype);
	        SVGPathSegCurvetoQuadraticRel.prototype.toString = function() { return "[object SVGPathSegCurvetoQuadraticRel]"; }
	        SVGPathSegCurvetoQuadraticRel.prototype._asPathString = function() { return this.pathSegTypeAsLetter + " " + this._x1 + " " + this._y1 + " " + this._x + " " + this._y; }
	        SVGPathSegCurvetoQuadraticRel.prototype.clone = function() { return new SVGPathSegCurvetoQuadraticRel(undefined, this._x, this._y, this._x1, this._y1); }
	        Object.defineProperty(SVGPathSegCurvetoQuadraticRel.prototype, "x", { get: function() { return this._x; }, set: function(x) { this._x = x; this._segmentChanged(); }, enumerable: true });
	        Object.defineProperty(SVGPathSegCurvetoQuadraticRel.prototype, "y", { get: function() { return this._y; }, set: function(y) { this._y = y; this._segmentChanged(); }, enumerable: true });
	        Object.defineProperty(SVGPathSegCurvetoQuadraticRel.prototype, "x1", { get: function() { return this._x1; }, set: function(x1) { this._x1 = x1; this._segmentChanged(); }, enumerable: true });
	        Object.defineProperty(SVGPathSegCurvetoQuadraticRel.prototype, "y1", { get: function() { return this._y1; }, set: function(y1) { this._y1 = y1; this._segmentChanged(); }, enumerable: true });

	        window.SVGPathSegArcAbs = function(owningPathSegList, x, y, r1, r2, angle, largeArcFlag, sweepFlag) {
	            SVGPathSeg.call(this, SVGPathSeg.PATHSEG_ARC_ABS, "A", owningPathSegList);
	            this._x = x;
	            this._y = y;
	            this._r1 = r1;
	            this._r2 = r2;
	            this._angle = angle;
	            this._largeArcFlag = largeArcFlag;
	            this._sweepFlag = sweepFlag;
	        }
	        SVGPathSegArcAbs.prototype = Object.create(SVGPathSeg.prototype);
	        SVGPathSegArcAbs.prototype.toString = function() { return "[object SVGPathSegArcAbs]"; }
	        SVGPathSegArcAbs.prototype._asPathString = function() { return this.pathSegTypeAsLetter + " " + this._r1 + " " + this._r2 + " " + this._angle + " " + (this._largeArcFlag ? "1" : "0") + " " + (this._sweepFlag ? "1" : "0") + " " + this._x + " " + this._y; }
	        SVGPathSegArcAbs.prototype.clone = function() { return new SVGPathSegArcAbs(undefined, this._x, this._y, this._r1, this._r2, this._angle, this._largeArcFlag, this._sweepFlag); }
	        Object.defineProperty(SVGPathSegArcAbs.prototype, "x", { get: function() { return this._x; }, set: function(x) { this._x = x; this._segmentChanged(); }, enumerable: true });
	        Object.defineProperty(SVGPathSegArcAbs.prototype, "y", { get: function() { return this._y; }, set: function(y) { this._y = y; this._segmentChanged(); }, enumerable: true });
	        Object.defineProperty(SVGPathSegArcAbs.prototype, "r1", { get: function() { return this._r1; }, set: function(r1) { this._r1 = r1; this._segmentChanged(); }, enumerable: true });
	        Object.defineProperty(SVGPathSegArcAbs.prototype, "r2", { get: function() { return this._r2; }, set: function(r2) { this._r2 = r2; this._segmentChanged(); }, enumerable: true });
	        Object.defineProperty(SVGPathSegArcAbs.prototype, "angle", { get: function() { return this._angle; }, set: function(angle) { this._angle = angle; this._segmentChanged(); }, enumerable: true });
	        Object.defineProperty(SVGPathSegArcAbs.prototype, "largeArcFlag", { get: function() { return this._largeArcFlag; }, set: function(largeArcFlag) { this._largeArcFlag = largeArcFlag; this._segmentChanged(); }, enumerable: true });
	        Object.defineProperty(SVGPathSegArcAbs.prototype, "sweepFlag", { get: function() { return this._sweepFlag; }, set: function(sweepFlag) { this._sweepFlag = sweepFlag; this._segmentChanged(); }, enumerable: true });

	        window.SVGPathSegArcRel = function(owningPathSegList, x, y, r1, r2, angle, largeArcFlag, sweepFlag) {
	            SVGPathSeg.call(this, SVGPathSeg.PATHSEG_ARC_REL, "a", owningPathSegList);
	            this._x = x;
	            this._y = y;
	            this._r1 = r1;
	            this._r2 = r2;
	            this._angle = angle;
	            this._largeArcFlag = largeArcFlag;
	            this._sweepFlag = sweepFlag;
	        }
	        SVGPathSegArcRel.prototype = Object.create(SVGPathSeg.prototype);
	        SVGPathSegArcRel.prototype.toString = function() { return "[object SVGPathSegArcRel]"; }
	        SVGPathSegArcRel.prototype._asPathString = function() { return this.pathSegTypeAsLetter + " " + this._r1 + " " + this._r2 + " " + this._angle + " " + (this._largeArcFlag ? "1" : "0") + " " + (this._sweepFlag ? "1" : "0") + " " + this._x + " " + this._y; }
	        SVGPathSegArcRel.prototype.clone = function() { return new SVGPathSegArcRel(undefined, this._x, this._y, this._r1, this._r2, this._angle, this._largeArcFlag, this._sweepFlag); }
	        Object.defineProperty(SVGPathSegArcRel.prototype, "x", { get: function() { return this._x; }, set: function(x) { this._x = x; this._segmentChanged(); }, enumerable: true });
	        Object.defineProperty(SVGPathSegArcRel.prototype, "y", { get: function() { return this._y; }, set: function(y) { this._y = y; this._segmentChanged(); }, enumerable: true });
	        Object.defineProperty(SVGPathSegArcRel.prototype, "r1", { get: function() { return this._r1; }, set: function(r1) { this._r1 = r1; this._segmentChanged(); }, enumerable: true });
	        Object.defineProperty(SVGPathSegArcRel.prototype, "r2", { get: function() { return this._r2; }, set: function(r2) { this._r2 = r2; this._segmentChanged(); }, enumerable: true });
	        Object.defineProperty(SVGPathSegArcRel.prototype, "angle", { get: function() { return this._angle; }, set: function(angle) { this._angle = angle; this._segmentChanged(); }, enumerable: true });
	        Object.defineProperty(SVGPathSegArcRel.prototype, "largeArcFlag", { get: function() { return this._largeArcFlag; }, set: function(largeArcFlag) { this._largeArcFlag = largeArcFlag; this._segmentChanged(); }, enumerable: true });
	        Object.defineProperty(SVGPathSegArcRel.prototype, "sweepFlag", { get: function() { return this._sweepFlag; }, set: function(sweepFlag) { this._sweepFlag = sweepFlag; this._segmentChanged(); }, enumerable: true });

	        window.SVGPathSegLinetoHorizontalAbs = function(owningPathSegList, x) {
	            SVGPathSeg.call(this, SVGPathSeg.PATHSEG_LINETO_HORIZONTAL_ABS, "H", owningPathSegList);
	            this._x = x;
	        }
	        SVGPathSegLinetoHorizontalAbs.prototype = Object.create(SVGPathSeg.prototype);
	        SVGPathSegLinetoHorizontalAbs.prototype.toString = function() { return "[object SVGPathSegLinetoHorizontalAbs]"; }
	        SVGPathSegLinetoHorizontalAbs.prototype._asPathString = function() { return this.pathSegTypeAsLetter + " " + this._x; }
	        SVGPathSegLinetoHorizontalAbs.prototype.clone = function() { return new SVGPathSegLinetoHorizontalAbs(undefined, this._x); }
	        Object.defineProperty(SVGPathSegLinetoHorizontalAbs.prototype, "x", { get: function() { return this._x; }, set: function(x) { this._x = x; this._segmentChanged(); }, enumerable: true });

	        window.SVGPathSegLinetoHorizontalRel = function(owningPathSegList, x) {
	            SVGPathSeg.call(this, SVGPathSeg.PATHSEG_LINETO_HORIZONTAL_REL, "h", owningPathSegList);
	            this._x = x;
	        }
	        SVGPathSegLinetoHorizontalRel.prototype = Object.create(SVGPathSeg.prototype);
	        SVGPathSegLinetoHorizontalRel.prototype.toString = function() { return "[object SVGPathSegLinetoHorizontalRel]"; }
	        SVGPathSegLinetoHorizontalRel.prototype._asPathString = function() { return this.pathSegTypeAsLetter + " " + this._x; }
	        SVGPathSegLinetoHorizontalRel.prototype.clone = function() { return new SVGPathSegLinetoHorizontalRel(undefined, this._x); }
	        Object.defineProperty(SVGPathSegLinetoHorizontalRel.prototype, "x", { get: function() { return this._x; }, set: function(x) { this._x = x; this._segmentChanged(); }, enumerable: true });

	        window.SVGPathSegLinetoVerticalAbs = function(owningPathSegList, y) {
	            SVGPathSeg.call(this, SVGPathSeg.PATHSEG_LINETO_VERTICAL_ABS, "V", owningPathSegList);
	            this._y = y;
	        }
	        SVGPathSegLinetoVerticalAbs.prototype = Object.create(SVGPathSeg.prototype);
	        SVGPathSegLinetoVerticalAbs.prototype.toString = function() { return "[object SVGPathSegLinetoVerticalAbs]"; }
	        SVGPathSegLinetoVerticalAbs.prototype._asPathString = function() { return this.pathSegTypeAsLetter + " " + this._y; }
	        SVGPathSegLinetoVerticalAbs.prototype.clone = function() { return new SVGPathSegLinetoVerticalAbs(undefined, this._y); }
	        Object.defineProperty(SVGPathSegLinetoVerticalAbs.prototype, "y", { get: function() { return this._y; }, set: function(y) { this._y = y; this._segmentChanged(); }, enumerable: true });

	        window.SVGPathSegLinetoVerticalRel = function(owningPathSegList, y) {
	            SVGPathSeg.call(this, SVGPathSeg.PATHSEG_LINETO_VERTICAL_REL, "v", owningPathSegList);
	            this._y = y;
	        }
	        SVGPathSegLinetoVerticalRel.prototype = Object.create(SVGPathSeg.prototype);
	        SVGPathSegLinetoVerticalRel.prototype.toString = function() { return "[object SVGPathSegLinetoVerticalRel]"; }
	        SVGPathSegLinetoVerticalRel.prototype._asPathString = function() { return this.pathSegTypeAsLetter + " " + this._y; }
	        SVGPathSegLinetoVerticalRel.prototype.clone = function() { return new SVGPathSegLinetoVerticalRel(undefined, this._y); }
	        Object.defineProperty(SVGPathSegLinetoVerticalRel.prototype, "y", { get: function() { return this._y; }, set: function(y) { this._y = y; this._segmentChanged(); }, enumerable: true });

	        window.SVGPathSegCurvetoCubicSmoothAbs = function(owningPathSegList, x, y, x2, y2) {
	            SVGPathSeg.call(this, SVGPathSeg.PATHSEG_CURVETO_CUBIC_SMOOTH_ABS, "S", owningPathSegList);
	            this._x = x;
	            this._y = y;
	            this._x2 = x2;
	            this._y2 = y2;
	        }
	        SVGPathSegCurvetoCubicSmoothAbs.prototype = Object.create(SVGPathSeg.prototype);
	        SVGPathSegCurvetoCubicSmoothAbs.prototype.toString = function() { return "[object SVGPathSegCurvetoCubicSmoothAbs]"; }
	        SVGPathSegCurvetoCubicSmoothAbs.prototype._asPathString = function() { return this.pathSegTypeAsLetter + " " + this._x2 + " " + this._y2 + " " + this._x + " " + this._y; }
	        SVGPathSegCurvetoCubicSmoothAbs.prototype.clone = function() { return new SVGPathSegCurvetoCubicSmoothAbs(undefined, this._x, this._y, this._x2, this._y2); }
	        Object.defineProperty(SVGPathSegCurvetoCubicSmoothAbs.prototype, "x", { get: function() { return this._x; }, set: function(x) { this._x = x; this._segmentChanged(); }, enumerable: true });
	        Object.defineProperty(SVGPathSegCurvetoCubicSmoothAbs.prototype, "y", { get: function() { return this._y; }, set: function(y) { this._y = y; this._segmentChanged(); }, enumerable: true });
	        Object.defineProperty(SVGPathSegCurvetoCubicSmoothAbs.prototype, "x2", { get: function() { return this._x2; }, set: function(x2) { this._x2 = x2; this._segmentChanged(); }, enumerable: true });
	        Object.defineProperty(SVGPathSegCurvetoCubicSmoothAbs.prototype, "y2", { get: function() { return this._y2; }, set: function(y2) { this._y2 = y2; this._segmentChanged(); }, enumerable: true });

	        window.SVGPathSegCurvetoCubicSmoothRel = function(owningPathSegList, x, y, x2, y2) {
	            SVGPathSeg.call(this, SVGPathSeg.PATHSEG_CURVETO_CUBIC_SMOOTH_REL, "s", owningPathSegList);
	            this._x = x;
	            this._y = y;
	            this._x2 = x2;
	            this._y2 = y2;
	        }
	        SVGPathSegCurvetoCubicSmoothRel.prototype = Object.create(SVGPathSeg.prototype);
	        SVGPathSegCurvetoCubicSmoothRel.prototype.toString = function() { return "[object SVGPathSegCurvetoCubicSmoothRel]"; }
	        SVGPathSegCurvetoCubicSmoothRel.prototype._asPathString = function() { return this.pathSegTypeAsLetter + " " + this._x2 + " " + this._y2 + " " + this._x + " " + this._y; }
	        SVGPathSegCurvetoCubicSmoothRel.prototype.clone = function() { return new SVGPathSegCurvetoCubicSmoothRel(undefined, this._x, this._y, this._x2, this._y2); }
	        Object.defineProperty(SVGPathSegCurvetoCubicSmoothRel.prototype, "x", { get: function() { return this._x; }, set: function(x) { this._x = x; this._segmentChanged(); }, enumerable: true });
	        Object.defineProperty(SVGPathSegCurvetoCubicSmoothRel.prototype, "y", { get: function() { return this._y; }, set: function(y) { this._y = y; this._segmentChanged(); }, enumerable: true });
	        Object.defineProperty(SVGPathSegCurvetoCubicSmoothRel.prototype, "x2", { get: function() { return this._x2; }, set: function(x2) { this._x2 = x2; this._segmentChanged(); }, enumerable: true });
	        Object.defineProperty(SVGPathSegCurvetoCubicSmoothRel.prototype, "y2", { get: function() { return this._y2; }, set: function(y2) { this._y2 = y2; this._segmentChanged(); }, enumerable: true });

	        window.SVGPathSegCurvetoQuadraticSmoothAbs = function(owningPathSegList, x, y) {
	            SVGPathSeg.call(this, SVGPathSeg.PATHSEG_CURVETO_QUADRATIC_SMOOTH_ABS, "T", owningPathSegList);
	            this._x = x;
	            this._y = y;
	        }
	        SVGPathSegCurvetoQuadraticSmoothAbs.prototype = Object.create(SVGPathSeg.prototype);
	        SVGPathSegCurvetoQuadraticSmoothAbs.prototype.toString = function() { return "[object SVGPathSegCurvetoQuadraticSmoothAbs]"; }
	        SVGPathSegCurvetoQuadraticSmoothAbs.prototype._asPathString = function() { return this.pathSegTypeAsLetter + " " + this._x + " " + this._y; }
	        SVGPathSegCurvetoQuadraticSmoothAbs.prototype.clone = function() { return new SVGPathSegCurvetoQuadraticSmoothAbs(undefined, this._x, this._y); }
	        Object.defineProperty(SVGPathSegCurvetoQuadraticSmoothAbs.prototype, "x", { get: function() { return this._x; }, set: function(x) { this._x = x; this._segmentChanged(); }, enumerable: true });
	        Object.defineProperty(SVGPathSegCurvetoQuadraticSmoothAbs.prototype, "y", { get: function() { return this._y; }, set: function(y) { this._y = y; this._segmentChanged(); }, enumerable: true });

	        window.SVGPathSegCurvetoQuadraticSmoothRel = function(owningPathSegList, x, y) {
	            SVGPathSeg.call(this, SVGPathSeg.PATHSEG_CURVETO_QUADRATIC_SMOOTH_REL, "t", owningPathSegList);
	            this._x = x;
	            this._y = y;
	        }
	        SVGPathSegCurvetoQuadraticSmoothRel.prototype = Object.create(SVGPathSeg.prototype);
	        SVGPathSegCurvetoQuadraticSmoothRel.prototype.toString = function() { return "[object SVGPathSegCurvetoQuadraticSmoothRel]"; }
	        SVGPathSegCurvetoQuadraticSmoothRel.prototype._asPathString = function() { return this.pathSegTypeAsLetter + " " + this._x + " " + this._y; }
	        SVGPathSegCurvetoQuadraticSmoothRel.prototype.clone = function() { return new SVGPathSegCurvetoQuadraticSmoothRel(undefined, this._x, this._y); }
	        Object.defineProperty(SVGPathSegCurvetoQuadraticSmoothRel.prototype, "x", { get: function() { return this._x; }, set: function(x) { this._x = x; this._segmentChanged(); }, enumerable: true });
	        Object.defineProperty(SVGPathSegCurvetoQuadraticSmoothRel.prototype, "y", { get: function() { return this._y; }, set: function(y) { this._y = y; this._segmentChanged(); }, enumerable: true });

	        // Add createSVGPathSeg* functions to SVGPathElement.
	        // Spec: http://www.w3.org/TR/SVG11/single-page.html#paths-InterfaceSVGPathElement.
	        SVGPathElement.prototype.createSVGPathSegClosePath = function() { return new SVGPathSegClosePath(undefined); }
	        SVGPathElement.prototype.createSVGPathSegMovetoAbs = function(x, y) { return new SVGPathSegMovetoAbs(undefined, x, y); }
	        SVGPathElement.prototype.createSVGPathSegMovetoRel = function(x, y) { return new SVGPathSegMovetoRel(undefined, x, y); }
	        SVGPathElement.prototype.createSVGPathSegLinetoAbs = function(x, y) { return new SVGPathSegLinetoAbs(undefined, x, y); }
	        SVGPathElement.prototype.createSVGPathSegLinetoRel = function(x, y) { return new SVGPathSegLinetoRel(undefined, x, y); }
	        SVGPathElement.prototype.createSVGPathSegCurvetoCubicAbs = function(x, y, x1, y1, x2, y2) { return new SVGPathSegCurvetoCubicAbs(undefined, x, y, x1, y1, x2, y2); }
	        SVGPathElement.prototype.createSVGPathSegCurvetoCubicRel = function(x, y, x1, y1, x2, y2) { return new SVGPathSegCurvetoCubicRel(undefined, x, y, x1, y1, x2, y2); }
	        SVGPathElement.prototype.createSVGPathSegCurvetoQuadraticAbs = function(x, y, x1, y1) { return new SVGPathSegCurvetoQuadraticAbs(undefined, x, y, x1, y1); }
	        SVGPathElement.prototype.createSVGPathSegCurvetoQuadraticRel = function(x, y, x1, y1) { return new SVGPathSegCurvetoQuadraticRel(undefined, x, y, x1, y1); }
	        SVGPathElement.prototype.createSVGPathSegArcAbs = function(x, y, r1, r2, angle, largeArcFlag, sweepFlag) { return new SVGPathSegArcAbs(undefined, x, y, r1, r2, angle, largeArcFlag, sweepFlag); }
	        SVGPathElement.prototype.createSVGPathSegArcRel = function(x, y, r1, r2, angle, largeArcFlag, sweepFlag) { return new SVGPathSegArcRel(undefined, x, y, r1, r2, angle, largeArcFlag, sweepFlag); }
	        SVGPathElement.prototype.createSVGPathSegLinetoHorizontalAbs = function(x) { return new SVGPathSegLinetoHorizontalAbs(undefined, x); }
	        SVGPathElement.prototype.createSVGPathSegLinetoHorizontalRel = function(x) { return new SVGPathSegLinetoHorizontalRel(undefined, x); }
	        SVGPathElement.prototype.createSVGPathSegLinetoVerticalAbs = function(y) { return new SVGPathSegLinetoVerticalAbs(undefined, y); }
	        SVGPathElement.prototype.createSVGPathSegLinetoVerticalRel = function(y) { return new SVGPathSegLinetoVerticalRel(undefined, y); }
	        SVGPathElement.prototype.createSVGPathSegCurvetoCubicSmoothAbs = function(x, y, x2, y2) { return new SVGPathSegCurvetoCubicSmoothAbs(undefined, x, y, x2, y2); }
	        SVGPathElement.prototype.createSVGPathSegCurvetoCubicSmoothRel = function(x, y, x2, y2) { return new SVGPathSegCurvetoCubicSmoothRel(undefined, x, y, x2, y2); }
	        SVGPathElement.prototype.createSVGPathSegCurvetoQuadraticSmoothAbs = function(x, y) { return new SVGPathSegCurvetoQuadraticSmoothAbs(undefined, x, y); }
	        SVGPathElement.prototype.createSVGPathSegCurvetoQuadraticSmoothRel = function(x, y) { return new SVGPathSegCurvetoQuadraticSmoothRel(undefined, x, y); }
	    }

	    if (!("SVGPathSegList" in window)) {
	        // Spec: http://www.w3.org/TR/SVG11/single-page.html#paths-InterfaceSVGPathSegList
	        window.SVGPathSegList = function(pathElement) {
	            this._pathElement = pathElement;
	            this._list = this._parsePath(this._pathElement.getAttribute("d"));

	            // Use a MutationObserver to catch changes to the path's "d" attribute.
	            this._mutationObserverConfig = { "attributes": true, "attributeFilter": ["d"] };
	            this._pathElementMutationObserver = new MutationObserver(this._updateListFromPathMutations.bind(this));
	            this._pathElementMutationObserver.observe(this._pathElement, this._mutationObserverConfig);
	        }

	        Object.defineProperty(SVGPathSegList.prototype, "numberOfItems", {
	            get: function() {
	                this._checkPathSynchronizedToList();
	                return this._list.length;
	            },
	            enumerable: true
	        });

	        // Add the pathSegList accessors to SVGPathElement.
	        // Spec: http://www.w3.org/TR/SVG11/single-page.html#paths-InterfaceSVGAnimatedPathData
	        Object.defineProperty(SVGPathElement.prototype, "pathSegList", {
	            get: function() {
	                if (!this._pathSegList)
	                    this._pathSegList = new SVGPathSegList(this);
	                return this._pathSegList;
	            },
	            enumerable: true
	        });
	        // FIXME: The following are not implemented and simply return SVGPathElement.pathSegList.
	        Object.defineProperty(SVGPathElement.prototype, "normalizedPathSegList", { get: function() { return this.pathSegList; }, enumerable: true });
	        Object.defineProperty(SVGPathElement.prototype, "animatedPathSegList", { get: function() { return this.pathSegList; }, enumerable: true });
	        Object.defineProperty(SVGPathElement.prototype, "animatedNormalizedPathSegList", { get: function() { return this.pathSegList; }, enumerable: true });

	        // Process any pending mutations to the path element and update the list as needed.
	        // This should be the first call of all public functions and is needed because
	        // MutationObservers are not synchronous so we can have pending asynchronous mutations.
	        SVGPathSegList.prototype._checkPathSynchronizedToList = function() {
	            this._updateListFromPathMutations(this._pathElementMutationObserver.takeRecords());
	        }

	        SVGPathSegList.prototype._updateListFromPathMutations = function(mutationRecords) {
	            if (!this._pathElement)
	                return;
	            var hasPathMutations = false;
	            mutationRecords.forEach(function(record) {
	                if (record.attributeName == "d")
	                    hasPathMutations = true;
	            });
	            if (hasPathMutations)
	                this._list = this._parsePath(this._pathElement.getAttribute("d"));
	        }

	        // Serialize the list and update the path's 'd' attribute.
	        SVGPathSegList.prototype._writeListToPath = function() {
	            this._pathElementMutationObserver.disconnect();
	            this._pathElement.setAttribute("d", SVGPathSegList._pathSegArrayAsString(this._list));
	            this._pathElementMutationObserver.observe(this._pathElement, this._mutationObserverConfig);
	        }

	        // When a path segment changes the list needs to be synchronized back to the path element.
	        SVGPathSegList.prototype.segmentChanged = function(pathSeg) {
	            this._writeListToPath();
	        }

	        SVGPathSegList.prototype.clear = function() {
	            this._checkPathSynchronizedToList();

	            this._list.forEach(function(pathSeg) {
	                pathSeg._owningPathSegList = null;
	            });
	            this._list = [];
	            this._writeListToPath();
	        }

	        SVGPathSegList.prototype.initialize = function(newItem) {
	            this._checkPathSynchronizedToList();

	            this._list = [newItem];
	            newItem._owningPathSegList = this;
	            this._writeListToPath();
	            return newItem;
	        }

	        SVGPathSegList.prototype._checkValidIndex = function(index) {
	            if (isNaN(index) || index < 0 || index >= this.numberOfItems)
	                throw "INDEX_SIZE_ERR";
	        }

	        SVGPathSegList.prototype.getItem = function(index) {
	            this._checkPathSynchronizedToList();

	            this._checkValidIndex(index);
	            return this._list[index];
	        }

	        SVGPathSegList.prototype.insertItemBefore = function(newItem, index) {
	            this._checkPathSynchronizedToList();

	            // Spec: If the index is greater than or equal to numberOfItems, then the new item is appended to the end of the list.
	            if (index > this.numberOfItems)
	                index = this.numberOfItems;
	            if (newItem._owningPathSegList) {
	                // SVG2 spec says to make a copy.
	                newItem = newItem.clone();
	            }
	            this._list.splice(index, 0, newItem);
	            newItem._owningPathSegList = this;
	            this._writeListToPath();
	            return newItem;
	        }

	        SVGPathSegList.prototype.replaceItem = function(newItem, index) {
	            this._checkPathSynchronizedToList();

	            if (newItem._owningPathSegList) {
	                // SVG2 spec says to make a copy.
	                newItem = newItem.clone();
	            }
	            this._checkValidIndex(index);
	            this._list[index] = newItem;
	            newItem._owningPathSegList = this;
	            this._writeListToPath();
	            return newItem;
	        }

	        SVGPathSegList.prototype.removeItem = function(index) {
	            this._checkPathSynchronizedToList();

	            this._checkValidIndex(index);
	            var item = this._list[index];
	            this._list.splice(index, 1);
	            this._writeListToPath();
	            return item;
	        }

	        SVGPathSegList.prototype.appendItem = function(newItem) {
	            this._checkPathSynchronizedToList();

	            if (newItem._owningPathSegList) {
	                // SVG2 spec says to make a copy.
	                newItem = newItem.clone();
	            }
	            this._list.push(newItem);
	            newItem._owningPathSegList = this;
	            // TODO: Optimize this to just append to the existing attribute.
	            this._writeListToPath();
	            return newItem;
	        }

	        SVGPathSegList._pathSegArrayAsString = function(pathSegArray) {
	            var string = "";
	            var first = true;
	            pathSegArray.forEach(function(pathSeg) {
	                if (first) {
	                    first = false;
	                    string += pathSeg._asPathString();
	                } else {
	                    string += " " + pathSeg._asPathString();
	                }
	            });
	            return string;
	        }

	        // This closely follows SVGPathParser::parsePath from Source/core/svg/SVGPathParser.cpp.
	        SVGPathSegList.prototype._parsePath = function(string) {
	            if (!string || string.length == 0)
	                return [];

	            var owningPathSegList = this;

	            var Builder = function() {
	                this.pathSegList = [];
	            }

	            Builder.prototype.appendSegment = function(pathSeg) {
	                this.pathSegList.push(pathSeg);
	            }

	            var Source = function(string) {
	                this._string = string;
	                this._currentIndex = 0;
	                this._endIndex = this._string.length;
	                this._previousCommand = SVGPathSeg.PATHSEG_UNKNOWN;

	                this._skipOptionalSpaces();
	            }

	            Source.prototype._isCurrentSpace = function() {
	                var character = this._string[this._currentIndex];
	                return character <= " " && (character == " " || character == "\n" || character == "\t" || character == "\r" || character == "\f");
	            }

	            Source.prototype._skipOptionalSpaces = function() {
	                while (this._currentIndex < this._endIndex && this._isCurrentSpace())
	                    this._currentIndex++;
	                return this._currentIndex < this._endIndex;
	            }

	            Source.prototype._skipOptionalSpacesOrDelimiter = function() {
	                if (this._currentIndex < this._endIndex && !this._isCurrentSpace() && this._string.charAt(this._currentIndex) != ",")
	                    return false;
	                if (this._skipOptionalSpaces()) {
	                    if (this._currentIndex < this._endIndex && this._string.charAt(this._currentIndex) == ",") {
	                        this._currentIndex++;
	                        this._skipOptionalSpaces();
	                    }
	                }
	                return this._currentIndex < this._endIndex;
	            }

	            Source.prototype.hasMoreData = function() {
	                return this._currentIndex < this._endIndex;
	            }

	            Source.prototype.peekSegmentType = function() {
	                var lookahead = this._string[this._currentIndex];
	                return this._pathSegTypeFromChar(lookahead);
	            }

	            Source.prototype._pathSegTypeFromChar = function(lookahead) {
	                switch (lookahead) {
	                case "Z":
	                case "z":
	                    return SVGPathSeg.PATHSEG_CLOSEPATH;
	                case "M":
	                    return SVGPathSeg.PATHSEG_MOVETO_ABS;
	                case "m":
	                    return SVGPathSeg.PATHSEG_MOVETO_REL;
	                case "L":
	                    return SVGPathSeg.PATHSEG_LINETO_ABS;
	                case "l":
	                    return SVGPathSeg.PATHSEG_LINETO_REL;
	                case "C":
	                    return SVGPathSeg.PATHSEG_CURVETO_CUBIC_ABS;
	                case "c":
	                    return SVGPathSeg.PATHSEG_CURVETO_CUBIC_REL;
	                case "Q":
	                    return SVGPathSeg.PATHSEG_CURVETO_QUADRATIC_ABS;
	                case "q":
	                    return SVGPathSeg.PATHSEG_CURVETO_QUADRATIC_REL;
	                case "A":
	                    return SVGPathSeg.PATHSEG_ARC_ABS;
	                case "a":
	                    return SVGPathSeg.PATHSEG_ARC_REL;
	                case "H":
	                    return SVGPathSeg.PATHSEG_LINETO_HORIZONTAL_ABS;
	                case "h":
	                    return SVGPathSeg.PATHSEG_LINETO_HORIZONTAL_REL;
	                case "V":
	                    return SVGPathSeg.PATHSEG_LINETO_VERTICAL_ABS;
	                case "v":
	                    return SVGPathSeg.PATHSEG_LINETO_VERTICAL_REL;
	                case "S":
	                    return SVGPathSeg.PATHSEG_CURVETO_CUBIC_SMOOTH_ABS;
	                case "s":
	                    return SVGPathSeg.PATHSEG_CURVETO_CUBIC_SMOOTH_REL;
	                case "T":
	                    return SVGPathSeg.PATHSEG_CURVETO_QUADRATIC_SMOOTH_ABS;
	                case "t":
	                    return SVGPathSeg.PATHSEG_CURVETO_QUADRATIC_SMOOTH_REL;
	                default:
	                    return SVGPathSeg.PATHSEG_UNKNOWN;
	                }
	            }

	            Source.prototype._nextCommandHelper = function(lookahead, previousCommand) {
	                // Check for remaining coordinates in the current command.
	                if ((lookahead == "+" || lookahead == "-" || lookahead == "." || (lookahead >= "0" && lookahead <= "9")) && previousCommand != SVGPathSeg.PATHSEG_CLOSEPATH) {
	                    if (previousCommand == SVGPathSeg.PATHSEG_MOVETO_ABS)
	                        return SVGPathSeg.PATHSEG_LINETO_ABS;
	                    if (previousCommand == SVGPathSeg.PATHSEG_MOVETO_REL)
	                        return SVGPathSeg.PATHSEG_LINETO_REL;
	                    return previousCommand;
	                }
	                return SVGPathSeg.PATHSEG_UNKNOWN;
	            }

	            Source.prototype.initialCommandIsMoveTo = function() {
	                // If the path is empty it is still valid, so return true.
	                if (!this.hasMoreData())
	                    return true;
	                var command = this.peekSegmentType();
	                // Path must start with moveTo.
	                return command == SVGPathSeg.PATHSEG_MOVETO_ABS || command == SVGPathSeg.PATHSEG_MOVETO_REL;
	            }

	            // Parse a number from an SVG path. This very closely follows genericParseNumber(...) from Source/core/svg/SVGParserUtilities.cpp.
	            // Spec: http://www.w3.org/TR/SVG11/single-page.html#paths-PathDataBNF
	            Source.prototype._parseNumber = function() {
	                var exponent = 0;
	                var integer = 0;
	                var frac = 1;
	                var decimal = 0;
	                var sign = 1;
	                var expsign = 1;

	                var startIndex = this._currentIndex;

	                this._skipOptionalSpaces();

	                // Read the sign.
	                if (this._currentIndex < this._endIndex && this._string.charAt(this._currentIndex) == "+")
	                    this._currentIndex++;
	                else if (this._currentIndex < this._endIndex && this._string.charAt(this._currentIndex) == "-") {
	                    this._currentIndex++;
	                    sign = -1;
	                }

	                if (this._currentIndex == this._endIndex || ((this._string.charAt(this._currentIndex) < "0" || this._string.charAt(this._currentIndex) > "9") && this._string.charAt(this._currentIndex) != "."))
	                    // The first character of a number must be one of [0-9+-.].
	                    return undefined;

	                // Read the integer part, build right-to-left.
	                var startIntPartIndex = this._currentIndex;
	                while (this._currentIndex < this._endIndex && this._string.charAt(this._currentIndex) >= "0" && this._string.charAt(this._currentIndex) <= "9")
	                    this._currentIndex++; // Advance to first non-digit.

	                if (this._currentIndex != startIntPartIndex) {
	                    var scanIntPartIndex = this._currentIndex - 1;
	                    var multiplier = 1;
	                    while (scanIntPartIndex >= startIntPartIndex) {
	                        integer += multiplier * (this._string.charAt(scanIntPartIndex--) - "0");
	                        multiplier *= 10;
	                    }
	                }

	                // Read the decimals.
	                if (this._currentIndex < this._endIndex && this._string.charAt(this._currentIndex) == ".") {
	                    this._currentIndex++;

	                    // There must be a least one digit following the .
	                    if (this._currentIndex >= this._endIndex || this._string.charAt(this._currentIndex) < "0" || this._string.charAt(this._currentIndex) > "9")
	                        return undefined;
	                    while (this._currentIndex < this._endIndex && this._string.charAt(this._currentIndex) >= "0" && this._string.charAt(this._currentIndex) <= "9")
	                        decimal += (this._string.charAt(this._currentIndex++) - "0") * (frac *= 0.1);
	                }

	                // Read the exponent part.
	                if (this._currentIndex != startIndex && this._currentIndex + 1 < this._endIndex && (this._string.charAt(this._currentIndex) == "e" || this._string.charAt(this._currentIndex) == "E") && (this._string.charAt(this._currentIndex + 1) != "x" && this._string.charAt(this._currentIndex + 1) != "m")) {
	                    this._currentIndex++;

	                    // Read the sign of the exponent.
	                    if (this._string.charAt(this._currentIndex) == "+") {
	                        this._currentIndex++;
	                    } else if (this._string.charAt(this._currentIndex) == "-") {
	                        this._currentIndex++;
	                        expsign = -1;
	                    }

	                    // There must be an exponent.
	                    if (this._currentIndex >= this._endIndex || this._string.charAt(this._currentIndex) < "0" || this._string.charAt(this._currentIndex) > "9")
	                        return undefined;

	                    while (this._currentIndex < this._endIndex && this._string.charAt(this._currentIndex) >= "0" && this._string.charAt(this._currentIndex) <= "9") {
	                        exponent *= 10;
	                        exponent += (this._string.charAt(this._currentIndex) - "0");
	                        this._currentIndex++;
	                    }
	                }

	                var number = integer + decimal;
	                number *= sign;

	                if (exponent)
	                    number *= Math.pow(10, expsign * exponent);

	                if (startIndex == this._currentIndex)
	                    return undefined;

	                this._skipOptionalSpacesOrDelimiter();

	                return number;
	            }

	            Source.prototype._parseArcFlag = function() {
	                if (this._currentIndex >= this._endIndex)
	                    return undefined;
	                var flag = false;
	                var flagChar = this._string.charAt(this._currentIndex++);
	                if (flagChar == "0")
	                    flag = false;
	                else if (flagChar == "1")
	                    flag = true;
	                else
	                    return undefined;

	                this._skipOptionalSpacesOrDelimiter();
	                return flag;
	            }

	            Source.prototype.parseSegment = function() {
	                var lookahead = this._string[this._currentIndex];
	                var command = this._pathSegTypeFromChar(lookahead);
	                if (command == SVGPathSeg.PATHSEG_UNKNOWN) {
	                    // Possibly an implicit command. Not allowed if this is the first command.
	                    if (this._previousCommand == SVGPathSeg.PATHSEG_UNKNOWN)
	                        return null;
	                    command = this._nextCommandHelper(lookahead, this._previousCommand);
	                    if (command == SVGPathSeg.PATHSEG_UNKNOWN)
	                        return null;
	                } else {
	                    this._currentIndex++;
	                }

	                this._previousCommand = command;

	                switch (command) {
	                case SVGPathSeg.PATHSEG_MOVETO_REL:
	                    return new SVGPathSegMovetoRel(owningPathSegList, this._parseNumber(), this._parseNumber());
	                case SVGPathSeg.PATHSEG_MOVETO_ABS:
	                    return new SVGPathSegMovetoAbs(owningPathSegList, this._parseNumber(), this._parseNumber());
	                case SVGPathSeg.PATHSEG_LINETO_REL:
	                    return new SVGPathSegLinetoRel(owningPathSegList, this._parseNumber(), this._parseNumber());
	                case SVGPathSeg.PATHSEG_LINETO_ABS:
	                    return new SVGPathSegLinetoAbs(owningPathSegList, this._parseNumber(), this._parseNumber());
	                case SVGPathSeg.PATHSEG_LINETO_HORIZONTAL_REL:
	                    return new SVGPathSegLinetoHorizontalRel(owningPathSegList, this._parseNumber());
	                case SVGPathSeg.PATHSEG_LINETO_HORIZONTAL_ABS:
	                    return new SVGPathSegLinetoHorizontalAbs(owningPathSegList, this._parseNumber());
	                case SVGPathSeg.PATHSEG_LINETO_VERTICAL_REL:
	                    return new SVGPathSegLinetoVerticalRel(owningPathSegList, this._parseNumber());
	                case SVGPathSeg.PATHSEG_LINETO_VERTICAL_ABS:
	                    return new SVGPathSegLinetoVerticalAbs(owningPathSegList, this._parseNumber());
	                case SVGPathSeg.PATHSEG_CLOSEPATH:
	                    this._skipOptionalSpaces();
	                    return new SVGPathSegClosePath(owningPathSegList);
	                case SVGPathSeg.PATHSEG_CURVETO_CUBIC_REL:
	                    var points = {x1: this._parseNumber(), y1: this._parseNumber(), x2: this._parseNumber(), y2: this._parseNumber(), x: this._parseNumber(), y: this._parseNumber()};
	                    return new SVGPathSegCurvetoCubicRel(owningPathSegList, points.x, points.y, points.x1, points.y1, points.x2, points.y2);
	                case SVGPathSeg.PATHSEG_CURVETO_CUBIC_ABS:
	                    var points = {x1: this._parseNumber(), y1: this._parseNumber(), x2: this._parseNumber(), y2: this._parseNumber(), x: this._parseNumber(), y: this._parseNumber()};
	                    return new SVGPathSegCurvetoCubicAbs(owningPathSegList, points.x, points.y, points.x1, points.y1, points.x2, points.y2);
	                case SVGPathSeg.PATHSEG_CURVETO_CUBIC_SMOOTH_REL:
	                    var points = {x2: this._parseNumber(), y2: this._parseNumber(), x: this._parseNumber(), y: this._parseNumber()};
	                    return new SVGPathSegCurvetoCubicSmoothRel(owningPathSegList, points.x, points.y, points.x2, points.y2);
	                case SVGPathSeg.PATHSEG_CURVETO_CUBIC_SMOOTH_ABS:
	                    var points = {x2: this._parseNumber(), y2: this._parseNumber(), x: this._parseNumber(), y: this._parseNumber()};
	                    return new SVGPathSegCurvetoCubicSmoothAbs(owningPathSegList, points.x, points.y, points.x2, points.y2);
	                case SVGPathSeg.PATHSEG_CURVETO_QUADRATIC_REL:
	                    var points = {x1: this._parseNumber(), y1: this._parseNumber(), x: this._parseNumber(), y: this._parseNumber()};
	                    return new SVGPathSegCurvetoQuadraticRel(owningPathSegList, points.x, points.y, points.x1, points.y1);
	                case SVGPathSeg.PATHSEG_CURVETO_QUADRATIC_ABS:
	                    var points = {x1: this._parseNumber(), y1: this._parseNumber(), x: this._parseNumber(), y: this._parseNumber()};
	                    return new SVGPathSegCurvetoQuadraticAbs(owningPathSegList, points.x, points.y, points.x1, points.y1);
	                case SVGPathSeg.PATHSEG_CURVETO_QUADRATIC_SMOOTH_REL:
	                    return new SVGPathSegCurvetoQuadraticSmoothRel(owningPathSegList, this._parseNumber(), this._parseNumber());
	                case SVGPathSeg.PATHSEG_CURVETO_QUADRATIC_SMOOTH_ABS:
	                    return new SVGPathSegCurvetoQuadraticSmoothAbs(owningPathSegList, this._parseNumber(), this._parseNumber());
	                case SVGPathSeg.PATHSEG_ARC_REL:
	                    var points = {x1: this._parseNumber(), y1: this._parseNumber(), arcAngle: this._parseNumber(), arcLarge: this._parseArcFlag(), arcSweep: this._parseArcFlag(), x: this._parseNumber(), y: this._parseNumber()};
	                    return new SVGPathSegArcRel(owningPathSegList, points.x, points.y, points.x1, points.y1, points.arcAngle, points.arcLarge, points.arcSweep);
	                case SVGPathSeg.PATHSEG_ARC_ABS:
	                    var points = {x1: this._parseNumber(), y1: this._parseNumber(), arcAngle: this._parseNumber(), arcLarge: this._parseArcFlag(), arcSweep: this._parseArcFlag(), x: this._parseNumber(), y: this._parseNumber()};
	                    return new SVGPathSegArcAbs(owningPathSegList, points.x, points.y, points.x1, points.y1, points.arcAngle, points.arcLarge, points.arcSweep);
	                default:
	                    throw "Unknown path seg type."
	                }
	            }

	            var builder = new Builder();
	            var source = new Source(string);

	            if (!source.initialCommandIsMoveTo())
	                return [];
	            while (source.hasMoreData()) {
	                var pathSeg = source.parseSegment();
	                if (!pathSeg)
	                    return [];
	                builder.appendSegment(pathSeg);
	            }

	            return builder.pathSegList;
	        }
	    }
	}());

	
	// End of Polyfill
	
	
	 var parentGraphName ;
	
    function CirclePointer(options) {
        if (!options.name || !options.parent) {
            console.error('name and parent are mandatory for circle pointer');
            return;
        }
        for (var i in circle_defaults) {
            if (options[i] === undefined) {
                options[i] = circle_defaults[i];
            }
        }

        this.model = new SoModel();
        this.data = this.model.data;
        this.eventHandler = new eventHandler();
        this.data.x = 0;
        this.data.y = 0;
        this.parent = options.parent;
        this.updateCall = options.update || undefined ;
        this.move = options.move;
        this.scrub = options.scrub;
        this.calculateDirectionAngle =  this.scrub || false;
        this.isDraggable = options.isDraggable || this.scrub;
        this.path = options.path;
        this.show = options.pointer || this.scrub || false;
        this.end = options.end;
        this.classes = options.classes || undefined;
        this.arrowClasses = options.arrowClasses || undefined;
        this.name = options.name;
        this.showCoordinates = (options.pointer || options.scrub) || false;
        this.isMoving = false;
        this.movement = (options.movement !== undefined) ? options.movement : true;
        this.isEnd = false;
        this.snapToGrid = !this.scrub && options.snapToGrid;
        this.restrictX = options.restrictX;
        this.restrictY = options.restrictY;
        this.cachedPointer = options.cachedPointer || false;
        _initCirclePointer.call(this, options.data || options.initData);
    }

    /**
     * Default options of CirclePointer class
     */
    var circle_defaults = {
        move: function() {},
        end: function() {

        },
        initData: {
            x2: 0,
            y2: 0
        },
        isDraggable: false,
        snapToGrid: false,
        restrictX: false,
        restrictY: false,
        movement: true
    };


    function _initCirclePointer(data) {

            this.mouseDownForward = function(event) {
                this.isMoving = true;
                this.isEnd = false;
                var parent = this.parent.el.parentNode;

                if (this.movement) {
                    if (event.touches)
                        parent.addEventListener('touchmove', this.mouseMoveForward);
                    else
                        parent.addEventListener('mousemove', this.mouseMoveForward);

                }
                if (event.touches)
                    parent.addEventListener('touchend', this.mouseUpForward);
                else
                    parent.addEventListener('mouseup', this.mouseUpForward);

                this.eventHandler.emit(event.type, event, this);
            }.bind(this);

            this.mouseUpForward = function(event) {
                this.isMoving = false;
                this.isEnd = true;
                var parent = this.parent.el.parentNode;
                if (this.movement) {
                    if (event.touches)
                        parent.removeEventListener('touchmove', this.mouseMoveForward);
                    else
                        parent.removeEventListener('mousemove', this.mouseMoveForward);
                }
                parent.removeEventListener('touchend', this.mouseUpForward);
                parent.removeEventListener('mouseup', this.mouseUpForward);

                this.eventHandler.emit(event.type, event, this);
            }.bind(this);

            this.mouseMoveForward = function(event) {
                this.eventHandler.emit(event.type, event, this);
            }.bind(this);


            this.el = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
            this.virtualEl = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
            this.triangleRightEl = document.createElementNS('http://www.w3.org/2000/svg', 'polygon');
            this.triangleBottomEl = document.createElementNS('http://www.w3.org/2000/svg', 'polygon');
            this.triangleLeftEl = document.createElementNS('http://www.w3.org/2000/svg', 'polygon');
            this.triangleTopEl = document.createElementNS('http://www.w3.org/2000/svg', 'polygon');
            if (this.classes) {
                for (var i = 0, len = this.classes.length; i < len ; i++)
                    this.el.classList.add(this.classes[i]);
            }
            if (this.arrowClasses) {
                for (var i = 0, len = this.arrowClasses.length; i < len; i++) {
                    this.triangleRightEl.classList.add(this.arrowClasses[i]);
                    this.triangleBottomEl.classList.add(this.arrowClasses[i]);
                    this.triangleLeftEl.classList.add(this.arrowClasses[i]);
                    this.triangleTopEl.classList.add(this.arrowClasses[i]);
                }
            }
            if (!this.show) {
                this.el.style.display = "none";
                this.virtualEl.style.display = "none";
                hideDirections.apply(this, []);
            }

            if (this.isDraggable)
                _bindEventsOnPointer.call(this);
            var container = this.parent.circleLine;
            if (this.cachedPointer)
                container = this.parent.cachedCircleLine;
            this.render(container, data);
        }
        /**
         * Update the CirclePointer
         * reads only x2 and y2 coordinates of the given data object
         * @memberof CirclePointer
         * @method update
         * @param {object} datapoints
         * @this {CirclePointer}
         */
    CirclePointer.prototype.update = function(dataPoints) {
        this.setPointer(dataPoints);
    };

    /**
     * Plot the CirclePointer at given coordinates
     * reads only x2 and y2 coordinates of the given data object
     * @memberof CirclePointer
     * @method setPointer
     * @param {object} dataPoints
     * @this {CirclePointer}
     * @example circle.setPointer({x2:1,y2:1})
     */
    CirclePointer.prototype.setPointer = function(dataPoints) {
        this.updateData(dataPoints);
        var circle = this.el,
            virtualCircle = this.virtualEl,
            parent = this.parent;
        circle.setAttribute('cx', parent.convertToSVGX(dataPoints.x2));
        circle.setAttribute('cy', parent.convertToSVGY(dataPoints.y2));
        virtualCircle.setAttribute('cx', parent.convertToSVGX(dataPoints.x2));
        virtualCircle.setAttribute('cy', parent.convertToSVGY(dataPoints.y2));
        _positionTooltip.call(this, dataPoints);
        this.parent.el.setAttribute('viewBox', parent.viewBox);
        //calculate polygon points for triangle
        if (this.scrub || this.isDraggable) {
            _setTrianglePosition.call(this, dataPoints);
        }
        /*this.toolTip.style['webkitTransform'] = 'translate('+(parent.convertToSVGX(dataPoints.x2)-this.toolTip.clientWidth/2)+'px,'+(-parent.convertToSVGY(dataPoints.y2)+this.toolTip.clientHeight/2+7)+'px)';
		this.toolTip.style['transform'] = 'translate('+(parent.convertToSVGX(dataPoints.x2)-this.toolTip.clientWidth/2)+'px,'+(-parent.convertToSVGX(dataPoints.y2)-this.toolTip.clientHeight/2-7)+'px)';*/
    };

    /**
     * add class to the CirclePointer
     * @method addClass
     * @param {class | classes[]} classes array of class or single class
     * @memberof CirclePointer
     */
    CirclePointer.prototype.addClass = function(classes) {
        if (classes instanceof Array) {
            for (var i = 0, len = classes.length; i < len; i++) {
                this.el.classList.add(classes[i]);
            }
        } else {
            this.el.classList.add(classes);
        }
        return this;
    };

    /**
     * remove class from the CirclePointer
     * @method removeClass
     * @param {class | classes[]} classes array of classes or single class
     * @memberof CirclePointer
     */
    CirclePointer.prototype.removeClass = function(classes) {
        if (classes instanceof Array) {
            for (var i = 0, len = classes.length; i < len; i++) {
                this.el.classList.remove(classes[i]);
            }
        } else {
            this.el.classList.remove(classes);
        }
        return this;
    };

    /**
     * hide CirclePointer
     * @method hidePointer
     * @memberof CirclePointer
     */
    CirclePointer.prototype.hidePointer = function() {
        this.el.parentNode.classList.add('hide');
        return this;
    };
    
    /**
     * show CirclePointer
     * @method showPointer
     * @memberof CirclePointer
     */
    CirclePointer.prototype.showPointer = function() {
        this.el.parentNode.classList.remove('hide');
        return this;
    };

    /**
     * Show dragability directions on the cirlcepointer
     * @methos showDirections
     * @memberof CirclePointer
     */
    CirclePointer.prototype.showDirections = function() {
        this.calculateDirectionAngle = true;
        _setTrianglePosition.call(this, {
            x2: this.data.x,
            y2: this.data.y
        });
        if (this.show) {
            this.triangleRightEl.style.display = 'block';
            this.triangleLeftEl.style.display = 'block';
            this.triangleTopEl.style.display = 'block';
            this.triangleBottomEl.style.display = 'block';
        }
        if (this.scrub) {
            this.triangleTopEl.style.display = 'none';
            this.triangleBottomEl.style.display = 'none';
        }
        if (this.restrictX) {
            this.triangleRightEl.style.display = 'none';
            this.triangleLeftEl.style.display = 'none';
        }
        if (this.restrictY) {
            this.triangleTopEl.style.display = 'none';
            this.triangleBottomEl.style.display = 'none';
        }
    };

    /**
     * Hide dragability directions on the cirlcepointer
     * @methos showDirections
     * @memberof CirclePointer
     */
    CirclePointer.prototype.hideDirections = function() {
        this.calculateDirectionAngle = false;
        hideDirections.apply(this, []);
    };

    function hideDirections() {
        this.triangleRightEl.style.display = "none";
        this.triangleBottomEl.style.display = "none";
        this.triangleLeftEl.style.display = "none";
        this.triangleTopEl.style.display = "none";
    }

    /**
     * Update the CirclePointer model
     * reads only x2 and y2 coordinates of the given data object
     * @memberof CirclePointer
     * @method updateData
     * @param {object} data
     * @this {CirclePointer}
     */
    CirclePointer.prototype.updateData = function(data) {
        this.data.x = data.x2;
        this.data.y = data.y2;
    };

    /**
     * CirclePointer mouseDown eventhandler
     * @memberof CirclePointer
     * @this {CirclePointer}
     */
    CirclePointer.prototype.onmousedown = function(event) {
        if (event.touches) event = event.touches[0];
        this.startX = event.clientX;
        this.startY = event.clientY;
        this.dataX = this.data.x;
        this.dataY = this.data.y;
        this.toolTip.classList.add('show-this');
    };


    /**
     * CirclePointer mouseUp eventhandler
     * @memberof CirclePointer
     * @this {CirclePointer}
     */
    CirclePointer.prototype.onmouseup = function(event) {
        var dataPoints = {
            x2: this.data.x,
            y2: this.data.y
        };
        if (this.snapToGrid) {
            var parent = this.parent;
            dataPoints.x2 = (Math.round(dataPoints.x2 / parent.deltaX)) * parent.deltaX;
            dataPoints.y2 = (Math.round(dataPoints.y2 / parent.deltaY)) * parent.deltaY;
        }
        this.data.event = event;
        if (this.movement)
            this.setPointer(dataPoints);
        if (this.updateCall)
            this.updateCall.call(this, dataPoints);
        this.end.call(this, this.data);
        this.toolTip.classList.remove('show-this');
         parentGraphName = this.parent.name ;
         
         var widgetType, widgetName ;
         
        /*dexterjs.logEvent("FBS_WIDGET", {
            widgetType :  "graph" ,
            widgetName : parentGraphName 
        });*/
        
    };


    /**
     * CirclePointer mouseMove eventhandler
     * @memberof CirclePointer
     * @this {CirclePointer}
     */
    CirclePointer.prototype.onmousemove = function(event) {
    /*	var slideAudio = document.createElement('audio');
    	slideAudio.id = "simSlide";
    	slideAudio.src = "../allspark/assets/music/slide-paper.mp3";
    	slideAudio.preload = "auto";
    	slideAudio.play(); to add trnsition music */ 
        event.preventDefault();
        if (event.touches) event = event.touches[0];
        var parent = this.parent,
            point = [event.clientX - parent.el.parentNode.offsetLeft, event.clientY - parent.el.parentNode.offsetTop],
            dataPoints;
        if (!this.scrub)
            dataPoints = _calculateDataPoints.call(this, event);
        else {
            var data = _calculateDataPoints.call(this, event);
            point = [parent.convertToSVGX(data.x2), parent.convertToSVGY(data.y2)];
            dataPoints = _closestPoint.call(this, point);
        }
        // var dataPoints = moveOnPath.call(this,event);
        this.data.event = event;
        this.setPointer(dataPoints);
        if (this.updateCall)
            this.updateCall.call(this, dataPoints);
        this.move.call(this, this.data);
    };


    function _closestPoint(point) {
        var parent = this.parent,
            pathNode = this.path,
            pathLength = pathNode.getTotalLength(),
            precision = pathLength / pathNode.pathSegList.numberOfItems * .125,
            best,
            bestLength,
            bestDistance = Infinity;

        // linear scan for coarse approximation
        for (var scan, scanLength = 0, scanDistance; scanLength <= pathLength; scanLength += precision) {
            if ((scanDistance = distance2(scan = pathNode.getPointAtLength(scanLength))) < bestDistance) {
                best = scan, bestLength = scanLength, bestDistance = scanDistance;
            }
        }

        // binary search for precise estimate
        precision *= .5;
        while (precision > .5) {
            var before,
                after,
                beforeLength,
                afterLength,
                beforeDistance,
                afterDistance;
            if ((beforeLength = bestLength - precision) >= 0 && (beforeDistance = distance2(before = pathNode.getPointAtLength(beforeLength))) < bestDistance) {
                best = before, bestLength = beforeLength, bestDistance = beforeDistance;
            } else if ((afterLength = bestLength + precision) <= pathLength && (afterDistance = distance2(after = pathNode.getPointAtLength(afterLength))) < bestDistance) {
                best = after, bestLength = afterLength, bestDistance = afterDistance;
            } else {
                precision *= .5;
            }
        }

        best = {
            x2: parent.convertFromSVGX(best.x),
            y2: parent.convertFromSVGY(best.y)
        };
        best.distance = Math.sqrt(bestDistance);
        return best;

        function distance2(p) {
            var dx = p.x - point[0],
                dy = p.y - point[1];
            return dx * dx + dy * dy;
        }
    }

    function _calculateDataPoints(event) {
        var parent = this.parent;
        var restrict = this.parent.options.restrictXY;
        if (!restrict) {
            restrict = {
                xMin: parent.xMinGridValue,
                yMin: parent.yMinGridValue,
                xMax: parent.xMaxGridValue,
                yMax: parent.yMaxGridValue
            };
        }
        this.moveX = event.clientX;
        this.moveY = event.clientY;
        this.deltaX = this.moveX - this.startX;
        this.deltaY = this.moveY - this.startY;

        var dataX = this.dataX + ((this.deltaX / parent.xGridWidth) * parent.deltaX);
        var dataY = this.dataY - ((this.deltaY / parent.yGridWidth) * parent.deltaY);

        if (this.scrub) {
            return {
                x2: dataX,
                y2: dataY
            };
        }

        if (dataX <= restrict.xMin) {
            dataX = restrict.xMin;
        }
        if (dataX >= restrict.xMax) {
            dataX = restrict.xMax;
        }
        if (dataY <= restrict.yMin) {
            dataY = restrict.yMin;
        }
        if (dataY >= restrict.yMax) {
            dataY = restrict.yMax;
        }
        var dataPoints = {
            x2: dataX,
            y2: dataY
        };
        return dataPoints;
    }



    function _bindEventsOnPointer() {
        var that = this;
        if ("ontouchstart" in document) {
            this.virtualEl.addEventListener('touchstart', function(event) {
                event.preventDefault();
                that.mouseDownForward(event);
            });
        }
        this.virtualEl.addEventListener('mousedown', this.mouseDownForward);
        this.eventHandler.bindThis(this);
        this.eventHandler.on('mousedown', this.onmousedown);
        this.eventHandler.on('mousemove', this.onmousemove);
        this.eventHandler.on('mouseup', this.onmouseup);
        this.eventHandler.on('touchstart', this.onmousedown);
        this.eventHandler.on('touchmove', this.onmousemove);
        this.eventHandler.on('touchend', this.onmouseup);
    }

    function _positionTooltip(dataPoints) {
        var parent = this.parent;
        this.toolTip.innerHTML = (dataPoints.x2).toFixed(1) + "," + (dataPoints.y2).toFixed(1);
        this.toolTip.style.webkitTransform = 'translate(' + (parent.convertToSVGX(dataPoints.x2) - this.toolTip.clientWidth / 2) + 'px,' + (parent.convertToSVGY(dataPoints.y2) - this.toolTip.clientHeight - 12) + 'px)';
        this.toolTip.style.transform = 'translate(' + (parent.convertToSVGX(dataPoints.x2) - this.toolTip.clientWidth / 2) + 'px,' + (parent.convertToSVGY(dataPoints.y2) - this.toolTip.clientHeight - 12) + 'px)';

    }

    function _setTrianglePosition(dataPoints) {
        var triangleRight = this.triangleRightEl,
            triangleBottom = this.triangleBottomEl,
            triangleLeft = this.triangleLeftEl,
            triangleTop = this.triangleTopEl,
            parent = this.parent,
            slope,
            position = {
                x: parent.convertToSVGX(dataPoints.x2),
                y: parent.convertToSVGY(dataPoints.y2)
            };
        if ((this.path) && (this.path.attributes.d) && (this.path.getTotalLength() !== 0) && (this.scrub) && (this.calculateDirectionAngle)) {
            var nextPosition = _closestPoint.call(this, ([
                    position.x + 1,
                    position.y
                ])),
                prevPosition = _closestPoint.call(this, ([
                    position.x - 1,
                    position.y
                ]));
            var i = 1;
            if ((prevPosition.x2 == nextPosition.x2) && (prevPosition.y2 == nextPosition.y2)) {
                i = 1;
                while (prevPosition.x2 == nextPosition.x2) {
                    i += 1;
                    if (i > 10) {
                        break;
                    }
                    prevPosition = _closestPoint.call(this, ([
                        position.x - i,
                        position.y
                    ]));
                }

            }
            if (i <= 10) {
                slope = -180 * Math.atan2(parent.convertToSVGY(prevPosition.y2) - parent.convertToSVGY(nextPosition.y2), parent.convertToSVGX(nextPosition.x2) - parent.convertToSVGX(prevPosition.x2)) / Math.PI;
            } else {
                slope = -90;
            }

            triangleRight.setAttribute('transform', 'rotate(' + slope + " " + position.x + " " + position.y + ')');
            triangleBottom.setAttribute('transform', 'rotate(' + slope + " " + position.x + " " + position.y + ')');
            triangleLeft.setAttribute('transform', 'rotate(' + slope + " " + position.x + " " + position.y + ')');
            triangleTop.setAttribute('transform', 'rotate(' + slope + " " + position.x + " " + position.y + ')');
            triangleRight.style.display = 'block';
            triangleLeft.style.display = 'block';
            triangleTop.style.display = 'none';
            triangleBottom.style.display = 'none';
        }

        var triangleRightValue = (position.x + 8) + "," + (position.y - 3) + " " + (position.x + 8) + "," + (position.y + 3) + " " + (position.x + 13) + "," + (position.y),
            triangleBottomValue = (position.x - 3) + "," + (position.y + 8) + " " + (position.x + 3) + "," + (position.y + 8) + " " + (position.x) + "," + (position.y + 13),
            triangleLeftValue = (position.x - 8) + "," + (position.y - 3) + " " + (position.x - 8) + "," + (position.y + 3) + " " + (position.x - 13) + "," + (position.y),
            triangleTopValue = (position.x - 3) + "," + (position.y - 8) + " " + (position.x + 3) + "," + (position.y - 8) + " " + (position.x) + "," + (position.y - 13);

        triangleRight.setAttribute('points', triangleRightValue);
        triangleBottom.setAttribute('points', triangleBottomValue);
        triangleLeft.setAttribute('points', triangleLeftValue);
        triangleTop.setAttribute('points', triangleTopValue);

    }


    /**
     * renders the CirclePointer on the given graph
     * @memberof CirclePointer
     * @method render
     * @param {element} container
     * @param {object} dataPoints
     * @this {CirclePointer}
     */
    CirclePointer.prototype.render = function(container, dataPoints) {
        var circle = this.el,
            virtualCircle = this.virtualEl,
            parent = this.parent,
            group = document.createElementNS('http://www.w3.org/2000/svg', 'g'),
            triangleRight = this.triangleRightEl,
            triangleBottom = this.triangleBottomEl,
            triangleLeft = this.triangleLeftEl,
            triangleTop = this.triangleTopEl;
        this.toolTip = document.createElement('div');
        parent.parent.appendChild(this.toolTip);
        this.toolTip.classList.add('graph-tooltip');
        /*if(this.showCoordinates)
			this.showTooltip();
		else
			this.hideTooltip();*/
        /*this.toolTip.style['opacity'] = 1;*/
        circle.setAttribute('r', 4.5);
        circle.classList.add('point-circle-beaker');
        this.updateData(dataPoints);
        circle.setAttribute('cx', parent.convertToSVGX(dataPoints.x2));
        circle.setAttribute('cy', parent.convertToSVGY(dataPoints.y2));
        virtualCircle.setAttribute('r', 20);
        virtualCircle.classList.add('virtual-circle-beaker');
        virtualCircle.setAttribute('cx', parent.convertToSVGX(dataPoints.x2));
        virtualCircle.setAttribute('cy', parent.convertToSVGY(dataPoints.y2));
        triangleRight.classList.add('direction-arrow-beaker');
        triangleBottom.classList.add('direction-arrow-beaker');
        triangleLeft.classList.add('direction-arrow-beaker');
        triangleTop.classList.add('direction-arrow-beaker');

        //calculate polygon points for triangle
        _setTrianglePosition.call(this, dataPoints);

        group.appendChild(circle);
        group.appendChild(virtualCircle);
        group.appendChild(triangleRight);
        group.appendChild(triangleBottom);
        group.appendChild(triangleLeft);
        group.appendChild(triangleTop);
        container.appendChild(group);

        if (this.restrictY) {
            triangleTop.style.display = 'none';
            triangleBottom.style.display = 'none';
        }
        if (this.restrictX) {
            triangleRight.style.display = 'none';
            triangleLeft.style.display = 'none';
        }

        if (this.isDraggable)
            _bindEventsOnPointer.call(this, virtualCircle);
    };

    return CirclePointer;

});;define('Graph', ['SoModel', 'utility','CirclePointer'], function(SoModel, utility,CirclePointer) {
    /**
     * Creates an instance of Circle.
     *
     * @constructor Graph
     * @this {Graph}
     * @param {object} desired options to the graph
     * @example
     * var parabola = new Graph({
     * 			name:'parabola',
     * 			height:400,
     * 			width:400,
     * 			labels:{
     * 					xAxis :['1t','2t','3t','4t'],
     * 					yAxis :['1N','2N','3N','4N'],
     * 					xLabel: true,
     * 					yLabel: true
     * 					},
     * 		offset:40,
     *		noOfGraphs:	1,
     *		isDrawGrid:true,
     *		xPos:'bottom',
     *		yPos:'left',
     *		drawYGrid:true,
     *		drawXGrid:true,
     *		gridStroke:'rgba(0, 0, 0, 0.15)',
     *		isDragCircle:false,
     *		snapToGrid: true
     * })
     *
     */
	
    var circlePointerBucket = [];
    var Graph = function(options) {

        for (var i in graph_defaults) {
        	if(graph_defaults.hasOwnProperty(i)){
                if (options[i] === undefined) {
                    options[i] = graph_defaults[i];
                }	
        	}
        }

        this.circlePointers = {};
        this.paths = {};

        this.cachedPaths = {};
        this.cachedId = [];
        this.cachedCirclePointers = {};
        this.circlePointerArray = [];
        this.isCachedGraphs = false;
        this.toolsModel = new SoModel({
            'info': false,
            'zoom': false,
            'hide': false,
            'lastRun': false,
            'currentGraph': true,
            'settingsEnabled': false
        });
        this.toolsSettingsCallback = function() {};
        this.toolsData = this.toolsModel.data;
        _init.call(this,options);
    };


    var graph_defaults = {
        name: 'graph',
        height: 400,
        width: 400,
        axisStroke: 'rgba(0, 0, 0, 0.4)',
        strokeWidth: "1",
        labels: {
            yAxis: ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11'],
            xAxis: ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '12'],
            xLabel: true,
            yLabel: true
        },
        offset: 40,
        noOfGraphs: 1,
        isDrawGrid: true,
        xPos: "bottom",
        yPos: "left",
        drawYGrid: true,
        drawXGrid: true,
        gridStroke: 'rgba(0, 0, 0, 0.15)',
        isDragCircle: false,
        snapToGrid: true,
        graphToolSet: true,
        lastRunOption: true,
        graphInfo:""

    };


    //var currentPaths = [];
    //var lastRunPaths = [];


    
    function _init(options) {
        this.el = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
        this.el.id = options.name;
        this.circleLine = document.createElementNS('http://www.w3.org/2000/svg', 'g');
        this.cachedCircleLine = document.createElementNS('http://www.w3.org/2000/svg', 'g');
        this.graphPath = document.createElementNS('http://www.w3.org/2000/svg', 'g');
        this.el.appendChild(this.graphPath);
        this.el.appendChild(this.cachedCircleLine);
        this.el.appendChild(this.circleLine);
        this.options = options;
        this.name = options.name;
        this.parent = options.parent;
        this.width = options.width || this.parent.clientWidth;
        this.height = options.height || this.parent.clientHeight;
        this.el.setAttribute('width', this.width);
        this.el.setAttribute('height', this.height);
        this.axisStroke = options.axisStroke;
        this.strokeWidth = options.strokeWidth;
        this.offsetInAxis = options.offset;
        this.labels = options.labels; // use labels.xLabel, labels.yLabel to draw labels for graph
        this.noOfGraphs = options.noOfGraphs;
        this.isDrawGrid = options.isDrawGrid;
        this.gridStroke = options.gridStroke;
        this.xPos = options.xPos;
        this.yPos = options.yPos;
        this.pathCount = 0;
        this.viewBox =  '0 0 '+this.width+' '+this.height;
        if (this.yPos === 'right' && this.xPos === "top") {
            this.yMaxGridValue = parseFloat(this.labels.yAxis[0].replace(/[a-zA-Z]/g, ""));
            this.yMinGridValue = parseFloat(this.labels.yAxis[this.labels.yAxis.length - 1].replace(/[a-zA-Z]/g, ""));
        } else if (this.yPos === 'right') {
            this.yMinGridValue = parseFloat(this.labels.yAxis[0].replace(/[a-zA-Z]/g, ""));
            this.yMaxGridValue = parseFloat(this.labels.yAxis[this.labels.yAxis.length - 1].replace(/[a-zA-Z]/g, ""));
        } else {
            this.yMinGridValue = parseFloat(this.labels.yAxis[0].replace(/[a-zA-Z]/g, ""));
            this.yMaxGridValue = parseFloat(this.labels.yAxis[this.labels.yAxis.length - 1].replace(/[a-zA-Z]/g, ""));
        }
        if (this.xPos === 'top' && this.yPos === 'right') {
            this.xMaxGridValue = parseFloat(this.labels.xAxis[0].replace(/[a-zA-Z]/g, ""));
            this.xMinGridValue = parseFloat(this.labels.xAxis[this.labels.xAxis.length - 1].replace(/[a-zA-Z]/g, ""));
        } else {
            this.xMinGridValue = parseFloat(this.labels.xAxis[0].replace(/[a-zA-Z]/g, ""));
            this.xMaxGridValue = parseFloat(this.labels.xAxis[this.labels.xAxis.length - 1].replace(/[a-zA-Z]/g, ""));
        }
        var y2 = parseFloat(this.labels.yAxis[1].replace(/[a-zA-Z]/g, ""));
        var x2 = parseFloat(this.labels.xAxis[1].replace(/[a-zA-Z]/g, ""));
        this.deltaX = Math.abs(x2 - parseFloat(this.labels.xAxis[0].replace(/[a-zA-Z]/g, "")));
        this.deltaY = Math.abs(y2 - parseFloat(this.labels.yAxis[0].replace(/[a-zA-Z]/g, "")));
        this.graphNumber = 0;
        this.isAnimate = options.isAnimate;
        this.drawXGrid = options.drawXGrid;
        this.drawYGrid = options.drawYGrid;
        this.graphToolSet = options.graphToolSet;
        this.lastRunOption = options.lastRunOption;
        this.graphInfo = options.graphInfo;
        this.isDragCircle = options.isDragCircle;
        this.snapToGrid = options.snapToGrid;
        this.currentPaths = [];
        this.lastRunPaths = [];
        this.labelAxis(this.labels);
        this.xAxis();
        this.yAxis();
        _graphTools.call(this);
        /* this.togglePrevplot(true);*/

        this.toolsModel.eyesOn(function(variable, as, currValue) {
            this.onSettingsChange(variable, currValue);
        }.bind(this));

        if (this.isDrawGrid)
            this.drawGrid();

    }


    /**
     * draw the yaxis
     * @memberof Graph
     * @method yAxis
     * @this {Graph}
     */
     function _graphTools() {
        if (this.graphToolSet) {
            var graphTools = [];
            //var zoomed = false;
            //var graphHidden = false;
            var infoOn = false;
            var iconContainer = document.createElement('div');
            iconContainer.classList.add('iconContainer');
            this.graphToolBox = document.createElement('div');
            this.graphToolBox.classList.add('graphToolBox');
            this.multiGraphTool = document.createElement('div');
            this.multiGraphTool.classList.add('multi-tool-icon');
            this.zoomEl = document.createElement('div');
            this.zoomEl.classList.add('graph-tools', 'zoom');
            this.zoomEl.innerHTML = "Zoom";
            this.graphHide = document.createElement('div');
            this.graphHide.classList.add('graph-tools', 'graphHide');
            this.graphHide.innerHTML = "Hide Graph";
            this.lastRunEl = document.createElement('div');
            this.lastRunEl.classList.add('graph-tools', 'lastRun');
            this.lastRunEl.innerHTML = "Enable Last Run";
            this.infoEl = document.createElement('div');
            this.infoEl.classList.add('graph-tools', 'info');
            this.infoEl.innerHTML = "Info";
    		
            this.enabledSettingsContainer = document.createElement('div');
            ['checkbox-container', 'inActive', 'hide', 'animated'].forEach(function(element) {
                this.enabledSettingsContainer.classList.add(element);
            }.bind(this));


            this.hideCurrentGraphEl = document.createElement('div');
            ['graph-tools'].forEach(function(element) {
                this.hideCurrentGraphEl.classList.add(element);
            }.bind(this));
            this.hideCurrentGraphEl.innerHTML = "<input type='checkbox' checked='true'>Show Current Run";

            this.showLastRunEl = document.createElement('div');
            this.showLastRunEl.classList.add('graph-tools');
            this.showLastRunEl.innerHTML = "<input type='checkbox' checked='true'>Show Last Run";

            this.enabledSettingsContainer.appendChild(this.hideCurrentGraphEl);
            this.enabledSettingsContainer.appendChild(this.showLastRunEl);

            if (!this.lastRunOption) {
                this.lastRunEl.classList.add('hide');
                this.hideCurrentGraphEl.classList.add('hide');
            }

            this.infoScreen = document.createElement('div');
            this.infoScreen.classList.add('infoScreen');
            this.infoScreen.innerHTML = '<span class="graph-info-text">' +this.graphInfo+ '</span>';
            if(this.graphInfo === ""){
            	this.infoEl.classList.add("hide");
            }
            this.infoScreen.addEventListener('click',function(event){
            	event.stopPropagation();
            });

            graphTools.push(this.infoEl, this.zoomEl, this.graphHide, this.lastRunEl, this.enabledSettingsContainer);

            for (var i = 0; i <= graphTools.length - 1; i++) {
                var graphTool = graphTools[i];
                this.graphToolBox.appendChild(graphTool);
            }
            iconContainer.appendChild(this.graphToolBox);
            iconContainer.appendChild(this.multiGraphTool);
            this.options.parent.appendChild(this.infoScreen);
            this.options.parent.appendChild(iconContainer);

            this.options.parent.classList.add('graphContainer');

            this.lastRunEl.addEventListener('click', function() {
                this.toolsData.settingsEnabled = !this.toolsData.settingsEnabled;
                this.toolsData.lastRun = this.toolsData.settingsEnabled;
                this.toolsData.currentGraph = true;
            }.bind(this));

            this.showLastRunEl.addEventListener('click', function() {
                if (this.isCachedGraphs) {
                    this.isCachedGraphs = false;
                } else {
                    this.isCachedGraphs = true;
                }
                this.toolsData.lastRun = !this.toolsData.lastRun;
            }.bind(this));


            this.hideCurrentGraphEl.addEventListener('click', function(e) {
                //if(!this.hideCurrentGraphEl.classList.contains('inActive')){
                this.toolsData.currentGraph = !this.toolsData.currentGraph;
                //}
            }.bind(this));

            this.infoEl.addEventListener('click', function() {
                this.toolsData.info = true;
            }.bind(this));

            this.zoomEl.addEventListener('click', function() {
                this.toolsData.zoom = true;
            }.bind(this));

            this.graphHide.addEventListener('click', function() {
                this.toolsData.hide = true;
            }.bind(this));

            this.multiGraphTool.addEventListener('click', function(e) {
              /*  e.stopPropagation();*/
                var graphContainer = this.parent;
                
            
                
                var graphCurrent = graphContainer.children;
                if (this.toolsData.zoom !== true && this.toolsData.hide !== true && this.toolsData.info !== true) {
                    this.graphToolBox.classList.add('open');
            
                } else {
                    if (this.toolsData.zoom === true) {
                        this.toolsData.zoom = false;
                    }
                    if (this.toolsData.hide === true) {
                        this.toolsData.hide = false;
                    }
                    if (this.toolsData.info === true) {
                        this.toolsData.info = false;
                    }
                    /**Removing high z index */
                    graphContainer.classList.remove('highZIndex');
                }
            }.bind(this));

            this.graphToolBox.addEventListener('click', function(e) {
                e.stopPropagation();
            });


            document.addEventListener('click', function(e) {
                e.stopPropagation();
                var graphContainer = this.parent;
                /**Removing high z index */
                graphContainer.classList.remove('highZIndex');
                
                if (e.target == this.multiGraphTool || e.target == this.graphToolBox || e.target == this.infoScreen || e.target == graphContainer)
                    return;
                this.graphToolBox.classList.remove('open');
                this.toolsData.info = false;
                this.toolsData.zoom = false;
            }.bind(this));

        }
    }


    /**
     * Contain the callback function after change of tool settings
     * @memberof Graph
     * @method onSettingsChange
     * @param {variable} settings variable name
     * @param {value} settings variable value
     * @this {Graph}
     */
    Graph.prototype.onSettingsChange = function(variable, value) {
        switch (variable) {
            case "settingsEnabled":
                _toggleSettings.apply(this, [value]);
                break;
            case "lastRun":
                _toggleLastRun.apply(this, [value]);
                break;
            case "currentGraph":
                _toggleCurrentGraph.apply(this, [value]);
                break;
            case "info":
                _toggleInfo.apply(this, [value]);
                break;
            case "zoom":
                _toggleZoom.apply(this, [value]);
                break;
            case "hide":
                _toggleHide.apply(this, [value]);
                break;
            default:
                break;
        }
        this.el.setAttribute('viewBox',this.viewBox);
        this.toolsSettingsCallback.apply(this, [{
            variable: variable,
            value: value
        }]);
    };

    function _toggleSettings(showSettings) {
        if (showSettings) {
            this.lastRunEl.textContent = "Disable Last Run";
            this.enabledSettingsContainer.classList.remove('slideUpFadeOut');
            this.enabledSettingsContainer.classList.add('slideDownFadeIn');
            //this.enabledSettingsContainer.classList.remove('inActive');
            this.enabledSettingsContainer.classList.remove('hide');
            this.toolsData.settingsEnabled = true;
        } else {
            this.lastRunEl.textContent = "Enable Last Run";
            this.enabledSettingsContainer.classList.remove('slideDownFadeIn');
            this.enabledSettingsContainer.classList.add('slideUpFadeOut');
            //this.enabledSettingsContainer.classList.add('inActive');
            //this.hideCurrentGraphEl.classList.add('hide');
            this.toolsData.settingsEnabled = false;
        }
    }

    function _toggleLastRun(showLastRun) {
        for (var i = 0; i <= this.lastRunPaths.length - 1; i++) {
            if (showLastRun) {
                this.lastRunPaths[i].classList.remove('vanish');
                for (var x in this.cachedCirclePointers) {
                	if(this.cachedCirclePointers.hasOwnProperty(x)){
                        if (!this.cachedCirclePointers[x].firstRender){
                            this.cachedCirclePointers[x].showPointer();		
                        }
                	}
                }

            } else {
                this.lastRunPaths[i].classList.add('vanish');
                for (var x in this.cachedCirclePointers) {
                	if(this.cachedCirclePointers.hasOwnProperty(x)){
                    	if(this.cachedCirclePointers.hasOwnProperty(x)){
                            this.cachedCirclePointers[x].hidePointer();	
                    	}	
                	}
                }
            }
        }
        if (showLastRun)
            this.showLastRunEl.getElementsByTagName('input')[0].checked = true;
        else
            this.showLastRunEl.getElementsByTagName('input')[0].checked = false;
    }

    function _toggleCurrentGraph(showCurrentGraph) {
        if (showCurrentGraph) {
            this.hideCurrentGraphEl.getElementsByTagName('input')[0].checked = true;
            for (var j in this.circlePointers) {
            	if(this.circlePointers.hasOwnProperty(j)){
                    this.circlePointers[j].showPointer();	
            	}
            }
        } else {
            this.hideCurrentGraphEl.getElementsByTagName('input')[0].checked = false;
            for (var j in this.circlePointers) {
            	if(this.circlePointers.hasOwnProperty(j)){
                    this.circlePointers[j].hidePointer();	
            	}
            }
        }
        for (var i = 0; i <= this.currentPaths.length - 1; i++) {
            if (showCurrentGraph) {
                this.currentPaths[i].classList.remove('hide');
            } else {
                this.currentPaths[i].classList.add('hide');
            }
        }
        for (var x in this.circlePointers) {
        	if(this.circlePointers.hasOwnProperty(x)){
                if (this.toolsData.currentGraph) {
                    this.circlePointers[x].showPointer();
                } else {
                    this.circlePointers[x].hidePointer();
                }	
        	}
        }
    }

    function _toggleInfo(infoOn) {
        if (infoOn) {
            this.infoScreen.classList.add('showInfo');
            this.graphToolBox.classList.remove('open');
            this.multiGraphTool.classList.add('close-icon');
            //
            /**Adding high z index */
            this.parent.classList.add('highZIndex');
        } else {
            this.infoScreen.classList.remove('showInfo');
            this.multiGraphTool.classList.remove('close-icon');
        }

    }

    function _toggleZoom(zoomed) {
        var graphContainer = this.parent;
        if (zoomed) {
            this.multiGraphTool.classList.add('zoom-out-icon');
            graphContainer.classList.add('scaleGraph');
            this.graphToolBox.classList.remove('open');
            this.zoomBackground.classList.remove('hide');
            for (var x in this.circlePointers) {
            	if(this.circlePointers.hasOwnProperty(x)){
                    this.circlePointers[x].hideDirections();	
            	}
            }
        } else {
            graphContainer.classList.remove('scaleGraph');
            this.multiGraphTool.classList.remove('zoom-out-icon');
            this.zoomBackground.classList.add('hide');
            for (var x in this.circlePointers) {
            	if(this.circlePointers.hasOwnProperty(x)){
                    this.circlePointers[x].showDirections();	
            	}
            }
        }
    }

    function _toggleHide(hidden) {
        var graphCurrent = this.parent.children;
        if (hidden) {
            this.graphHide.classList.add("graphShow");
            for (var i = 0; i <= graphCurrent.length - 1; i++) {
                if (!graphCurrent[i].classList.contains('iconContainer')) {
                    graphCurrent[i].classList.add('displayNone');
                }
            }
            this.graphToolBox.classList.remove('open');
            this.multiGraphTool.classList.add('graph-icon');
        } else {
            this.graphHide.classList.remove("graphShow");
            for (var i = 0; i <= graphCurrent.length - 1; i++) {
                graphCurrent[i].classList.remove('displayNone');
            }
            this.multiGraphTool.classList.remove('graph-icon');
        }

    }


    /**
     * draw the yaxis
     * @memberof Graph
     * @method yAxis
     * @this {Graph}
     */
    Graph.prototype.yAxis = function() {
        var lengthY = this.lengthX,
            center = 0,
            yAxis = document.createElementNS('http://www.w3.org/2000/svg', 'line'),
            groupY = document.createElementNS('http://www.w3.org/2000/svg', 'g');
        yAxis.setAttribute('y1', this.offsetInAxis);
        if ((this.xPos === 'center' && this.yPos === 'center') || (this.xPos === 'center')) {
            center = 1;
        }
        if (this.yPos === 'center') {
            var xPos = this.offsetInAxis + ((lengthY - parseInt(lengthY / 2)) * this.xGridWidth);
            yAxis.setAttribute('y2', this.height - this.offsetInAxis - this.yGridWidth * center);
            yAxis.setAttribute('x1', xPos);
            yAxis.setAttribute('x2', xPos);
        } else if (this.xPos === 'center') {
            yAxis.setAttribute('y2', this.height - this.offsetInAxis - this.yGridWidth * center);
            yAxis.setAttribute('x1', this.offsetInAxis);
            yAxis.setAttribute('x2', this.offsetInAxis);
        } else if (this.yPos === 'right' && this.xPos === 'top') {
            yAxis.setAttribute('y2', this.height - this.offsetInAxis);
            yAxis.setAttribute('x1', this.width - this.offsetInAxis);
            yAxis.setAttribute('x2', this.width - this.offsetInAxis);
        } else if (this.yPos === 'right') {
            yAxis.setAttribute('y2', this.height - this.offsetInAxis);
            yAxis.setAttribute('x1', this.width - this.offsetInAxis);
            yAxis.setAttribute('x2', this.width - this.offsetInAxis);
        } else {
            yAxis.setAttribute('y2', this.height - this.offsetInAxis);
            yAxis.setAttribute('x1', this.offsetInAxis);
            yAxis.setAttribute('x2', this.offsetInAxis);
        }
        yAxis.setAttribute('style', 'stroke:' + this.axisStroke + ';stroke-width:' + this.strokeWidth);
        groupY.appendChild(yAxis);
        this.el.insertBefore(groupY, this.graphPath);
    };

    /**
     * draw the xaxis
     * @memberof Graph
     * @method xAxis
     * @this {Graph}
     */
    Graph.prototype.xAxis = function() {
        var lengthX = this.lengthY,
            center = 0,
            xAxis = document.createElementNS('http://www.w3.org/2000/svg', 'line'),
            groupX = document.createElementNS('http://www.w3.org/2000/svg', 'g');
        xAxis.setAttribute('x2', this.width - this.offsetInAxis);
        if ((this.xPos === 'center' && this.yPos === 'center') || (this.yPos === 'center')) {
            center = 1;
        }
        if (this.xPos === 'center') {
            xAxis.setAttribute('x1', (this.offsetInAxis + this.xGridWidth * center));
            var yPos = this.height - this.offsetInAxis - ((lengthX - parseInt(lengthX / 2)) * this.yGridWidth);
            xAxis.setAttribute('y1', yPos);
            xAxis.setAttribute('y2', yPos);
        } else if (this.yPos === 'center') {
            xAxis.setAttribute('x1', this.offsetInAxis + this.xGridWidth * center);
            xAxis.setAttribute('y1', this.height - this.offsetInAxis);
            xAxis.setAttribute('y2', this.height - this.offsetInAxis);
        } else if (this.xPos === 'top' && this.yPos === 'right') {
            xAxis.setAttribute('x1', this.offsetInAxis);
            xAxis.setAttribute('y1', this.offsetInAxis);
            xAxis.setAttribute('y2', this.offsetInAxis);
        } else if (this.xPos === 'top') {
            xAxis.setAttribute('x1', this.offsetInAxis);
            xAxis.setAttribute('y1', this.offsetInAxis);
            xAxis.setAttribute('y2', this.offsetInAxis);
        } else {
            xAxis.setAttribute('x1', this.offsetInAxis);
            xAxis.setAttribute('y1', this.height - this.offsetInAxis);
            xAxis.setAttribute('y2', this.height - this.offsetInAxis);
        }
        xAxis.setAttribute('style', 'stroke:' + this.axisStroke + ';stroke-width:' + this.strokeWidth);
        groupX.appendChild(xAxis);
        this.el.insertBefore(groupX, this.graphPath);
    };




    /**
     * label the xaxis and yaxis grids if labels are true in options
     * @member of Graph
     * @method labelAxis
     * @param {labels[]} labels array of labels
     * @this {Graph}
     */
    Graph.prototype.labelAxis = function(labels) {
        this.lengthX = labels.xAxis.length;
        this.lengthY = labels.yAxis.length;
        var lengthX = this.lengthX,
            lengthY = this.lengthY, yPos, xPos;
        this.xGridWidth = (this.width - this.offsetInAxis * 2) / (lengthX),
            this.yGridWidth = (this.height - this.offsetInAxis * 2) / (lengthY);
        var groupX = document.createElementNS('http://www.w3.org/2000/svg', 'g'),
            groupY = document.createElementNS('http://www.w3.org/2000/svg', 'g');
        if (this.labels.xLabel) {
            for (var i = 0; i < lengthX; i++) {
                var label = document.createElementNS('http://www.w3.org/2000/svg', 'text');
                if (this.xPos === 'center') {
                    yPos = this.height - this.offsetInAxis - ((lengthY - parseInt(lengthY / 2)) * this.yGridWidth);
                    label.setAttribute('x', this.offsetInAxis + ((i + 1) * this.xGridWidth));
                    label.setAttribute('y', yPos + 10);
                } else if (this.xPos === "top" && this.yPos === 'right') {
                    yPos = this.offsetInAxis;
                    label.setAttribute('x', this.offsetInAxis + ((i) * this.xGridWidth) + 15);
                    label.setAttribute('y', yPos - 10);
                } else if (this.xPos === "top") {
                    yPos = this.offsetInAxis;
                    label.setAttribute('x', this.offsetInAxis + ((i + 1) * this.xGridWidth));
                    label.setAttribute('y', yPos - 10);
                } else if (this.xPos === "bottom" && this.yPos === 'right') {
                    yPos = this.height - this.offsetInAxis;
                    label.setAttribute('x', this.offsetInAxis + ((i) * this.xGridWidth));
                    label.setAttribute('y', yPos + 15);
                } else {
                    label.setAttribute('x', this.offsetInAxis + ((i + 1) * this.xGridWidth) + 7);
                    label.setAttribute('y', this.height - this.offsetInAxis + 20);
                }

                label.setAttribute('text-anchor', 'end');
                label.textContent = labels.xAxis[i];
                label.setAttribute('class', 'axis-label');
                groupX.appendChild(label);

            }
            this.el.insertBefore(groupX, this.graphPath);
        }

        if (this.labels.yLabel) {
            for (var i = 0; i < lengthY; i++) {
                var label = document.createElementNS('http://www.w3.org/2000/svg', 'text');
                if (this.yPos === 'center') {
                    xPos = this.offsetInAxis + ((lengthX - parseInt(lengthX / 2)) * this.xGridWidth);
                    label.setAttribute('x', xPos);
                    label.setAttribute('y', this.height - this.offsetInAxis - ((i + 1) * this.yGridWidth) + 10);
                } else if (this.yPos === 'right' && this.xPos === "top") {
                    xPos = this.width - this.offsetInAxis;
                    label.setAttribute('x', xPos + 20);
                    label.setAttribute('y', this.height - this.offsetInAxis - ((i) * this.yGridWidth));
                } else if (this.yPos === 'left' && this.xPos === "top") {
                    xPos = this.offsetInAxis;
                    label.setAttribute('x', xPos - 10);
                    label.setAttribute('y', this.height - this.offsetInAxis - ((i) * this.yGridWidth));
                } else if (this.yPos === 'right' && this.xPos === "bottom") {
                    xPos = this.width - this.offsetInAxis;
                    label.setAttribute('x', xPos + 20);
                    label.setAttribute('y', this.height - this.offsetInAxis - ((i + 1) * this.yGridWidth) + 6);
                } else {
                    label.setAttribute('x', this.offsetInAxis - 10);
                    label.setAttribute('y', this.height - this.offsetInAxis - ((i + 1) * this.yGridWidth) + 3);
                }
                label.setAttribute('text-anchor', 'end');
                label.setAttribute('class', 'axis-label');
                label.textContent = labels.yAxis[i];
                groupY.appendChild(label);
            }
            this.el.insertBefore(groupY, this.graphPath);
        }
    };

    /**
     * draw the grid if drawXGrid or drawYGrid is true in the options
     * @memberof Graph
     *@method drawGrid
     * @this {Graph}
     */
    Graph.prototype.drawGrid = function() {
        var lengthX = this.lengthX,
            lengthY = this.lengthY,
            i,
            center = 0;
        var groupX = document.createElementNS('http://www.w3.org/2000/svg', 'g'),
            groupY = document.createElementNS('http://www.w3.org/2000/svg', 'g');
        /*** Yaxis grids ***/
        if (this.drawYGrid) {
            var lengthx = lengthX;
            if (this.xPos === 'top' || this.yPos === 'right') {
                i = -1;
            } else if ((this.xPos === 'center' && this.yPos === 'center') || this.xPos === 'center') {
                center = 1;
                i = 0;
            } else {
                i = 0;
            }

            for (; i < lengthx; i++) {
                var yGrid = document.createElementNS('http://www.w3.org/2000/svg', 'line');
                yGrid.setAttribute('x1', this.offsetInAxis + ((i + 1) * this.xGridWidth));
                yGrid.setAttribute('y1', this.offsetInAxis);
                yGrid.setAttribute('x2', this.offsetInAxis + ((i + 1) * this.xGridWidth));
                yGrid.setAttribute('y2', this.height - this.offsetInAxis - center * this.yGridWidth);
                yGrid.setAttribute('style', 'stroke:' + this.gridStroke + ';stroke-width:' + this.strokeWidth);
                groupY.appendChild(yGrid);
            }
            this.el.insertBefore(groupY, this.graphPath);
        }
        /*** Xaxis grids ****/
        if (this.drawXGrid) {
            var lengthy = lengthY;
            center = 0;
            if ((this.yPos === 'center' && this.xPos === 'center') || this.yPos === 'center') {
                //lengthy=lengthy-1;
                center = 1;
            }
            if (this.yPos === 'right' || this.xPos === 'top') {
                i = -1;
            } else {
                i = 0;
            }
            for (; i < lengthy; i++) {
                var xGrid = document.createElementNS('http://www.w3.org/2000/svg', 'line');
                xGrid.setAttribute('x1', this.offsetInAxis + center * this.xGridWidth);
                xGrid.setAttribute('y1', this.height - this.offsetInAxis - ((i + 1) * this.yGridWidth));
                xGrid.setAttribute('x2', this.width - this.offsetInAxis);
                xGrid.setAttribute('y2', this.height - this.offsetInAxis - ((i + 1) * this.yGridWidth));
                xGrid.setAttribute('style', 'stroke:' + this.gridStroke + ';stroke-width:1');
                groupX.appendChild(xGrid);
            }
            this.el.insertBefore(groupX, this.graphPath);
        }
    };

    Graph.prototype.showCoordinates = function showCoordinates() {
        for (var i in this.circlePointers) {
        	if(this.circlePointers.hasOwnProperty(i)){
                this.circlePointers[i].showTooltip();	
        	}
        }
    };

    Graph.prototype.hideCoordinates = function hideCoordinates() {
        for (var i in this.circlePointers) {
        	if(this.circlePointers.hasOwnProperty(i)){
                this.circlePointers[i].hideTooltip();	
        	}
        }
    };



    function _refactorCallBacks(callbacks) {

        if (!callbacks) {
            callbacks = {};
        }
        if (!callbacks.update) {
            callbacks.update = function() {};
        }

        if (!callbacks.move) {
            callbacks.move = function() {};
        }
        if (!callbacks.end) {
            callbacks.end = function() {};
        }

        return callbacks;
    }

    function _lastRunHide() {
        for (var i = 0; i <= this.lastRunPaths.length - 1; i++) {
            this.lastRunPaths[i].classList.add('vanish');
        }
    }

    function _appendToGraph(curve, ID) {
        var group = document.createElementNS('http://www.w3.org/2000/svg', 'g');
        group.setAttribute('clip-path', 'url(#path_ID_' + ID + ')');
        group.appendChild(curve);
        this.paths['path' + ID] = curve;
        this.graphPath.appendChild(group);

        if (ID % 1000 !== 0) {
            this.currentPaths.push(curve);
        } else {
            this.lastRunPaths.push(curve);
        }
        if(!this.toolsData.lastRun)
        	_lastRunHide.apply(this, []);
    }

    function _animateGraph(isAnimate, curve) {
        if (isAnimate) {
            if (isAnimate instanceof Object)
                this.animate(curve, isAnimate.duration);
            else {
                this.animate(curve);
            }
        }
    }

    Graph.prototype.prevLine = function(ID, dataPoints, style, isAnimate) {

        if (!this.paths['path' + (ID * 1000)]) {
            var curve = document.createElementNS('http://www.w3.org/2000/svg', 'path');
            _appendToGraph.apply(this, [curve, ID * 1000]);
        } else {

        }
        var lastRunStyle = Object.create(style);
        lastRunStyle.opacity = 0.4;
        var path = "",
            curve = this.paths['path' + ID * 1000];
        path += "M " + (this.convertToSVGX(dataPoints.x1)) + " " + (this.convertToSVGY(dataPoints.y1)) + " ";
        path += "L" + (this.convertToSVGX(dataPoints.x2)) + " " + (this.convertToSVGY(dataPoints.y2));
        curve.setAttribute('d', path);
        _setStyle(curve, lastRunStyle);
    };
    
    Graph.prototype.drawPoint = function(dataPoints, style) {
        var circle = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
        circle.setAttribute('cx', this.convertToSVGX(dataPoints.x1));
        circle.setAttribute('cy', this.convertToSVGY(dataPoints.y1));
        circle.setAttribute('r', 5);
        circle.setAttribute('class', 'point-circle-beaker');
        circle.setAttribute('data-value-y', dataPoints.y1);
        circle.setAttribute('data-value-x', dataPoints.x1);
        this.graphPath.appendChild(circle);
    };

    /**
     * plot a Line between given two points, takes options for animating the path.
     * You can choose whether to show the pointer on the screen or not Pass pointer is true if you need a circle Pointer
     * takes a callback object as the third parameter, move cb(callback) fn(function0 would be called when pointer moves, update is for updating the path on moving the pointer, end cb fn is called on mouseup/touchend of CirclePointer
     * @method drawLine
     * @memberof Graph
     * @param {object} dataPoints
     * @param {object} style
     * @param {boolean | object} isAnimate isAnimate or {duration:1000} duration of animation
     * @param {object} options options to the CirclePointer {move:function(){},end:function(){},update:function(){},pointer:true,isDraggable:true}
     * @example
     * Graph.drawLine({x1:1,x2:3,y1:1,y2:4},{stokeWidth:3},true,{move:function(){},update:function(){},end:function(){},isDraggable:true,pointer:true,snapToGrid:true})
     * @this {Graph}
     * @returns {number} PathID UniqueID of the path
     */
    Graph.prototype.drawLine = function(dataPoints, style, isAnimate, options) {
        var curve1 = document.createElementNS('http://www.w3.org/2000/svg', 'path');
        var curve2 = document.createElementNS('http://www.w3.org/2000/svg', 'path');
        this.pathCount++;
        _appendToGraph.apply(this, [curve1, this.pathCount * 1000]);
        _appendToGraph.apply(this, [curve2, this.pathCount]);
        options = _refactorCallBacks(options);
        options = _circlePointerOption.apply(this, [options]);
        options.initData = dataPoints;
        this.createCirclePointer(options);
        this.lineDraw(this.pathCount, dataPoints, style, isAnimate);
        return this.pathCount;
    };



    /**
     * update existing line. take SVG line element, data, style, isAnimate as options
     * @memberof Graph
     * @method updateLine
     * @param {number} pathId uniqueID of the path
     * @param {object} dataPoints
     * @param {object} style
     * @param {boolean} isAnimate
     * @example
     * Graph.updateLine(line,{x1:1,x2:3,y1:1,y2:4},{stokeWidth:3},false)
     * @this {Graph}
     */
    Graph.prototype.updateLine = function(ID, dataPoints, style, isAnimate) {
        this.lineDraw(ID, dataPoints, style, isAnimate);
        
        if (this.cachedPaths[ID]) {
            _renderSavedCirclePointers.apply(this, []);
            var lastRunStyle = Object.create(style);
            lastRunStyle.opacity = 0.4;
            this.lineDraw(ID * 1000, this.cachedPaths[ID].data, lastRunStyle, false, true);
        }
    };
    
    Graph.prototype.lineDraw = function(ID, dataPoints, style, isAnimate, isCached) {
            var path = "",
                curve = this.paths['path' + ID];
            path += "M " + (this.convertToSVGX(dataPoints.x1)) + " " + (this.convertToSVGY(dataPoints.y1)) + " ";
            path += "L" + (this.convertToSVGX(dataPoints.x2)) + " " + (this.convertToSVGY(dataPoints.y2));
            curve.setAttribute('d', path);
            this.el.setAttribute('viewBox',this.viewBox);
            _setStyle(curve, style);
            if (!isCached) {
                this.circlePointers['path' + ID].update(dataPoints);
            }

            _animateGraph.apply(this, [isAnimate, curve]);
        };


    /**
     * update existing parabola. take SVG line element, data, style, isAnimate as options
     * @memberof Graph
     * @method updateParabola
     * @param {number} pathId uniqueID of the path
     * @param {object} dataPoints
     * @param {object} style
     * @param {boolean | object} isAnimate isAnimate or {duration:1000} duration of animation
     * @example
     * Graph.updateParabolaline(curve,{x1:1,x2:3,y1:1,y2:4},{stokeWidth:3},false)
     * @this {Graph}
     */
    Graph.prototype.updateParabola = function(ID, dataPoints, style, isAnimate) {
        var ctrlX = (dataPoints.x2) / 2,
            ctrlY = dataPoints.y1,
            curve = this.paths['path' + ID];
        var path = "";
        path += "M " + (this.convertToSVGX(dataPoints.x1)) + " " + (this.convertToSVGY(dataPoints.y1)) + " ";
        path += "Q" + (this.convertToSVGX(ctrlX)) + " " + (this.convertToSVGY(ctrlY)) + " ";
        path += (this.convertToSVGX(dataPoints.x2)) + " " + (this.convertToSVGY(dataPoints.y2)) + " ";
        curve.setAttribute('d', path);
        _setStyle(curve, style);
        this.circlePointers['path' + ID].update(dataPoints);
        _animateGraph.apply(this, [isAnimate, curve]);
    };


    /**
     * plot a Line between given two points and fill the area under the curve, takes options for animating the path and showing the graph circle Pointer.
     * You can choose whether to show the pointer on the screen or not Pass pointer is true if you need a circle Pointer
     * takes a callback object as the third parameter, move cb(callback) fn(function0 would be called when pointer moves, update is for updating the path on moving the pointer, end cb fn is called on mouseup/touchend of CirclePointer
     * @memberof Graph
     * @method drawFill
     * @param {object} dataPoints
     * @param {object} style
     * @param {boolean} isAnimate
     * @param {object} options options to the CirclePointer {move:function(){},end:function(){},update:function(){},pointer:true,isDraggable:true}
     * @example
     * Graph.drawFill({x2:3,y2:4,x1:1,y1:1},{stokeWidth:3},true,{move:function(){},update:function(){},end:function(){},isDraggable,pointer:true,})
     * @this {Graph}
     * @returns {number} pathID uniqueID of the path
     */
    Graph.prototype.drawFill = function(dataPoints, styleFill, isAnimate, options) {
        //this.clear();
        var curve = document.createElementNS('http://www.w3.org/2000/svg', 'path');
        this.pathCount++;
        _appendToGraph.apply(this, [curve, this.pathCount]);
        options = _refactorCallBacks(options);
        options = _circlePointerOption.apply(this, [options]);
        options.initData = dataPoints;
        this.createCirclePointer(options);
        this.updateFill(this.pathCount, dataPoints, style, isAnimate);
        return this.pathCount;
    };

    /**
     * update existing line(filled). take SVG line element, data, style, isAnimate as options
     * @memberof Graph
     * @method updateFill
     * @param {number} pathId uniqueID of the path
     * @param {object} dataPoints
     * @param {object} style
     * @param {boolean | object} isAnimate isAnimate or {duration:1000} duration of animation
     * @example
     *  Graph.updateFill(curve,{x1:1,x2:3,y1:1,y2:4},{stokeWidth:3},false)
     * @this {Graph}
     */
    Graph.prototype.updateFill = function(ID, dataPoints, styleFill, isAnimate) {
        var path = "",
            curve = this.paths['path' + ID];
        path += "M " + (this.convertToSVGX(dataPoints.x1)) + " " + (this.convertToSVGY(dataPoints.y1)) + " ";
        path += "L" + (this.convertToSVGX(dataPoints.x2)) + " " + (this.convertToSVGY(dataPoints.y2)) + " " + "L" + (this.convertToSVGX(dataPoints.x2)) + " " + (this.convertToSVGY(dataPoints.y1)) + " " + "Z";
        curve.setAttribute('d', path);
        _setStyle(curve, style);
        this.circlePointers['path' + ID].update(dataPoints);
        _animateGraph.apply(this, [isAnimate, curve]);
    };

    /**
     * plot a rectangle between given two points(provide points diagonally)
     *    _______(x2,y2)
     *    |		|
     *    |		|
     *    |_____|
     * (x1,y1)
     * , takes options for animating the path and showing the graph circle Pointer.
     * You can choose whether to show the pointer on the screen or not Pass pointer is true if you need a circle Pointer
     * takes a callback object as the third parameter, move cb(callback) fn(function0 would be called when pointer moves, update is for updating the path on moving the pointer, end cb fn is called on mouseup/touchend of CirclePointer
     * @memberof Graph
     * @method drawRectangle
     * @param {object} dataPoints
     * @param {object} style
     * @param {boolean} isAnimate
     * @param {object} options options to the CirclePointer {move:function(){},end:function(){},update:function(){},pointer:true,isDraggable:true}
     * @example
     * Graph.drawRectangle({x2:3,y2:4,x1:1,y1:1},{stokeWidth:3},true,{move:function(){},update:function(){},end:function(){},isDraggable,pointer:true,})
     * @this {Graph}
     * @returns {number} pathID uniqueID of the path
     */
    Graph.prototype.drawRectangle = function(dataPoints, style, isAnimate, options) {
        var rect1 = document.createElementNS('http://www.w3.org/2000/svg', 'rect');
        var rect2 = document.createElementNS('http://www.w3.org/2000/svg', 'rect');
        this.pathCount++;
        _appendToGraph.apply(this, [rect1, this.pathCount * 1000]);
        _appendToGraph.apply(this, [rect2, this.pathCount]);

        options = _refactorCallBacks(options);
        options = _circlePointerOption.apply(this, [options]);
        options.initData = dataPoints;
        this.createCirclePointer(options);
        this.updateRectangle(this.pathCount, dataPoints, style, false);
        return this.pathCount;
    };
    
    function _circlePointerOption(options) {
        var obj = {};
        for (var x in options) {
        	if(options.hasOwnProperty(x)){
                obj[x] = options[x];	
        	}
        }
        obj.parent = this;
        obj.name = 'path' + this.pathCount;
        obj.snapToGrid = this.snapToGrid;
        return obj;
    }
    /**
     * update existing rectangle. take SVG line element, data, style, isAnimate as options
     *    _______(x2,y2)
     *    |		|
     *    |		|
     *    |_____|
     * (x1,y1)
     * @memberof Graph
     * @method updateRectangle
     * @param {number} pathId uniqueID of the path
     * @param {object} dataPoints
     * @param {object} style
     * @param {boolean} isAnimate
     * @example
     * Graph.updateLine(curve,{x2:3,y2:4,x1:1,y1:1},{stokeWidth:3},false)
     * @this {Graph}
     */

    Graph.prototype.updateRectangle = function(ID, dataPoints, style) {
        this.RectangleDraw(ID, dataPoints, style);

        if (this.cachedPaths[ID]) {
            _renderSavedCirclePointers.apply(this, []);
            var lastRunStyle = Object.create(style);
            lastRunStyle.opacity = 0.4;
            this.RectangleDraw(ID * 1000, this.cachedPaths[ID].data, lastRunStyle, true);
        }
    };

    /**
     * update existing rectangle. take SVG line element, data, style, isAnimate as options
     *    _______(x2,y2)
     *    |		|
     *    |		|
     *    |_____|
     * (x1,y1)
     * @memberof Graph
     * @method updateRectangle
     * @param {number} pathId uniqueID of the path
     * @param {object} dataPoints
     * @param {object} style
     * @param {boolean} isAnimate
     * @example
     * Graph.updateLine(curve,{x2:3,y2:4,x1:1,y1:1},{stokeWidth:3},false)
     * @this {Graph}
     */

    Graph.prototype.RectangleDraw = function(ID, dataPoints, style, isCached) {
        var curve = this.paths['path' + ID],
            height = (Math.abs(dataPoints.y2 - dataPoints.y1) / this.deltaY) * this.yGridWidth,
            width = (Math.abs(dataPoints.x2 - dataPoints.x1) / this.deltaX) * this.xGridWidth;
        curve.setAttribute('width', width);
        curve.setAttribute('height', height);
        curve.setAttribute('x', this.convertToSVGX(dataPoints.x1));
        if (dataPoints.y2 < 0)
            curve.setAttribute('y', this.convertToSVGY(dataPoints.y1 + (dataPoints.y2 - dataPoints.y1)) - height);
        else
            curve.setAttribute('y', this.convertToSVGY(dataPoints.y1 + (dataPoints.y2 - dataPoints.y1)));
        _setStyle(curve, style);
        this.el.setAttribute('viewBox',this.viewBox);
        if (!isCached) {
            this.circlePointers['path' + ID].update(dataPoints);
        }
    };


    Graph.prototype.drawDottedLine = function(dataPoints, style, isAnimate, pointer) {
        var curve = document.createElementNS('http://www.w3.org/2000/svg', 'path'),
            path = "", options, callbacks;
        path += "M " + (this.convertToSVGX(dataPoints.x1)) + " " + (this.convertToSVGY(dataPoints.y1)) + " ";
        path += "L" + (this.convertToSVGX(dataPoints.x2)) + " " + (this.convertToSVGY(dataPoints.y2));
        curve.setAttribute('d', path);
        _setStyle(curve, style);
        this.graphPath.appendChild(curve);
        callbacks = _refactorCallBacks(callbacks);
        options = _circlePointerOption.apply(this, [options]);
        this.createCirclePointer(options);
        _animateGraph.apply(this, [isAnimate, curve]);
        return curve;
    };

    /**
     * plot a Gaussian normal distribution curve given maximum value(Ymax,mu(mean),sigma(variance) ,takes options for animating the path.
     * Make sure that X axis runs atleat from -5 to +5
     * @memberof Graph
     * @method drawNormalDistribution
     * @param {number} Ymax
     * @param {number} mu
     * @param {number} sigma
     * @param {object} style
     * @param {boolean} isAnimate
     *@param {object} CirclePointerOptions read scrub,move,end and update key from given options
     * @example
     * Graph.drawNormalDistribution(Ymax,mu,sigma,{stokeWidth:3},false)
     * options for the circle pointer
     * options = {
     * scrub: true,
     * move: function(){},
     * update: function(){},
     * end:function(){}
     * }
     * @this {Graph}
     * @returns {number} pathID uniqueID of the path
     */
    Graph.prototype.drawNormalDistribution = function(Ymax, mu, sigma, style, isAnimate, options) {
        var K1 = 1 / (sigma * Math.sqrt(2 * Math.PI)),
            K2 = 2 * Math.pow(sigma, 2),
            Y = [],
            curve = document.createElementNS('http://www.w3.org/2000/svg', 'path'),
            X = [],
            xMax = this.xMaxGridValue,
            power;
        this.pathCount++;
        _appendToGraph.apply(this, [curve, this.pathCount]);
        options = _refactorCallBacks(options);
        for (var i = -xMax; i < xMax;) {
            power = -(Math.pow((i - mu), 2) / K2);
            Y.push((Ymax * 2) * (K1 * Math.exp(power)));
            X.push(i);
            i += 0.006;
        }
        options = _circlePointerOption.apply(this, [options]);
        this.createCirclePointer(options);
        this.updateSmoothPlot(this.pathCount, X, Y, style, isAnimate);
        return this.pathCount;
    };

    /**
     * Update a Gaussian normal distribution curve given maximum value(Ymax,mu(mean),sigma(variance) ,takes options for animating the path.
     * @memberof Graph
     * @method upDateNormalDistribution
     * @param {ID} pathID uniqueID of the path
     * @param {number} Ymax
     * @param {number} mu
     * @param {number} sigma
     * @param {object} style
     * @param {boolean} isAnimate
     * @example
     * Graph.upDateNormalDistribution(curve,Ymax,mu,sigma,{stokeWidth:3},false)
     */
    Graph.prototype.upDateNormalDistribution = function(ID, Ymax, mu, sigma, style, isAnimate) {
        var K1 = 1 / (sigma * Math.sqrt(2 * Math.PI)),
            K2 = 2 * Math.pow(sigma, 2),
            Y = [],
            X = [],
            xMax = this.xMaxGridValue,
            power;
        for (var i = -xMax; i < xMax;) {
            power = -(Math.pow((i - mu), 2) / K2);
            Y.push((Ymax * 2) * (K1 * Math.exp(power)));
            X.push(i);
            i += 0.006;
        }
        this.updateSmoothPlot(ID, X, Y, style, isAnimate);
    };

    function findControlPoints(s1, s2, s3) {
        var dx1 = s1.x - s2.x,
            dy1 = s1.y - s2.y,
            dx2 = s2.x - s3.x,
            dy2 = s2.y - s3.y,
            l1 = Math.sqrt(dx1 * dx1 + dy1 * dy1),
            l2 = Math.sqrt(dx2 * dx2 + dy2 * dy2),
            m1 = {
                x: (s1.x + s2.x) / 2.0,
                y: (s1.y + s2.y) / 2.0
            },
            m2 = {
                x: (s2.x + s3.x) / 2.0,
                y: (s2.y + s3.y) / 2.0
            },
            dxm = (m1.x - m2.x),
            dym = (m1.y - m2.y),
            k = l2 / (l1 + l2),
            cm = {
                x: m2.x + dxm * k,
                y: m2.y + dym * k
            },
            tx = s2.x - cm.x,
            ty = s2.y - cm.y,
            c1 = {
                x: m1.x + tx,
                y: m1.y + ty
            },
            c2 = {
                x: m2.x + tx,
                y: m2.y + ty
            };
        return {
            c1: c1,
            c2: c2
        };
    }

    /**
     * plot any curve given xdata and ydata, takes options for animating the path and smoothing the graph.
     * It also takes options for scrubbing a CirclePointer on the path and provides three callback(move,update,end)
     * if you want scrubbing gives options objects with scrub key true;
     * accepts array of x values and y values
     *  @memberof Graph
     * @method plot
     * @param {array} x
     * @param {array} y
     * @param {object} style
     * @param {boolean | object} isAnimate isAnimate or {duration:1000} duration of animation
     * @param {boolean} smoothen
     * @param {object} CirclePointerOptions read scrub,move,end and update key from given options
     * @example
     * Graph.plot(x[],y[],{stokeWidth:3},{duration:1000},false,options)
     * options for the circle pointer
     * options = {
     * scrub: true,
     * move: function(){},
     * update: function(){},
     * end:function(){}
     * }
     * @this {Graph}
     * @returns {number} pathID uniqueID of the path
     */
    Graph.prototype.plot = function plot(x, y, style, isAnimate, smoothen, options) {
            var curve1 = document.createElementNS('http://www.w3.org/2000/svg', 'path'),
                curve2 = document.createElementNS('http://www.w3.org/2000/svg', 'path');
            this.pathCount++;
            _appendToGraph.apply(this, [curve1, this.pathCount * 1000]);
            _appendToGraph.apply(this, [curve2, this.pathCount]);


            if (!options) {
                options = {
                    scrub: false
                };
            }
            options = _circlePointerOption.apply(this, [options]);
            options.path = curve2;
            this.createCirclePointer(options);

            if (smoothen)
                this.drawSmoothPlot(this.pathCount, x, y, style, isAnimate);
            else
                this.drawPlot(this.pathCount, x, y, style, isAnimate);
            return this.pathCount;
        };
        
    /**
     * store prev Graph data
     * obj = { curve1 : {},curve2 : {} }
     *
     * */
    Graph.prototype.cachedGraphData = function(obj) {
        for (var x in obj) {
        	if(obj.hasOwnProperty(x)){
                this.cachedPaths[x] = obj[x];	
        	}
        }
    };
    
    /**
     * Update previous graph data
     * @memberof Graph
     * @method updateCachedGraphData
     * @param {object} options to tranform the current data, like scaleX, scaleY, shiftX, shiftY etc.
     * @this {Graph}
     *
     * */
    Graph.prototype.updateCachedGraphData = function(options) {
        var scaleX = options.scaleX ? options.scaleX : 1,
        	scaleY = options.scaleY ? options.scaleY : 1,
        	shiftX = options.shiftX ? options.shiftX : 0,
        	shiftY = options.shiftY ? options.shiftY : 0;
        for(var i in this.cachedPaths){
            if(this.cachedPaths.hasOwnProperty(i)){
            	this.cachedPaths[i].data.x = this.cachedPaths[i].data.x*scaleX;
            	this.cachedPaths[i].data.y = this.cachedPaths[i].data.y*scaleY;
            }
        }
    };
    
    /**
     * Store previous circle pointers' data
     * @memberof Graph
     * @method saveCirclePointerData
     * @param {array} names of the circle pointers
     * @this {Graph}
     */
    Graph.prototype.saveCirclePointerData = function(pointers) {
        if (utility.isEmpty(this.cachedCirclePointers)) {
            if (pointers && (pointers.length !== 0)) {
                for (var i = 0; i < pointers.length; i += 1) {
                    var options = {
                        name: pointers[i] + '_clone',
                        parent: this,
                        pointer: true,
                        restrictX: true,
                        restrictY: true,
                        isDraggable: true,
                        movement: false,
                        cachedPointer: true
                    };
                    var circle = new CirclePointer(options);
                    circle.actualPointerName = pointers[i];
                    circle.firstRender = true;
                    circle.updateData({
                        x2: this.circlePointers[pointers[i]].data.x,
                        y2: this.circlePointers[pointers[i]].data.y
                    });
                    this.cachedCirclePointers[circle.name] = circle;
                    this.cachedCirclePointers[circle.name].hidePointer();
                }
            } else {
                for (var x in this.circlePointers) {
                	if(this.circlePointers.hasOwnProperty(x)){
                        var options = {
                                name: this.circlePointers[x].name + '_clone',
                                parent: this,
                                pointer: true,
                                restrictX: true,
                                restrictY: true,
                                isDraggable: true,
                                movement: false,
                                cachedPointer: true
                            };
                            var circle = new CirclePointer(options);
                            circle.actualPointerName = this.circlePointers[x].name;
                            circle.firstRender = true;
                            circle.setPointer({
                                x2: this.circlePointers[x].data.x,
                                y2: this.circlePointers[x].data.y
                            });
                            this.cachedCirclePointers[circle.name] = circle;
                            this.cachedCirclePointers[circle.name].hidePointer();
                	}
                }
            }
        } else {
            for (var x in this.cachedCirclePointers) {
            	if(this.cachedCirclePointers.hasOwnProperty(x)){
                    this.cachedCirclePointers[x].updateData({
                        x2: this.circlePointers[this.cachedCirclePointers[x].actualPointerName].data.x,
                        y2: this.circlePointers[this.cachedCirclePointers[x].actualPointerName].data.y
                    });	
            	}
            }
        }


    };

    /**
     * Render saved previous circle pointers' data
     * @memberof Graph
     * @method renderSavedCirclePointers
     * @this {Graph}
     */
    Graph.prototype.renderSavedCirclePointers = function() {
        _renderSavedCirclePointers.apply(this, []);
    };


    function _renderSavedCirclePointers() {
        for (var x in this.cachedCirclePointers) {
        	if(this.cachedCirclePointers.hasOwnProperty(x)){
                this.cachedCirclePointers[x].setPointer({
                    x2: this.cachedCirclePointers[x].data.x,
                    y2: this.cachedCirclePointers[x].data.y
                });
                this.cachedCirclePointers[x].firstRender = false;
                if (this.toolsData.lastRun) {
                    this.cachedCirclePointers[x].showPointer();
                }
        	}
        }
    }


    /**
     * Update the existing path and connect points with lines
     * accepts array of x values and y values
     *  @memberof Graph
     * @method updatePlot
     * @param {number} pathID uniqueID of the path
     * @param {array} x
     * @param {array} y
     * @param {object} style
     * @param {boolean | object} isAnimate isAnimate or {duration:1000} duration of animation
     * @example
     * Graph.updatePlot(curve,[1,2,3,4],[1,4,9,16],{stokeWidth:3},true)
     * @this {Graph}
     */
    Graph.prototype.updatePlot = function(ID, x, y, style, isAnimate) {
        this.drawPlot(ID, x, y, style, isAnimate);

        if (this.cachedPaths[ID]) {
            _renderSavedCirclePointers.apply(this, []);
            var lastRunStyle = Object.create(style);
            lastRunStyle.opacity = 0.4;
            this.drawPlot(ID * 1000, this.cachedPaths[ID].data.x, this.cachedPaths[ID].data.y, lastRunStyle, false, true);
        }
    };

    Graph.prototype.drawPlot = function(ID, x, y, style, isAnimate, isCached) {
        var length = x.length,
            path = "",
            curve = this.paths['path' + ID];
        path += "M" + this.convertToSVGX(x[0]) + " " + this.convertToSVGY(y[0]) + " ";
        for (var i = 1; i <= length - 1; i++) {
            path += "L" + this.convertToSVGX(x[i]) + " " + this.convertToSVGY(y[i]) + " ";
        }
        this.el.setAttribute('viewBox',this.viewBox);
        if (!isCached) {
            this.circlePointers['path' + ID].update({
                x2: x[length - 1],
                y2: y[length - 1]
            });
        }

        curve.setAttribute('d', path);
        _setStyle(curve, style);
        _animateGraph.apply(this, [isAnimate, curve]);
    };


    function _setStyle(path, style) {
        for (var n in style) {
                path.style[n] = style[n];	
        }
    }

    /**
     * Update the existing path and connect points with smooth curves
     * accepts array of x values and y values
     * @memberof Graph
     * @method updateSmoothPlot
     * @param {number} pathID uniqueID of the path
     * @param {array} x
     * @param {array} y
     * @param {object} style
     * @param {boolean} isAnimate
     * @example
     * Graph.updateSmoothPlot(curve,[1,2,3,4],[1,4,9,16],{stokeWidth:3},true)
     * @this {Graph}
     */
    Graph.prototype.updateSmoothPlot = function(ID, x, y, style, isAnimate) {
        this.drawSmoothPlot(ID, x, y, style, isAnimate);
        if (this.cachedPaths[ID]) {
            _renderSavedCirclePointers.apply(this, []);
            var lastRunStyle = Object.create(style);
            lastRunStyle.opacity = 0.4;
            this.drawSmoothPlot(ID * 1000, this.cachedPaths[ID].data.x, this.cachedPaths[ID].data.y, lastRunStyle, false, true);
        }
    };

    Graph.prototype.drawSmoothPlot = function(ID, x, y, style, isAnimate, isCached) {
        var length = x.length,
            s1 = {},
            s2 = {},
            s3 = {},
            s4 = {},
            S1,
            S2,
            path = "",
            curve = this.paths['path' + ID];
	        x = [x[0]].concat(x);
	        y = [y[0]].concat(y);
	        x.push(x[length]);
	        y.push(y[length]);

        path += "M" + this.convertToSVGX(x[0]) + " " + this.convertToSVGY(y[0]) + " ";


        for (var i = 0; i < length - 1; i++) {
            s1.x = this.convertToSVGX(x[i]);
            s1.y = this.convertToSVGY(y[i]);
            s2.x = this.convertToSVGX(x[i + 1]);
            s2.y = this.convertToSVGY(y[i + 1]);
            s3.x = this.convertToSVGX(x[i + 2]);
            s3.y = this.convertToSVGY(y[i + 2]);
            s4.x = this.convertToSVGX(x[i + 3]);
            s4.y = this.convertToSVGY(y[i + 3]);
            S1 = findControlPoints(s1, s2, s3);
            S2 = findControlPoints(s2, s3, s4);
            path += "C " + S1.c2.x + " " + S1.c2.y + ", " + S2.c1.x + " " + S2.c1.y + ", " + s3.x + " " + s3.y + " ";
        }
        this.el.setAttribute('viewBox',this.viewBox);
        if (!isCached) {
            this.circlePointers['path' + ID].update({
                x2: x[x.length - 1],
                y2: y[x.length - 1]
            });
        }
        curve.setAttribute('d', path);
        _setStyle(curve, style);
        _animateGraph.apply(this, [isAnimate, curve]);
    };

    /**
     * Animate path smoothly using requestAnimationFrame. Default duration value is 1sec
     *  @memberof Graph
     * @method animate
     * @param {path} curve
     * @this {Graph}
     */
    Graph.prototype.animate = function(curve, duration) {
            var pathAnim = {}, length;
            pathAnim.path = curve;
            length = pathAnim.path.getTotalLength();
            pathAnim.length = length;
            pathAnim.path.style.strokeDasharray = length + ' ' + length;
            pathAnim.path.style.strokeDashoffset = length;
            this.el.setAttribute('viewBox',this.viewBox);
            this._duration = duration || 1000;
            this._startTime = Date.now();
            this.animation(curve, pathAnim.length);
        };
        /**
         * Animate path smoothly using requestAnimationFrame.
         *  @memberof Graph
         * @method animation
         * @param {path} currentPath
         * @param {number} length
         * @this {Graph}
         */
    Graph.prototype.animation = function(currentPath, length) {
        var self = this,
            timeSinceStart = Date.now() - this._startTime, progress;
        if (timeSinceStart > this._duration) {
            currentPath.style.strokeDasharray = 0;
            this.el.setAttribute('viewBox',this.viewBox);
            window.cancelAnimationFrame(this.handle);
        } else {
            progress = timeSinceStart / this._duration;
            currentPath.style.strokeDashoffset = Math.floor(length * (1 - progress));
            this.el.setAttribute('viewBox',this.viewBox);
            this.handle = window.requestAnimationFrame(function() {
                self.animation(currentPath, length);
            });
        }
    };

    /**
     * Convert SVG coordinate to graph coordinates
     * @memberof Graph
     * @method convertFromSVGY
     * @param {number} y
     * @return {number} graphCoordinate coordinate converted from svg to graph
     */
    Graph.prototype.convertFromSVGY = function convertFromSVGY(y) {
    	/**Modified*/
        if (this.xPos === 'top'){
        	var value = -(((y - this.offsetInAxis) / this.yGridWidth) * this.deltaY);
            return parseFloat(value.toPrecision(12));	
        }
        else{
        	var value = this.yMaxGridValue - (((y - this.offsetInAxis) / this.yGridWidth) * this.deltaY);
            return  parseFloat(value.toPrecision(12));		
        }
    };

    /**
     * Convert SVGX coordinate to graphX coordinate
     * @memberof Graph
     * @method convertFromSVGX
     * @param {number} x
     * @return {number} graphCoordinate coordinate converted from svg to graph
     */
    Graph.prototype.convertFromSVGX = function convertFromSVGX(x) {
    	/**Modified*/
    	var value = this.xMaxGridValue - (((this.width - x - this.offsetInAxis) / this.xGridWidth) * this.deltaX);
    	 return  parseFloat(value.toPrecision(12));	
    };


    /**
     *  Conversion dataX to SVG coordinate X
     *  @memberof Graph
     * @method convertToSVGX
     * @param {number} x
     * @return {number} svgCoordinates graph coordinate that is converted to svg coordinate
     * @this {Graph}
     */
    Graph.prototype.convertToSVGX = function(x) {
    	var range,
		sign = x>0?1:-1,
		percentage;
		 x = parseFloat(x.toFixed(3));
	if(this.xPos ==='top' && this.yPos === 'right' || (this.xPos==='bottom' && this.yPos==='right')){
				x = -x;
				sign = -sign;
	}
	if(this.yPos === 'center')
	  range = this.xMaxGridValue - this.xMinGridValue;
	else
	  range = this.xMaxGridValue;
	var noOfFullGrids = parseInt((range-(this.xMaxGridValue-x))/this.deltaX);
	/*var reminder      = x%this.deltaX;*/
	x%this.xMinGridValue;
	var reminder;
	if(this.yPos === 'center'){
		noOfFullGrids = noOfFullGrids+1;
		if(sign<0)
		 reminder      = x-(this.xMinGridValue + (noOfFullGrids*this.deltaX));
		else
			 reminder      = x-(this.xMinGridValue + ((noOfFullGrids-1)*this.deltaX));
	}else{
		 reminder      = x-(noOfFullGrids*this.deltaX);
	}
		
	reminder = parseFloat(reminder.toFixed(3));
	
	
	if(sign<0 && reminder!=0){
	    percentage = 1-Math.abs((reminder/this.deltaX)*sign);
	}
	else
		percentage = Math.abs((reminder/this.deltaX));
	var xInSVG = (noOfFullGrids*this.xGridWidth)+(percentage*this.xGridWidth)+this.offsetInAxis;
		if(this.xPos === 'top' && this.yPos === 'right' || (this.xPos==='bottom' && this.yPos==='right'))
		return this.width-this.offsetInAxis-(noOfFullGrids*this.xGridWidth)-(percentage*this.xGridWidth);
		else 
		return xInSVG
    };

    /**
     * Conversion dataY to SVG coordinate Y
     *  @memberof Graph
     * @method convertToSVGY
     * @param {number} y
     * @this {Graph}
     */
    Graph.prototype.convertToSVGY = function(y) {
    	var sign = y>0?1:-1,
      		     range,
      		     percentage;
      		 y = parseFloat(y.toFixed(3));
      		 
      			if(this.xPos ==='top' ){
      				y = -y;
      				sign = -sign;
      			}
      		if(this.xPos === 'center')
      			  range = this.yMaxGridValue - this.yMinGridValue;
      			else
      			  range = this.yMaxGridValue;
      		var noOfFullGrids = parseInt((range-(this.yMaxGridValue-y))/this.deltaY);
      		/*var reminder      = y%this.deltaY;*/
      		var reminder;
      		if(this.xPos === 'center'){
      			noOfFullGrids = noOfFullGrids+1;
      			if(sign<0)
      			 reminder      = y-(this.yMinGridValue + (noOfFullGrids*this.deltaY));
      			else
      				reminder      = y-(this.yMinGridValue + ((noOfFullGrids-1)*this.deltaY));
      		}else{
      			reminder      = y-(noOfFullGrids*this.deltaY);
      		}
      		
      		reminder = parseFloat(reminder.toFixed(3));
      		if(sign<0 && reminder!=0){
      		    percentage = 1-Math.abs((reminder/this.deltaY));
      		}
      		else
      			percentage = Math.abs((reminder/this.deltaY));
      		var yInSVG = this.height-this.offsetInAxis-((noOfFullGrids)*this.yGridWidth)-(percentage*this.yGridWidth);
      		if(this.yPos === 'right' && this.xPos ==='top' || (this.yPos==='left' && this.xPos==='top'))
      		return ((noOfFullGrids)*this.yGridWidth)+(percentage*this.yGridWidth)+this.offsetInAxis;
      		else 
      		return yInSVG
    };

    /**
     * Creating a graphPointer, takes options: name,move,end,update,pointer(boolean),snapToGrid
     *  @memberof Graph
     * @method createCirclePointers
     * @param {object} options
     * @this {Graph}
     */
    Graph.prototype.createCirclePointer = function(options) {
        var size = utility.size(this.circlePointers), index = parseInt(size) + 1, circle;
        this.circlePointerArray.push(options.name);
        circle = new CirclePointer(options);
        this.circlePointers[options.name] = circle;
        circlePointerBucket.push(circle.el);
        return circle;
    };



    /**
     * empty graph
     *  @memberof Graph
     * @method clear
     * @this {Graph}
     */
    Graph.prototype.clear = function() {
        utility.emptyElement(this.graphPath);
        utility.emptyElement(this.circleLine);
    };
    
    /**
     * render graph on the given container
     * empty graph
     *  @memberof Graph
     * @method render
     * @param {element} parent
     * @this {Graph}
     */
    Graph.prototype.render = function(parent) {
    	var graphZoomedMessage, graphZoomedMessageIcon, graphZoomedMessageConatiner;
        if (this.options.parent) {
            this.options.parent.appendChild(this.el);
        } else {
            parent.appendChild(this.el);
        }
        this.zoomBackground = document.createElement('div');
		this.zoomBackground.classList.add('zoom-background');
		this.zoomBackground.classList.add('hide');
		graphZoomedMessage = document.createElement('div');
		graphZoomedMessage.classList.add('graph-zoomed-message');
		graphZoomedMessage.innerHTML = "Graph manipulations are not supported in the zoomed in mode.";
		graphZoomedMessageIcon = document.createElement('div');
		graphZoomedMessageIcon.classList.add('graph-zoomed-message-icon');
		graphZoomedMessageConatiner = document.createElement('div');
		graphZoomedMessageConatiner.classList.add('graph-zoomed-message-container');
		graphZoomedMessageConatiner.appendChild(graphZoomedMessageIcon);
		graphZoomedMessageConatiner.appendChild(graphZoomedMessage);
		this.zoomBackground.appendChild(graphZoomedMessageConatiner);
		parent.appendChild(this.zoomBackground);
    };

   
    return Graph;
});;define('ProgressBar', ['SimObject', 'StaticObject', 'Matrix', 'easing'], function(SimObject, StaticObject, Matrix, easing) {

    /**
     * creates Instance of progress bar
     * @constructor ProgressBar
     * @param {number} duration duration of progress animation in seconds
     */
    function ProgressBar(duration) {
        this._duration = duration;
        _init.call(this);
    }


    function _init() {
        this._progressBar = new StaticObject({
                name: 'videoProgress',
                classes: ['progressbar-container']
            }),
            this._showProgress = new SimObject({
                name: 'showProgress',
                classes: ['show-progress']
            }),
            this._progressPointer = new SimObject({
                name: 'progressPointer',
                classes: ['progress-pointer']
            });
        this._progressBar.addsimObject([this._showProgress, this._progressPointer]);
        this.el = this._progressBar.el;
    }

    /**
     * start the video progress
     * @method start
     * @memberof ProgressBar
     */
    ProgressBar.prototype.start = function() {
        var x = this._progressBar.el.clientWidth - this._progressPointer.el.clientWidth,
            x1 = x + this._progressPointer.el.clientWidth / 2;
        this._progressPointer.transform(Matrix.translate(x, 0, 0), {
            duration: this._duration,
            curve: easing.linear
        });
        this._showProgress.transform(Matrix.translate(x1, 0, 0), {
            duration: this._duration,
            curve: easing.linear
        });
    };

    /**
     * reset progressBar to the original state
     * @method reset
     * @memberof ProgressBar
     */
    ProgressBar.prototype.reset = function() {
        this._progressPointer.resetTransform();
        this._showProgress.resetTransform();
    };

    /**
     * update the progress bar animation
     * @method update
     * @memberof ProgressBar
     */
    ProgressBar.prototype.update = function() {
        var pointerTransform = this._progressPointer.manipulate();
        var progressTransform = this._showProgress.manipulate();
        this._progressPointer.update(pointerTransform.transform, pointerTransform.size, pointerTransform.opacity, pointerTransform.origin);
        this._showProgress.update(progressTransform.transform, progressTransform.size, progressTransform.opacity, progressTransform.origin);
    };

    /**
     * Pause the progress 
     * @method pause
     * @memberof ProgressBar
     */
    ProgressBar.prototype.pause = function() {
        this._progressPointer.pause();
        this._showProgress.pause();
    };

    ProgressBar.prototype.render = function(container) {
        container.appendChild(this.el);
    };

    return ProgressBar;
});;define('Slider', ['SoModel', 'EventHandler'], function(SoModel, eventHandler) {

    /**
     * Creates an instance of Circle.
     *
     * @constructor Slider
     * @param {object} desired options to the slider
     * @example
     * 	 	var noOfFriends = new Slider({min: 1, max: 3, shifts: ['one','two','three'],label:true ,UILabel:'No. of Friends = ',UIValue:"",parameter:'noOfFriends',classes:['slider-patch','noOfFriends-slider'] ,discrete:false, move: function(value,fd,newvalue){
     *		sbScene.emit('change.noOfFriends',{value:value,data:newvalue},noOfFriends);
     *	},end:function(){
     *		sbScene.emit('init.animation',undefined,noOfFriends);
     *	}});
     *
     */
	  var classArray, sliderName ;
	
	
    function Slider(options) {
        this.options = options || {};
        this.Model = new SoModel();
        this.data = this.Model.data;
        this.eventHandler = new eventHandler();
        this.name = 'slider';
        if (this.options.discrete) {
            this.options.max == this.options.max;
            this.options.min == this.options.min;
        }


        for (var i in defaults) {
            if (options[i] === undefined) {
                this.options[i] = defaults[i];
            }
        }
        if (options && options.vertical && options.vertical === true) {
            this.createVerticalSlider();
        } else {
            this.createHorizontalSlider();
        }

        this.slider = this.create('span', 'range-bar');

        this.mouseDownForward = function(event) {
            if (this.slider.classList.contains('disable-slider')) {
                return;
            }
            if (event.touches) {
                document.addEventListener('touchmove', this.mouseMoveForward);
                document.addEventListener('touchend', this.mouseUpForward);
            } else {
                document.addEventListener('mousemove', this.mouseMoveForward);
                document.addEventListener('mouseup', this.mouseUpForward);
            }
            this.eventHandler.emit(event.type, event, this);
        }.bind(this);

        this.mouseUpForward = function(event) {
            if (event.touches) {
                document.removeEventListener('touchmove', this.mouseMoveForward);
                document.removeEventListener('touchend', this.mouseUpForward);
            } else {
                document.removeEventListener('mousemove', this.mouseMoveForward);
                document.removeEventListener('mouseup', this.mouseUpForward);
            }

            this.options.end.call(this);
            
             classArray = this.el.classList ;
            for(var i = 0 ; i < classArray.length ; i++){
            	if(classArray[i] != "slider-patch"){
            		 sliderName = classArray[i] ;
            	}
            	}
            var widgetType, widgetName ;
           /* dexterjs.logEvent("FBS_WIDGET", {
                widgetType :  "slider" ,
                widgetName : sliderName 
            });*/
            
            this.eventHandler.emit(event.type, event, this); /** changed  for the slider issue (in case of custom UI value , on click of handle UI value should automatically updated according slider position ) */
        }.bind(this);

        this.mouseMoveForward = function(event) {
            this.eventHandler.emit(event.type, event, this);
        }.bind(this);


        this.set();
        this.Model.data[options.parameter] = this.options.start;
        this.Model.eyesOn(this.options.move);
    }

    /**
     * Default values of options of model
     * @default defaults
     */
    var defaults = {
        move: function() {},
        decimal: false,
        discrete: false,
        disable: false,
        disableOpacity: 0.5,
        hideRange: false,
        klass: '',
        min: 0,
        max: 100,
        start: null,
        step: null,
        vertical: false,
        parameter: 'parameter',
        UILabel: 'parameter',
        UIValue: 'paramValue',
        UIUnit: "",
        sliderInfo: "",
        sliderInfoSet: true,
        classes: 'slider-wrapper',
        end: function() {}
    };

    /**
     * setting the slider
     *
     * @method set
     * @param{object} handle - element
     * @memberof Slider
     */
    Slider.prototype.set = function(handle) {
        _generate.call(this);
    };


     function _generate() {
        var elems = {
            'handle': {
                'type': 'span',
                'selector': 'range-handle'
            },
            'quantity': {
                'type': 'span',
                'selector': 'range-quantity'
            }
        };

        for (var key in elems) {
            if (elems.hasOwnProperty(key)) {
                var temp = this.create(elems[key].type, elems[key].selector);
                this.slider.appendChild(temp);
            }
        }

        this.sliderObj.infoIcon = this.create('div', 'slider-info-icon');
        _showInfoHandler.call(this, this.sliderObj.infoIcon);
        if (!this.options.sliderInfoSet) {
            this.sliderObj.infoIcon.classList.add('hide-slider');
        }
        if (this.options.sliderInfo === "") {
            this.sliderObj.infoIcon.classList.add("hide");
        }

        this.sliderObj.handle = this.slider.querySelector('.range-handle');
        this.handle = this.sliderObj.handle;
        this.sliderObj.slider = this.slider;
        _bindEvents.call(this, this.sliderObj.handle);
        this.setRange(this.options);

    }

    function _showInfoHandler(elem) {
    	this.sliderInfoTransitionCheck = false;
        elem.addEventListener('click', function(e) {
            //e.stopPropagation();
            var info = this.sliderObj.info;
            var close = info.querySelector('.slider-info-close');
            /**Adding high z index*/
            this.el.classList.add('highZIndex');
            close.addEventListener('click', function(ev) {
                ev.stopPropagation();
              
                closeIcon(ev);
            });

            info.addEventListener('click', function(ev) {
                ev.stopPropagation();
            });
            //write here condition ....for transition up/down
            if(!this.sliderInfoTransitionCheck){
            	  if((this.el.offsetTop-info.clientHeight)<50){
                 	 info.classList.add("down-info-transition");
                 }else{
                	 info.classList.add("up-info-transition");
                 }
            	  this.sliderInfoTransitionCheck = true;
            }
            	  info.style.webkitTransform = 'scale(1)';
                  info.style.transform = 'scale(1)';

            var closeIcon = _closeInfo.bind(this);

            document.addEventListener('click', closeIcon);
            //for touch devices 
            document.addEventListener('touchstart', closeIcon);

            function _closeInfo(e) {
            	 if (e.touches) e = e.touches[0];
              
            	 if (e.target == this.sliderObj.info || e.target == this.sliderObj.infoIcon)
                    return;
                /**Removing high z index*/
                this.el.classList.remove('highZIndex');
                info.style.webkitTransform = 'scale(0)';
                info.style.transform = 'scale(0)';
                document.removeEventListener('click', closeIcon);
                document.removeEventListener('touchstart', closeIcon);
            }

        }.bind(this));
    }


    function _bindEvents(handle) {
        var that = this;
        if ("ontouchstart" in document) {
            handle.addEventListener('touchstart', function(event) {
                event.preventDefault();
                that.mouseDownForward(event);
            });
        }
        handle.addEventListener('mousedown', this.mouseDownForward);
        this.eventHandler.on('mousedown', this.onmousedown);
        this.eventHandler.on('mousemove', this.onmousemove);
        this.eventHandler.on('mouseup', this.onmouseup);
        this.eventHandler.on('touchstart', this.onmousedown);
        this.eventHandler.on('touchmove', this.onmousemove);
        this.eventHandler.on('touchend', this.onmouseup);
    }


    /**
     * creating the element type
     * @method create
     * @memberof Slider
     * @return{element}
     * @param{string} type - type of element eg. div
     * @param{string} name - id of the element
     */
    Slider.prototype.create = function(type, name) {
        var elem = document.createElement(type);
        elem.className = name;
        return elem;
    };

    /**
     * setting the initial data
     * @method setData
     * @memberof Slider
     * @param {object} data - data-set for soModel
     */
    Slider.prototype.setData = function(data) {
        this.data = data;
        this.soModel.set(data);
    };



    /**
     * onmousemove event on the handle
     * @method onmousemove
     * @memberof Slider
     */
    Slider.prototype.onmousemove = function(e) {
        this.onmousemove(e);
    };

    /**
     * onmouseup event on the handle
     * @method onmouseup
     * @memberof Slider
     */
    Slider.prototype.onmouseup = function(e) {
        this.onmouseup(e);
    };

    /**
     * onmousedown event on the handle
     * @method onmousedown
     * @memberof Slider
     */
    Slider.prototype.onmousedown = function(e) {
        this.onmousedown(e);
    };

    /**
     * setting the value on the change
     * @method setValue
     * @memberof Slider
     * @param{number} offset - distance from origin of container
     * @param{number} size - size of slider
     */
    Slider.prototype.setValue = function(offset, size) {
        var part = percentage.from(parseFloat(offset), size),
            value = percentage.of(part, this.options.max - this.options.min) + this.options.min,
            changed = false;

        value = (this.options.decimal) ? (Math.round(value * 100) / 100) : Math.round(value);
        changed = (this.element.value != value) ? true : false;
        if (this.options.discrete === false) {
            this.element.value = value;
            this.model.data[this.options.UIValue] = value;
            this.model.data[this.options.parameter] = value;
            this.labelValue.innerHTML = value + "" + this.options.UIUnit;
        } else if (this.options.discrete === true) {
            this.element.value = value;
            this.model.data[this.options.UIValue] = this.options.shifts[value - 1];
            this.model.data[this.options.parameter] = this.options.shifts[value - 1];

            this.labelValue.innerHTML = this.model.data[this.options.UIValue] + "" + this.options.UIUnit;
        }
        this.currentPosition = value;
    };


    /**
     * setting the range
     * @method setRange
     * @memberof Slider
     * @param {object} options - soModel options
     */
    Slider.prototype.setRange = function(options) {
        if (options.discrete === false) {
            if (typeof this.options.min === 'number' && typeof this.options.max === 'number' && !this.options.hideRange) {}
        } else if (this.options.discrete === true) {
            if (this.options.shifts.length) {}
        }

    };


    /**
     * initialising Horizontal slider event on the handle
     *	@method createHorizontalSlider
     *@memberof Slider
     */

    Slider.prototype.createHorizontalSlider = function() {
            this.sliderObj = new horizontalSlider();
            this.sliderObj.setValue = this.setValue;
            this.sliderObj.unselectable = this.unselectable;
            this.sliderObj.options = this.options;
            this.sliderObj.model = this.Model;
            this.sliderObj.eventHandler = this.eventHandler;
            this.eventHandler.bindThis(this.sliderObj);
        };
        /**
         * initialising Vertical slider event on the handle
         * @method createVerticalSlider
         * @memberof Slider
         */
    Slider.prototype.createVerticalSlider = function() {
        //this.sliderObj = new verticalSlider();
        this.eventHandler.bindThis(this.sliderObj);
    };

    /**
     * rendering the slider
     * @method render
     * @memberof Slider
     * @param{element} parent - container to render present element
     */

    Slider.prototype.render = function(parent) {
        var sliderElement = document.createElement('div');
        var length = this.options.classes.length;
        for (var i = 0; i < length; i++) {
            sliderElement.classList.add(this.options.classes[i]);
        }

        sliderElement.innerHTML = '<input class="js-customized" id="inputBox"></input><span class="label-slider"></span><span class="slider-value"></span>' + '<div class="slider-info"><div class="slider-info-close"></div><div class="slider-info-text">' + this.options.sliderInfo + '</div></div>';


        this.el = sliderElement;
        this.el.appendChild(this.sliderObj.infoIcon);
        this.sliderObj.element = this.el;
        this.sliderObj.element = this.el.querySelector('.js-customized');
        this.sliderObj.labelName = this.el.querySelector('.label-slider');
        this.sliderObj.labelValue = this.el.querySelector('.slider-value');
        this.sliderObj.info = this.el.querySelector('.slider-info');
        this.sliderObj.element.style.display = 'none';
        if (this.options.label === false) {
            this.sliderObj.labelName.style.display = 'none';
        }
        this.sliderObj.labelName.innerHTML = this.options.UILabel;
        this.sliderObj.labelValue.innerHTML = this.options.UIValue + "" + this.options.UIUnit;
        this.el.appendChild(this.slider);
        parent.appendChild(this.el);
    };

    /**
     * adding unselectable class to disable the slider
     * @method unselectable
     * @memberof Slider
     * @param {element} element - element that need to be added the unselectable class
     * @param {boolean} set - true or false
     */
    Slider.prototype.unselectable = function(element, set) {
        if (!this.slider.classList.contains('unselectable') && set === true) {
            this.slider.classList.add('unselectable');
        } else {
            this.slider.classList.remove('unselectable');
        }
    };

    /**
     * adding disable class to the slider
     * @method disable
     * @memberof Slider
     */
    Slider.prototype.disable = function() {
        this.slider.classList.add('disable-slider');
    };

    /**
     * adding disable class to the slider
     * @method disable
     * @memberof Slider
     */
    Slider.prototype.enable = function() {
        this.slider.classList.remove('disable-slider');
    };

    /**
     * updating the slider values using the values
     * @method update
     * @memberof Slider
     * @param{number} value - updated value of the slider
     */
    Slider.prototype.update = function(value) {
        this.sliderObj.setStart(value);
    };


    function horizontalSlider() {
        this.position = null;
    }

    /**
     * setting the start position
     * @method setStart
     * @memberof Slider
     * @param {nuber} start - default value of the slider
     */
    horizontalSlider.prototype.setStart = function(start) {
        var begin = (start === null) ? this.options.min : start,
            part = percentage.from(begin - this.options.min, this.options.max - this.options.min) || 0,
            offset = percentage.of(part, this.slider.offsetWidth - this.handle.offsetWidth),
            position = (this.options.step) ? closest.find(offset, this.steps) : offset;

        this.setPosition(position);
        this.setValue(this.position, this.slider.offsetWidth - this.handle.offsetWidth);
    };


    /**
     * horizontalSlider : setting initial position
     * @method setPosition
     * @memberof Slider
     * @param {number} val - start left position of slider handle in pixel
     */

    horizontalSlider.prototype.setPosition = function(val) {
        this.position = val;
        var wid = this.handle.offsetWidth;
        this.handle.style.webkitTransform = 'translateX(' + this.position + 'px)';
        this.handle.style.transform = 'translateX(' + this.position + 'px)';
        this.slider.querySelector('.range-quantity').style.width = val + wid / 3 + 'px';
    };


    /**
     * horizontalSlider : onmousedown event
     * @method onmousedown
     * @memberof Slider
     */
    horizontalSlider.prototype.onmousedown = function(e) {
        if (e.touches) e = e.touches[0];
        this.startX = e.clientX;
        this.handleOffsetX = this.position;
        this.restrictHandleX = this.slider.offsetWidth - this.handle.offsetWidth;
        this.unselectable(this.slider, true);
    };

    /**
     * horizontalSlider : onmousemove event
     * @method onmousemove
     * @memberof Slider
     */
    horizontalSlider.prototype.onmousemove = function(e) {
    	/*var slideAudio = document.createElement('audio');
    	slideAudio.id = "simSlide";
    	slideAudio.src = "../allspark/assets/music/beep-xylo.mp3";
    	slideAudio.preload = "auto";
    	slideAudio.play(); to add trnsition music */
        e.preventDefault();
        if (e.touches) e = e.touches[0];
        var leftOffset = this.handleOffsetX + e.clientX - this.startX,
            position = (this.steps) ? closest.find(leftOffset, this.steps) : leftOffset;

        if (leftOffset <= 0) {
            this.setPosition(0);
        } else if (leftOffset >= this.restrictHandleX) {
            this.setPosition(this.restrictHandleX);
        } else {
            this.setPosition(position);
        }
        this.setValue(this.position, this.slider.offsetWidth - this.handle.offsetWidth);
    };

    /**
     * horizontalSlider : onmouseup event
     * @method onmouseup
     * @memberof Slider
     */
    horizontalSlider.prototype.onmouseup = function(e) {
    	this.setValue(this.position, this.slider.offsetWidth - this.handle.offsetWidth);
        this.unselectable(this.slider, false);
    };

    var percentage = {

        isNumber: function(num) {
            return (typeof num === 'number') ? true : false;
        },

        of: function(perc, num) {
            if (this.isNumber(perc) && this.isNumber(num)) return (perc / 100) * num;
        },

        from: function(part, target) {
            if (this.isNumber(part) && this.isNumber(target)) return (part / target) * 100;
        }

    };


    var closest = function(element, selector, checkYoSelf, root) {
        element = checkYoSelf ? {
            parentNode: element
        } : element;

        root = root || document;
        while ((element = element.parentNode) && element !== document) {
            if (matches(element, selector))
                return element;
            if (element === root)
                return;
        }
    };

    return Slider;


});;define('Toggle', ['EventHandler', 'SoModel'], function(EventHandler, SoModel) {

    /**
     * Creates an instance of toggle
     * @constructor Toggle
     * @param {object}  options to the toggle
     * @example
     *
     *  end callback after toggle, switchType for type of toggle required
     * 	var FDB = new Toggle ({
     * 					start : 0 ||1 ,
     * 					end: function)(){},
     * 					switchType : true || false,
     * 					info : "toggle information",
     * 					UILabel: "toggle name",
     * 					shifts :['On','Off] || ['left','right'],
     * 					classes:['class1','class2']
     * 				});
     *
     */
	
	var toggleName ;
	
    function Toggle(options) {
        this.options = options || {};
        this.model = new SoModel({
            checked: false
        });
        this.data = this.model.data;
        this.offsetX = 0;
        this.move = false;

        this.eventHandler = new EventHandler();
        this.eventHandler.bindThis(this);
        for (var i in defaults) {
            if (this.options[i] === undefined) {
                this.options[i] = defaults[i];
            }
        }

        this.mouseDownFwd = function(e) {

            if (this.isDisable) {
                return;
            }

            e.stopPropagation();
            e.preventDefault();
            if (e.touches) {
                document.addEventListener('touchmove', this.mouseMoveFwd);
                document.addEventListener('touchend', this.mouseUpFwd);
            } else {
                document.addEventListener('mousemove', this.mouseMoveFwd);
                document.addEventListener('mouseup', this.mouseUpFwd);
            }
            this.eventHandler.emit(e.type, e);
        }.bind(this);

        this.mouseUpFwd = function(e) {
            e.stopPropagation();
            if (e.touches) {
                document.removeEventListener('touchmove', this.mouseMoveFwd);
                document.removeEventListener('touchend', this.mouseUpFwd);
            } else {
                document.removeEventListener('mousemove', this.mouseMoveFwd);
                document.removeEventListener('mouseup', this.mouseUpFwd);
            }
            this.eventHandler.emit(e.type, e);
        }.bind(this);

        this.mouseMoveFwd = function(e) {
            this.eventHandler.emit(e.type, e);
        }.bind(this);

        this.styleToggle = function styleToggle() {
            this.move = false;
            if (this.data.checked) {
                this.offsetX = this.toggleBar.offsetLeft + this.toggleBar.clientWidth;
                this.toggleRadio.setAttribute('checked', '');
                this.toggleBar.setAttribute('checked', '');
                this.radioOn.classList.add('fill');
            } else {
                this.offsetX = 0;
                this.toggleRadio.removeAttribute('checked', '');
                this.toggleBar.removeAttribute('checked', '');
                this.radioOn.classList.remove('fill');
            }
            var val = this.data.checked ? 1 : 0;
            this.options.end(val);
            
            var classArray = this.el.classList ;
            for(var i = 0 ; i < classArray.length ; i++){
            	if(classArray[i] != "toggle-patch"){
            		 toggleName = classArray[i] ;
            	}
            	}
           /* dexterjs.logEvent("FBS_SIMULATION_WIDGET", {
                "widgetType" :  "toggle" ,
                "widgetName" : toggleName 
            });*/
            
            this.toggleValue.innerHTML = this.options.shifts[val];
        }.bind(this);

        this.model.eyesOn(this.styleToggle);
        _init.call(this);
    }

    var defaults = {
        switchType: false,
        shifts: ['Off', 'On'],
        label: true,
        UILabel: 'Object',
        start: 0,
        UIValue: "",
        classes: ['toggle-patch'],
        info: '',
        end: function() {}
    };


    function _init() {
        var template = '<span class="toggle-info-icon"></span>' + '<div class="toggle-info""><div class="toggle-info-close"></div><div class="toggle-info-text">' + this.options.info + '</div></div>' + '<div class="toggle-body-wrapper">' + '<span class="toggle-label">' + this.options.UILabel + ' = </span><span class="toggle-value">' + this.options.shifts[this.options.start] + '</span>' + '<div id="toggleContainer" class="toggle-container"><div class="toggle-bar" id="toggleBar"></div>' + '<div id="toggleRadio" class="toggle-radio"><div class="radio-container" id="radioContainer">' + '<div id="radioOff" class="radio-off"> </div>' + '<div id="radioOn" class="radio-on"></div></div><div></div>';

        this.el = document.createElement('div');
        this.el.innerHTML = template;
        this.el.id = "togglePatch";
        this.el.classList.add('toggle-patch');
        this.toggleRadio = this.el.querySelector('#toggleRadio');
        this.toggleContainer = this.el.querySelector('#toggleContainer');
        this.toggleBar = this.el.querySelector('#toggleBar');
        this.radioOn = this.el.querySelector('#radioOn');
        this.radioOff = this.el.querySelector('#radioOff');
        this.radioContainer = this.el.querySelector('#radioContainer');
        this.toggleValue = this.el.querySelector('.toggle-value');
        this.infoIcon = this.el.querySelector('.toggle-info-icon');
        this.info = this.el.querySelector('.toggle-info');
        if(this.options.info === ""){
        	this.infoIcon.classList.add('hide');
        }
        this.options.classes.forEach(function(element) {
            this.el.classList.add(element);
        }.bind(this));
        if (!this.options.switchType) {
            this.toggleContainer.classList.add('two-valued');
        }

        _bindEvents.call(this);
    }

    function _bindEvents() {
    	var that = this;
    	if("ontouchstart" in document){
       	 this.toggleRadio.addEventListener('touchstart',function(event){
	    	  event.preventDefault();
	    	  that.mouseDownFwd(event); 
	      });	
    	}
        this.toggleRadio.addEventListener('mousedown', this.mouseDownFwd);
        this.eventHandler.on('mousedown', this.trackStart);
        this.eventHandler.on('mousemove', this.trackX);
        this.eventHandler.on('mouseup', this.trackEnd);
        this.eventHandler.on('touchstart', this.trackStart);
        this.eventHandler.on('touchmove', this.trackX);
        this.eventHandler.on('touchend', this.trackEnd);

        _showInfoHandler.call(this, this.infoIcon);
    }


    function _showInfoHandler(elem) {
        elem.addEventListener('click', function(e) {
            //e.stopPropagation();
            var info = this.info;

            var close = info.querySelector('.toggle-info-close');
            /**Adding high z index*/
            this.el.classList.add('highZIndex');
            
            close.addEventListener('click', function(ev) {
                ev.stopPropagation();
                closeIcon(ev);
            });

            info.addEventListener('click', function(ev) {
                ev.stopPropagation();
            });

            info.style.webkitTransform = 'scale(1)';
            info.style.transform = 'scale(1)';

            var closeIcon = _closeInfo.bind(this);

            document.addEventListener('click', closeIcon);
            //for touch devices 
            document.addEventListener('touchstart', closeIcon);
            function _closeInfo(e) {
            	 if (e.touches) e = e.touches[0];
                if (e.target == this.infoIcon)
                    return;
                /**Removing high z index*/
                this.el.classList.remove('highZIndex');
                info.style.webkitTransform = 'scale(0)';
                info.style.transform = 'scale(0)';
                document.removeEventListener('click', closeIcon);
                document.removeEventListener('touchstart', closeIcon);
            }

        }.bind(this));
    }


    Toggle.prototype.trackStart = function trackStart(e) {
        e.stopPropagation();
        if (e.touches) e = e.touches[0];
        this._w = this.toggleBar.offsetLeft + this.toggleBar.clientWidth;
        this._startX = e.clientX;
    };

    Toggle.prototype.trackX = function trackX(e) {
        if (e.touches) e = e.touches[0];
        e.dx = this.offsetX - this._startX + e.clientX;
        this.move = true;
        this._x = Math.min(this._w, Math.max(0, this.checked ? this._w + e.dx : e.dx));
        var s = this.toggleRadio.style;
        s.webkitTransform = s.transform = 'translate3d(' + this._x + 'px,0,0)';
    };



    Toggle.prototype.trackEnd = function trackEnd(e) {
        if (e.touches) e = e.touches[0];
        var s = this.toggleRadio.style;
        s.webkitTransform = s.transform = null;
        if (!this.move) {
            this.data.checked = !this.data.checked;
            return;
        }
        this.move = false;
        this.data.checked = Math.abs(this._x) > this._w / 2;
    };

    /**
     * Disable Toggle movement
     * @method disable
     * @memberof Toggle
     */
    Toggle.prototype.disable = function disable() {
        this.isDisable = true;
        this.el.classList.add('toggle-disable');
    };

    /**
     * enable Toggle movement
     * @method enable
     * @memberof Toggle
     */
    Toggle.prototype.enable = function enable() {
        this.isDisable = false;
        this.el.classList.remove('toggle-disable');
    };

    /**
     * Update the Toggle
     * @method  update
     * @memberof Toggle
     * @param {number} number either 0 or 1
     */
    Toggle.prototype.update = function update(value) {
        this.data.checked = (value == 1);
    };


    Toggle.prototype.render = function render(container) {
        container.appendChild(this.el);
    };

    return Toggle;

});;define('Trigger', ['StaticObject'], function(StaticObject) {



    /**
     * creates Instance of trigger
     * @constructor Trigger
     * @param {object} options duration, startCallback and endCallback
     */
    function Trigger(options) {
        this._duration = (typeof(options.duration) === 'number') ? options.duration * 1000 : options.duration;
        this._startCallback = options.startCallback;
        this._endCallback = options.endCallback;
        this._pauseCallback = options.pauseCallback;
        this._resumeCallback = options.resumeCallback;
        this._pauseAllowed = options.pauseAllowed;
        this._state = 0;
        this._pause = false;
        this._lapseTime = 0;
        //this._move = move;
        _init.call(this);
    }
    
    function _init(){
        this._trigger = new StaticObject({
            name: 'triggerContainer',
            type: 'div',
            classes: ['play-container']
        });
        this._playIcon = new StaticObject({
            name: 'playIcon',
            type: 'div',
            parent: this._trigger.el,
            classes: ['play-icon']
        });
        this._svgContainer = document.createElementNS("http://www.w3.org/2000/svg", 'svg');
        this._svgContainer.classList.add('circle');
        this._svgContainer.setAttribute('width', '55');
        this._svgContainer.setAttribute('height', '55');
        this._trigger.addsimObject([this._playIcon]);
        this.el = this._trigger.el;
        this.el.appendChild(this._svgContainer);

        var pathOutline = document.createElementNS("http://www.w3.org/2000/svg", 'path');
        pathOutline.setAttribute("d", "M 27 2 a 24.5 24.5 0 1 0 0.0001 0");
        pathOutline.style.stroke = '#ff692e';
        pathOutline.style.strokeWidth = "3px";

        var path = document.createElementNS("http://www.w3.org/2000/svg", 'path');
        path.setAttribute("d", "M 27 4 a 22.5 22.5 0 1 0 0.0001 0");
        path.style.stroke = 'rgb(255,255,255)';
        path.style.strokeWidth = "5px";

        var path2;
        this._path2 = path2 = document.createElementNS("http://www.w3.org/2000/svg", 'path');
        path2.setAttribute("d", "M 27 4 a 22.5 22.5 0 1 0 0.0001 0");
        path2.style.stroke = '#fc9815';
        path2.style.strokeWidth = "5px";
        path2.style.fill = '#fc9815';

        var length = path2.getTotalLength();
        this._length = length;
        path2.style.strokeDashoffset = -length;
        path2.style.strokeDasharray = length;
        this._svgContainer.appendChild(pathOutline);
        this._svgContainer.appendChild(path);
        this._svgContainer.appendChild(path2);
        _bindEvents.call(this);
    }


    Trigger.prototype.animate = function() {
        var self = this;

        if (this._pause) {
            timeSinceStart = 0;
            return;
        }
        var timeSinceStart = Date.now() - this._startTime;
        if (timeSinceStart > this._currentDuration) {
            self.reset();
            self._endCallback();
        } else {
            var progress = timeSinceStart / this._currentDuration;
            this._lapseTime = timeSinceStart;
            this._state = this._length * (1 - progress);
            self._path2.style.strokeDashoffset = -Math.floor(this._state);
            this._svgContainer.setAttribute('viewBox','0 0 55 55'); /* remove this after chrome fixed the repaint issue*/
            this.ID = window.requestAnimationFrame(function() {
                self.animate(self._path2, length);
            });
        }
    };

    Trigger.prototype.setDuration = function(duration) {
        this._duration = duration * 1000;
    };

    Trigger.prototype.pause = function() {
        this._pause = true;
    };
    Trigger.prototype.resume = function() {
        this._pause = false;
        this._startTime = Date.now();
        this._currentDuration = this._currentDuration - this._lapseTime;
        this._lapseTime = 0;
        this._length = this._state;
        this.animate();
    };

    Trigger.prototype.reset = function() {
        var self = this;
        self._path2.style.strokeDashoffset = self._length = self._path2.getTotalLength();
        this._svgContainer.setAttribute('viewBox','0 0 55 55'); /* remove this after chrome fixed the repaint issue*/
        window.cancelAnimationFrame(this.ID);
        self._trigger.el.classList.remove('playing');
        self._trigger.el.classList.remove('pause');
        self._trigger.el.classList.remove('disabled');
    };

    Trigger.prototype.play = function() {
        this._startTime = Date.now();
        this._pause = false;
        this._currentDuration = this._duration;
        this.animate();
    };

    function _bindEvents() {
        this._trigger.on('click', function() {
            if (this._trigger.el.classList.contains('playing') && this._pauseAllowed === false && this._duration !== 'continuous') {
                return false;
            }

            if (this._trigger.el.classList.contains('pause')) {
                this._trigger.el.classList.remove('pause');
                this._trigger.el.classList.add('playing');
                this._resumeCallback();
                if (this._duration !== 'continuous') {
                    this.resume();
                }
            } else if (this._trigger.el.classList.contains('playing')) {
                this._trigger.el.classList.add('pause');
                this._pauseCallback();
                if (this._duration !== 'continuous') {
                    this.pause();
                }
            } else {

                this._trigger.el.classList.add('playing');
                if (this._pauseAllowed === false) {
                    this._trigger.el.classList.add('disabled');
                }
                this._startCallback();

                if (this._duration === 'continuous') {

                } else {
                    this._startTime = Date.now();
                    this.play();
                }
            }
            
            
            var widgetType, widgetName ;
            
          /* dexterjs.logEvent("FBS_WIDGET", {
               widgetType :  "trigger" ,
               widgetName : "trigger" 
           });*/
            
        }.bind(this));
    }



    Trigger.prototype.render = function(container) {
        container.appendChild(this.el);
    };

    return Trigger;
});